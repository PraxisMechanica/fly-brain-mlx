# Source audit, 2026-10-15

Audited local candidate: `1e33d98854312ab9337b7443c49a75ef538d9c53`.
The original checkout was clean, detached `79f62ad`; it was advanced to the
existing local main commit after the requested source audit. The separate
`pr-split` checkout and its running matrix were not modified or signalled.

## Scope and current evidence

`milestone.md` in the newer checkout records twelve accepted cases, including
ten sugar cases at 0.1/1 seconds and sugar trials 0/1 at ten seconds. Trial 0
has 170,752 identical events; trial 1 has 171,973 events with four one-step
shifts and a bound causal review. The remaining 52-case campaign was estimated
at 40–64 elapsed hours and 49 GiB. These are recorded results pending current
compatibility verification, not newly reproduced experiments. The stale
checkout's architecture hold and deleted-evidence inventory are superseded by
the newer milestone; no new numerical mode is adopted by this task.

## Exact source identities

Eon main equals the existing pin
`a3db62f9436074e485c0278290c2164ed6150808`. Kisame main was read at
`e417b33616513ef350b1b1c3cdf2b5b7a1799c8e`. All requested Kisame files were
reviewed: README validation sections, `engine_ref64.py`, `validate_brian2.py`,
`subnet.py`, `validate_notebook.py`, and `tools/refractory_gate.py`.

| Property | Eon and this port | Kisame |
| --- | --- | --- |
| Connectome | FlyWire v783, 138,639 neurons, 15,091,983 rows | v630, 127,400 neurons, 14,687,178 edges |
| Reference | Pinned Brian2 2.8.0 | Brian2 2.10.1 |
| dt; membrane/synaptic constants | 0.1 ms; 20/5 ms | Same |
| Initial/rest/reset voltage | -52 mV | Same |
| Threshold | Strictly greater than -45 mV | Same physical predicate |
| Ordinary refractory; delay | 2.2 ms / 22 steps; 1.8 ms / 18 steps | Same nominal release/delay |
| Contact/external amplitudes | 0.275 mV; 250 times that = 68.75 mV | Same |
| Activation refractory | Zero for union of both activation lists, including zero-rate channels | Same, but duplicate/overlapping targets rejected |
| Rates | Sugar 200 Hz, P9 100 Hz; second class explicit | Default 150 Hz; published sugar file 200 Hz, notebook cases also 100 Hz |

The current MLX candidate stores threshold-relative `u=v+45`, applies transient
compensation, resets `u=-7,g=0`, and uses strict `u_pre>0`. Kisame's NumPy64
uses absolute voltage and its Brian2-generated expression ordering. Do not
copy coefficients or finite-precision implementation choices between models.

Kisame's ring consumes before overwriting an 18-slot source-spike ring. This
can implement the same delay as this port's 19-slot queue. Its countdown reload
22 is equivalent to ordinary release at step 22. Its arrival/input mask is
availability before threshold; it can write into this-step spikers before
reset. This port requires `available AND NOT spiking` at delivery. End-state
agreement alone would miss that ledger difference. Both freeze v and g during
refractory and drop blocked arrivals rather than deferring them. Silencing is
outgoing-only in Eon's actual code. Kisame's pack coalesces rows; this port
preserves every original row and duplicate.

## Six parity pitfalls

1. Kisame corrected its FMA diagnosis on 2026-09-25: captured scalar constants
   printed with seven significant digits caused the observed `mx.compile`
   mismatch. Passing constants as arguments restored parity there. Handwritten
   single-expression Metal arithmetic can still contract; its kernel uses
   `#pragma clang fp contract(off)`. This candidate keeps compilation disabled;
   no kernel or compilation change is part of this task.
2. A default `StateMonitor(when='start')` row k is the previous end state.
   Existing local monitors explicitly use threshold/before-reset/end phases;
   no artificial one-tick shift is appropriate.
3. Pinned Brian2 protects both refractory variables against synaptic writes.
   The local reference tests explicitly verify freezing, discarded inputs,
   step-22 release, and same-step-spiker blocking even with zero refractory.
4. Preserve strict threshold, including equality/adjacent representable values.
5. Kisame uses int32 contact atomics and then one scale multiplication. This
   candidate uses guarded exact float32 contact reduction and compensated
   scaling, with a fallback compensated tree; preserve its qualified arithmetic.
6. Bind actual saved events, rates, channel classes and hashes. Kisame's stale
   200-versus-150-Hz result is not evidence that this port's explicit 200-Hz
   sugar rate is wrong.

## Eon interface and score comparability

Backends are selected in `main.py` and dispatched by `code/benchmark.py`.
Runners export `run_all_benchmarks(t_run_values,n_run_values,experiment,logger,
run_label,round_idx)`. CSV fields include setup/build/simulation/total seconds,
duration, trial count, neuron/spike counts, status, experiment and backend;
realtime ratio is `(duration*trials)/simulation_total`. There is no memory CSV
field. Export is outside simulation timing. CPU single-trial Brian2 uses C++
standalone; multi-trial workers include load/build/extraction inside the
simulation timer and report setup/build zero. Report actual timing boundaries.

The legacy scorer pools trials; its Jaccard uses active-neuron union, Pearson
uses shared-active neurons, and spike-count ratio is diagnostic. Rounded
Jaccard >0.90 and correlation >0.99 produce MATCH. Empty Jaccard is zero and
constant correlation can be undefined. Preserve those report conventions
separately from acceptance; they do not prove exact or distributional parity.
The pairwise scorer additionally has greedy one-to-one event timing matches.

Eon's PyTorch has the same constants but Euler integration, different input
order/refractory semantics and a wrapper that ignores secondary drive and
silencing. It remains a named independent comparator, not the float64 oracle.

## Licensing and attribution

Eon's root GPL version-2 license is byte-identical to this repository's
license, SHA-256 `8177f97513213526df2cf6184d8ff986c675afb514d4e68a404010521b880643`.
Eon's README specifies GPL-2.0-or-later with third-party exceptions. Kisame is
MIT. Original Shiu paper code carries the Philip Shiu/Nico Spiller 2023 MIT
notice. Preserve all applicable original notices in any adapted files.
This audit copies no Kisame implementation. Its source inspection informed
the validation approach; it is not a v783 qualification result or speed claim.

## Reviewed sources

- [Kisame README](https://raw.githubusercontent.com/Kisame76/drosophila-brain-mlx/e417b33616513ef350b1b1c3cdf2b5b7a1799c8e/README.md)
- [Kisame oracle](https://raw.githubusercontent.com/Kisame76/drosophila-brain-mlx/e417b33616513ef350b1b1c3cdf2b5b7a1799c8e/src/lif/engine_ref64.py)
- [Kisame constants](https://raw.githubusercontent.com/Kisame76/drosophila-brain-mlx/e417b33616513ef350b1b1c3cdf2b5b7a1799c8e/src/lif/core.py)
- [Kisame license](https://raw.githubusercontent.com/Kisame76/drosophila-brain-mlx/e417b33616513ef350b1b1c3cdf2b5b7a1799c8e/LICENSE)
- [Eon runner](https://raw.githubusercontent.com/eonsystemspbc/fly-brain/a3db62f9436074e485c0278290c2164ed6150808/code/run_brian2_cuda.py)
- [Eon benchmark](https://raw.githubusercontent.com/eonsystemspbc/fly-brain/a3db62f9436074e485c0278290c2164ed6150808/code/benchmark.py)
- [Eon scorer](https://raw.githubusercontent.com/eonsystemspbc/fly-brain/a3db62f9436074e485c0278290c2164ed6150808/code/compare_ground_truth.py)
- [Eon license](https://raw.githubusercontent.com/eonsystemspbc/fly-brain/a3db62f9436074e485c0278290c2164ed6150808/LICENSE)
