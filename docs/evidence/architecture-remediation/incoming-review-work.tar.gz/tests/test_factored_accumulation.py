import importlib.metadata
import json
import os
import sys
from pathlib import Path

import mlx.core as mx
import numpy as np
import pytest
import test_mlx_core as qualification

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from probe_mlx_factored_accumulation import SCALE, factored_sum

MEASUREMENTS = {}


def weights(counts):
    return tuple(np.asarray(counts, dtype=np.int64) * SCALE)


def record(name, arrays, measurements):
    name = f'factored-{name}'
    MEASUREMENTS[name] = measurements
    output = os.environ.get('MLX_QUALIFICATION_OUTPUT')
    if output:
        with (Path(output) / f'{name}.npz').open('xb') as destination:
            np.savez_compressed(destination, **arrays)


@pytest.fixture(scope='module', autouse=True)
def environment():
    assert os.environ.get('MLX_ENABLE_TF32') == '0'
    assert mx.metal.is_available()
    assert importlib.metadata.version('mlx') == '0.32.3'
    assert importlib.metadata.version('mlx-metal') == '0.32.3'
    mx.disable_compile()
    yield
    output = os.environ.get('MLX_QUALIFICATION_OUTPUT')
    if output:
        with (Path(output) / 'factored-networks.json').open('x') as destination:
            json.dump(
                {
                    'execution': 'Test-only factored recurrent-input adapter over unchanged qualified core',
                    'device': mx.device_info(),
                    'measurements': MEASUREMENTS,
                },
                destination,
                indent=2,
            )
            destination.write('\n')


@pytest.fixture(autouse=True)
def factored_adapter(monkeypatch):
    original_network = qualification.network_for
    original_advance = qualification.core.advance
    layouts = {}

    def network_for(case):
        network = original_network(case)
        counts = np.rint(np.asarray(case.weights) / SCALE).astype(np.int64)
        np.testing.assert_array_equal(counts * SCALE, case.weights)
        counts[np.isin(case.sources, case.silenced)] = 0
        degree = np.bincount(case.destinations, minlength=case.neurons)
        width = 1 << (max(1, int(degree.max())) - 1).bit_length()
        edge_ids = np.zeros((case.neurons, width), dtype=np.int32)
        packed = np.zeros((case.neurons, width), dtype=np.float32)
        for target in range(case.neurons):
            edges = np.flatnonzero(np.asarray(case.destinations) == target)
            edge_ids[target, : len(edges)] = edges + 1
            packed[target, : len(edges)] = counts[edges]
        with mx.stream(mx.gpu):
            layouts[id(network)] = (network, mx.array(edge_ids), mx.array(packed))
        return network

    def advance(network, state, events):
        with mx.stream(mx.gpu):
            updated, trace = original_advance(network, state, events)
            _, edge_ids, packed = layouts[id(network)]
            accepted = mx.concatenate(
                (mx.zeros((events.shape[0], 1), dtype=mx.bool_), trace.accepted), axis=1
            )
            active_counts = mx.where(accepted[:, edge_ids], packed, 0)
            synaptic, _, _ = factored_sum(active_counts, trace.pre_synaptic_mv)
            synaptic = mx.where(trace.receiving, synaptic, trace.pre_synaptic_mv)
            return updated._replace(
                synaptic_mv=mx.where(trace.spikes, 0, synaptic)
            ), trace._replace(before_reset_synaptic_mv=synaptic)

    monkeypatch.setattr(qualification, 'network_for', network_for)
    monkeypatch.setattr(qualification, 'record', record)
    monkeypatch.setattr(qualification.core, 'advance', advance)


Case = qualification.Case
INITIAL = qualification.core.INITIAL_LAST_SPIKE


@pytest.mark.parametrize(
    'name,case,steps,impulses',
    [
        ('rest-empty', Case(2), 60, ()),
        (
            'reset-weights',
            Case(2, (0,), (1,), weights([4]), voltage=(-44, -52), synaptic=(1, 0)),
            60,
            (),
        ),
        (
            'positive-negative',
            Case(3, (0, 0), (1, 2), weights([15, -15]), voltage=(-44, -52, -52)),
            80,
            (),
        ),
        (
            'balanced-duplicates',
            Case(
                4,
                (0, 1, 0, 1),
                (2, 2, 3, 3),
                weights([4, -4, 1, 1]),
                voltage=(-44, -44, -52, -52),
            ),
            80,
            (),
        ),
        (
            'cast-drift-triplet',
            Case(
                2, (0, 0, 0), (1, 1, 1), weights([2405, -2404, -1]), voltage=(-44, -52)
            ),
            60,
            (),
        ),
        (
            'fanout-self-wrap',
            Case(3, (0, 0, 0), (0, 1, 2), weights([4, 7, -7]), (0,)),
            160,
            ((0, 0), (25, 0), (50, 0), (75, 0), (100, 0)),
        ),
        ('refractory-held', Case(1, voltage=-50, synaptic=1, last_spike=0), 40, ()),
        (
            'released-at-arrival',
            Case(
                2,
                (0,),
                (1,),
                weights([4]),
                voltage=(-44, -50),
                synaptic=(0, 1),
                last_spike=(INITIAL, -10),
            ),
            50,
            (),
        ),
        (
            'outgoing-silencing',
            Case(
                3,
                (0, 1, 2),
                (1, 2, 1),
                weights([364, 11, 7]),
                silenced=(1,),
                voltage=(-44, -52, -52),
            ),
            80,
            (),
        ),
        (
            'overlapping-inputs',
            Case(2, targets=(0, 0, 1)),
            80,
            ((0, 0), (0, 1), (5, 0), (12, 1), (24, 0), (24, 1)),
        ),
        (
            'zero-refractory-loss',
            Case(1, targets=(0,)),
            12,
            tuple((step, 0) for step in range(12)),
        ),
        (
            '32-edge-fanin',
            Case(
                2,
                (0,) * 32,
                (1,) * 32,
                weights([1, -1] * 15 + [2, 1]),
                voltage=(-44, -52),
            ),
            80,
            (),
        ),
    ],
)
def test_factored_network_matches_reference_phases(name, case, steps, impulses):
    observed = qualification.qualify(
        name, case, qualification.events_for(case, steps, impulses)
    )
    if name == 'cast-drift-triplet':
        assert abs(observed['synaptic_mv'][18, 0, 1]) <= 2e-5
    if name == 'outgoing-silencing':
        assert observed['spikes'][:, 0, 1].any()
        assert not observed['spikes'][:, 0, 2].any()
    if name == 'released-at-arrival':
        assert observed['accepted'][18, 0, 0]


def test_factored_refractory_boundary_and_firing_step_discard_events():
    case = Case(
        3,
        (0, 1),
        (2, 2),
        weights([4, 7]),
        (0, 1),
        voltage=(-52, -52, -50),
        synaptic=(0, 0, 1),
        last_spike=(INITIAL, INITIAL, 0),
    )
    observed = qualification.qualify(
        'boundary', case, qualification.events_for(case, 50, ((2, 0), (3, 1)))
    )
    assert observed['discarded'][21, 0, 0]
    assert observed['accepted'][22, 0, 1]
    assert not observed['due'][22, 0, 0]
    case = Case(
        3,
        (0, 0),
        (1, 2),
        weights([11, 11]),
        (0, 1),
        voltage=(-52, -52, -44),
        synaptic=(0, 0, 1),
        last_spike=(INITIAL, INITIAL, 0),
    )
    observed = qualification.qualify(
        'same-step-loss', case, qualification.events_for(case, 50, ((3, 0), (21, 1)))
    )
    np.testing.assert_array_equal(observed['spikes'][22, 0, 1:], [True, True])
    np.testing.assert_array_equal(observed['discarded'][22, 0], [True, True])


REPLAY = Case(3, (0, 0, 1, 2), (1, 2, 2, 1), weights([1, 364, -2, 3]), (0, 0, 1))


def test_factored_replay_preserves_reference_states_and_events():
    qualification.qualify('replay-1000', REPLAY, qualification.replay_events())


def test_factored_batch_and_chunked_runs_preserve_complete_state():
    events = qualification.replay_events(180, trials=3)
    batch = qualification.qualify('batch-chunks', REPLAY, events)
    chunked = qualification.run_candidate(REPLAY, events, [1, 17, 1, 18, 40, 103])
    for key, value in batch.items():
        np.testing.assert_array_equal(value, chunked[key])
    for trial in range(3):
        standalone = qualification.run_candidate(REPLAY, events[:, trial : trial + 1])
        for key, value in standalone.items():
            np.testing.assert_array_equal(value[:, 0], batch[key][:, trial])


@pytest.mark.parametrize(
    'name,counts',
    [
        ('retained-large', [2405] * 2048 + [1] + [-2405] * 2048),
        ('cast-drift-large', [2405, -2404, -1] * 128),
    ],
)
def test_factored_large_fanin_meets_delayed_reference_trace(name, counts):
    case = Case(
        2, (0,) * len(counts), (1,) * len(counts), weights(counts), voltage=(-44, -52)
    )
    events = qualification.events_for(case, 40)
    expected = qualification.run_reference(case, events)
    observed = qualification.run_candidate(case, events)
    repeated = qualification.run_candidate(case, events)
    errors = {}
    for key, wanted in expected.items():
        if key.endswith('_mv'):
            error = np.abs(observed[key] - wanted)
            assert np.all(error <= 1e-3 + 1e-5 * np.abs(wanted))
            errors[key] = float(error.max(initial=0))
        else:
            np.testing.assert_array_equal(observed[key], wanted)
    for key in observed:
        np.testing.assert_array_equal(observed[key], repeated[key])
    assert observed['accepted'][18, 0].all()
    assert not observed['due'][:18].any()
    state = expected['before_reset_synaptic_mv'][18]
    assert np.all(
        np.abs(observed['before_reset_synaptic_mv'][18] - state)
        <= 2e-5 + 2e-6 * np.abs(state)
    )
    record(
        name,
        {
            **{f'reference_{key}': value for key, value in expected.items()},
            **{f'mlx_{key}': value for key, value in observed.items()},
            'events': events,
        },
        {
            'steps': 40,
            'edges': len(counts),
            'max_abs_error_mv': errors,
            'exact_discrete_parity': True,
            'repeat_bit_identical': True,
        },
    )


def test_factored_adapter_uses_metal_with_cpu_default_and_resets_pending_trials():
    with mx.stream(mx.cpu):
        network = qualification.network_for(Case(2, (0,), (1,), weights([1])))
        state = qualification.core.initial_state(network, voltage_mv=[-44, -52])
        state, trace = qualification.core.advance(
            network, state, mx.zeros((1, 0), dtype=mx.bool_)
        )
        assert np.asarray(state.queue).any()
        fresh = qualification.core.initial_state(network)
        assert not np.asarray(fresh.queue).any()
        fresh, _ = qualification.core.advance(
            network, fresh, mx.zeros((1, 0), dtype=mx.bool_)
        )
        np.testing.assert_array_equal(np.asarray(fresh.synaptic_mv), 0)
        np.testing.assert_array_equal(np.asarray(trace.spikes), [[True, False]])
