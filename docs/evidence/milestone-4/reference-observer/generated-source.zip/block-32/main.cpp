#include <stdlib.h>
#include "objects.h"
#include <ctime>
#include <time.h>

#include "run.h"
#include "brianlib/common_math.h"

#include "code_objects/observed_before_codeobject.h"
#include "code_objects/observed_end_codeobject.h"
#include "code_objects/observed_input_pre_codeobject.h"
#include "code_objects/observed_input_pre_push_spikes.h"
#include "code_objects/before_run_observed_input_pre_push_spikes.h"
#include "code_objects/observed_input_synapses_create_array_codeobject.h"
#include "code_objects/observed_neurons_spike_resetter_codeobject.h"
#include "code_objects/observed_neurons_spike_thresholder_codeobject.h"
#include "code_objects/after_run_observed_neurons_spike_thresholder_codeobject.h"
#include "code_objects/observed_neurons_stateupdater_codeobject.h"
#include "code_objects/observed_pre_codeobject.h"
#include "code_objects/observed_recurrent_pre_codeobject.h"
#include "code_objects/observed_recurrent_pre_push_spikes.h"
#include "code_objects/before_run_observed_recurrent_pre_push_spikes.h"
#include "code_objects/observed_recurrent_synapses_create_array_codeobject.h"
#include "code_objects/observed_source_codeobject.h"
#include "code_objects/spikemonitor_codeobject.h"


#include <iostream>
#include <fstream>
#include <string>




void set_from_command_line(const std::vector<std::string> args)
{
    for (const auto& arg : args) {
		// Split into two parts
		size_t equal_sign = arg.find("=");
		auto name = arg.substr(0, equal_sign);
		auto value = arg.substr(equal_sign + 1, arg.length());
		brian::set_variable_by_name(name, value);
	}
}
int main(int argc, char **argv)
{
	std::random_device _rd;
	std::vector<std::string> args(argv + 1, argv + argc);
	if (args.size() >=2 && args[0] == "--results_dir")
	{
		brian::results_dir = args[1];
		#ifdef DEBUG
		std::cout << "Setting results dir to '" << brian::results_dir << "'" << std::endl;
		#endif
		args.erase(args.begin(), args.begin()+2);
	}
        

	brian_start();
        

	{
		using namespace brian;

		
                
        _array_defaultclock_dt[0] = 0.0001;
        _array_defaultclock_dt[0] = 0.0001;
        _array_defaultclock_dt[0] = 0.0001;
        
                        
                        for(int i=0; i<_num__array_observed_neurons_lastspike; i++)
                        {
                            _array_observed_neurons_lastspike[i] = - 10000.0;
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_neurons_not_refractory; i++)
                        {
                            _array_observed_neurons_not_refractory[i] = true;
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_neurons_v; i++)
                        {
                            _array_observed_neurons_v[i] = _static_array__array_observed_neurons_v[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_neurons_g; i++)
                        {
                            _array_observed_neurons_g[i] = _static_array__array_observed_neurons_g[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_neurons_lastspike; i++)
                        {
                            _array_observed_neurons_lastspike[i] = _static_array__array_observed_neurons_lastspike[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_neurons_rfc; i++)
                        {
                            _array_observed_neurons_rfc[i] = _static_array__array_observed_neurons_rfc[i];
                        }
                        
        _dynamic_array_observed_recurrent_delay.resize(1);
        _dynamic_array_observed_recurrent_delay.resize(1);
        _dynamic_array_observed_recurrent_delay[0] = 0.0018000000000000002;
        
                        
                        for(int i=0; i<_num__array_observed_recurrent_sources; i++)
                        {
                            _array_observed_recurrent_sources[i] = _static_array__array_observed_recurrent_sources[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_recurrent_targets; i++)
                        {
                            _array_observed_recurrent_targets[i] = _static_array__array_observed_recurrent_targets[i];
                        }
                        
        _run_observed_recurrent_synapses_create_array_codeobject();
        
                        
                        for(int i=0; i<_dynamic_array_observed_recurrent_w.size(); i++)
                        {
                            _dynamic_array_observed_recurrent_w[i] = _static_array__dynamic_array_observed_recurrent_w[i];
                        }
                        
        _dynamic_array_observed_source_spike_number.resize(75);
        
                        
                        for(int i=0; i<_dynamic_array_observed_source_spike_number.size(); i++)
                        {
                            _dynamic_array_observed_source_spike_number[i] = _static_array__dynamic_array_observed_source_spike_number[i];
                        }
                        
        _dynamic_array_observed_source_neuron_index.resize(75);
        
                        
                        for(int i=0; i<_dynamic_array_observed_source_neuron_index.size(); i++)
                        {
                            _dynamic_array_observed_source_neuron_index[i] = _static_array__dynamic_array_observed_source_neuron_index[i];
                        }
                        
        _dynamic_array_observed_source_spike_time.resize(75);
        
                        
                        for(int i=0; i<_dynamic_array_observed_source_spike_time.size(); i++)
                        {
                            _dynamic_array_observed_source_spike_time[i] = _static_array__dynamic_array_observed_source_spike_time[i];
                        }
                        
        _dynamic_array_observed_source__timebins.resize(75);
        _array_observed_source__lastindex[0] = 0;
        _array_observed_source_period[0] = 0.0;
        
                        
                        for(int i=0; i<_num__array_observed_input_sources; i++)
                        {
                            _array_observed_input_sources[i] = _static_array__array_observed_input_sources[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_input_targets; i++)
                        {
                            _array_observed_input_targets[i] = _static_array__array_observed_input_targets[i];
                        }
                        
        _run_observed_input_synapses_create_array_codeobject();
        
                        
                        for(int i=0; i<_num__array_observed_pre__indices; i++)
                        {
                            _array_observed_pre__indices[i] = _static_array__array_observed_pre__indices[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_before__indices; i++)
                        {
                            _array_observed_before__indices[i] = _static_array__array_observed_before__indices[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_observed_end__indices; i++)
                        {
                            _array_observed_end__indices[i] = _static_array__array_observed_end__indices[i];
                        }
                        
        _array_defaultclock_timestep[0] = 0;
        _array_defaultclock_t[0] = 0.0;
        _array_observed_source__lastindex[0] = 0;
        
                        
                        for(int i=0; i<_dynamic_array_observed_source__timebins.size(); i++)
                        {
                            _dynamic_array_observed_source__timebins[i] = _static_array__dynamic_array_observed_source__timebins[i];
                        }
                        
        _array_observed_source__period_bins[0] = 0.0;
        _before_run_observed_recurrent_pre_push_spikes();
        _before_run_observed_input_pre_push_spikes();
        observed_network.clear();
        observed_network.add(&defaultclock, _run_observed_neurons_stateupdater_codeobject);
        observed_network.add(&defaultclock, _run_observed_pre_codeobject);
        observed_network.add(&defaultclock, _run_observed_neurons_spike_thresholder_codeobject);
        observed_network.add(&defaultclock, _run_observed_source_codeobject);
        observed_network.add(&defaultclock, _run_spikemonitor_codeobject);
        observed_network.add(&defaultclock, _run_observed_recurrent_pre_push_spikes);
        observed_network.add(&defaultclock, _run_observed_recurrent_pre_codeobject);
        observed_network.add(&defaultclock, _run_observed_input_pre_push_spikes);
        observed_network.add(&defaultclock, _run_observed_input_pre_codeobject);
        observed_network.add(&defaultclock, _run_observed_before_codeobject);
        observed_network.add(&defaultclock, _run_observed_neurons_spike_resetter_codeobject);
        observed_network.add(&defaultclock, _run_observed_end_codeobject);
        
        static_assert(sizeof(double)==8 && sizeof(int32_t)==4 && sizeof(uint64_t)==8, "Observer scalar widths differ");
        static uint32_t obs_crc = 0xffffffffu;
        static uint32_t obs_table[256];
        for(uint32_t i=0; i<256; ++i) {
            uint32_t value=i;
            for(int bit=0; bit<8; ++bit) value = (value>>1) ^ ((value&1) ? 0xedb88320u : 0u);
            obs_table[i]=value;
        }
        static auto obs_write = [](const void* pointer, size_t size) {
            if(size) {
                const auto* data = static_cast<const unsigned char*>(pointer);
                std::cout.write(reinterpret_cast<const char*>(data), size);
                for(size_t i=0; i<size; ++i) obs_crc = (obs_crc>>8) ^ obs_table[(obs_crc^data[i])&255u];
            }
        };
        static auto obs_q = [](uint64_t value) { obs_write(&value, sizeof(value)); };
        static auto obs_i = [](int32_t value) { obs_write(&value, sizeof(value)); };
        static auto obs_d = [](double value) { obs_write(&value, sizeof(value)); };
        static auto obs_finish = []() {
            const uint32_t value = obs_crc ^ 0xffffffffu;
            std::cout.write(reinterpret_cast<const char*>(&value), sizeof(value));
            obs_crc = 0xffffffffu;
        };
        static uint64_t obs_step = 0;
        obs_write("FBQOBS01", 8);
        obs_q(6);
        obs_q(101);
        obs_q(3);
        obs_q(2);
        obs_q(32);
        obs_finish();
        static auto obs_snapshot = [](uint64_t step) {
        obs_q(step);
        obs_q(defaultclock.timestep[0]);
        obs_d(defaultclock.t[0]);
        obs_i(_array_observed_source__lastindex[0]);
        obs_q(_array_observed_neurons__spikespace[6]);
        obs_write(_array_observed_neurons__spikespace, _array_observed_neurons__spikespace[6] * sizeof(int32_t));
        obs_q(_array_observed_source__spikespace[3]);
        obs_write(_array_observed_source__spikespace, _array_observed_source__spikespace[3] * sizeof(int32_t));
        obs_q(observed_recurrent_pre.queue.size());
        for(const auto* queue : observed_recurrent_pre.queue) {
        obs_i(queue->offset);
        obs_q(queue->queue.size());
        for(const auto& slot : queue->queue) {
        obs_q(slot.size());
        obs_write(slot.data(), slot.size() * sizeof(int32_t));
        }
        }
        obs_q(observed_recurrent_pre.all_peek.size());
        obs_write(observed_recurrent_pre.all_peek.data(), observed_recurrent_pre.all_peek.size() * sizeof(int32_t));
        obs_q(observed_input_pre.queue.size());
        for(const auto* queue : observed_input_pre.queue) {
        obs_i(queue->offset);
        obs_q(queue->queue.size());
        for(const auto& slot : queue->queue) {
        obs_q(slot.size());
        obs_write(slot.data(), slot.size() * sizeof(int32_t));
        }
        }
        obs_q(observed_input_pre.all_peek.size());
        obs_write(observed_input_pre.all_peek.data(), observed_input_pre.all_peek.size() * sizeof(int32_t));
        };
        observed_network.add(&defaultclock, +[]() {
        obs_q(1); obs_snapshot(obs_step); obs_finish();
        ++obs_step;
        if(obs_step % 32 == 0 || obs_step == 101) {
        const size_t rows = _dynamic_array_observed_pre_t.size();
        obs_q(2); obs_q(obs_step - rows); obs_q(rows);
        obs_write(_dynamic_array_observed_pre_t.data(), rows * sizeof(double));
        for(size_t row=0; row<rows; ++row) {
        obs_write(_dynamic_array_observed_pre_v(row).data(), 6 * sizeof(double));
        }
        _dynamic_array_observed_pre_v.resize(0, 6);
        for(size_t row=0; row<rows; ++row) {
        obs_write(_dynamic_array_observed_pre_g(row).data(), 6 * sizeof(double));
        }
        _dynamic_array_observed_pre_g.resize(0, 6);
        for(size_t row=0; row<rows; ++row) {
        for(size_t neuron=0; neuron<6; ++neuron) {
        const uint8_t value = _dynamic_array_observed_pre_not_refractory(row, neuron) ? 1 : 0;
        obs_write(&value, 1);
        }
        }
        _dynamic_array_observed_pre_not_refractory.resize(0, 6);
        _dynamic_array_observed_pre_t.clear();
        _array_observed_pre_N[0] = 0;
        obs_write(_dynamic_array_observed_before_t.data(), rows * sizeof(double));
        for(size_t row=0; row<rows; ++row) {
        obs_write(_dynamic_array_observed_before_v(row).data(), 6 * sizeof(double));
        }
        _dynamic_array_observed_before_v.resize(0, 6);
        for(size_t row=0; row<rows; ++row) {
        obs_write(_dynamic_array_observed_before_g(row).data(), 6 * sizeof(double));
        }
        _dynamic_array_observed_before_g.resize(0, 6);
        for(size_t row=0; row<rows; ++row) {
        for(size_t neuron=0; neuron<6; ++neuron) {
        const uint8_t value = _dynamic_array_observed_before_not_refractory(row, neuron) ? 1 : 0;
        obs_write(&value, 1);
        }
        }
        _dynamic_array_observed_before_not_refractory.resize(0, 6);
        _dynamic_array_observed_before_t.clear();
        _array_observed_before_N[0] = 0;
        obs_write(_dynamic_array_observed_end_t.data(), rows * sizeof(double));
        for(size_t row=0; row<rows; ++row) {
        obs_write(_dynamic_array_observed_end_v(row).data(), 6 * sizeof(double));
        }
        _dynamic_array_observed_end_v.resize(0, 6);
        for(size_t row=0; row<rows; ++row) {
        obs_write(_dynamic_array_observed_end_g(row).data(), 6 * sizeof(double));
        }
        _dynamic_array_observed_end_g.resize(0, 6);
        for(size_t row=0; row<rows; ++row) {
        obs_write(_dynamic_array_observed_end_lastspike(row).data(), 6 * sizeof(double));
        }
        _dynamic_array_observed_end_lastspike.resize(0, 6);
        for(size_t row=0; row<rows; ++row) {
        for(size_t neuron=0; neuron<6; ++neuron) {
        const uint8_t value = _dynamic_array_observed_end_not_refractory(row, neuron) ? 1 : 0;
        obs_write(&value, 1);
        }
        }
        _dynamic_array_observed_end_not_refractory.resize(0, 6);
        _dynamic_array_observed_end_t.clear();
        _array_observed_end_N[0] = 0;
        obs_finish();
        }
        });
        
        set_from_command_line(args);
        observed_network.run(0.010100000000000001, NULL, 10.0);
        obs_q(3); obs_snapshot(101);
        obs_write(_array_observed_neurons_v, 6 * sizeof(double));
        obs_write(_array_observed_neurons_g, 6 * sizeof(double));
        obs_write(_array_observed_neurons_lastspike, 6 * sizeof(double));
        for(size_t neuron=0; neuron<6; ++neuron) {
        const uint8_t value = _array_observed_neurons_not_refractory[neuron] ? 1 : 0;
        obs_write(&value, 1);
        }
        obs_finish(); std::cout.flush();
        _after_run_observed_neurons_spike_thresholder_codeobject();
        #ifdef DEBUG
        _debugmsg_spikemonitor_codeobject();
        #endif
        
        #ifdef DEBUG
        _debugmsg_observed_recurrent_pre_codeobject();
        #endif
        
        #ifdef DEBUG
        _debugmsg_observed_input_pre_codeobject();
        #endif

	}
        

	brian_end();
        

	return 0;
}