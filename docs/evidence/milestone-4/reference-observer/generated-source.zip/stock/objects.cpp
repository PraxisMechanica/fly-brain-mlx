

#include "objects.h"
#include "synapses_classes.h"
#include "brianlib/clocks.h"
#include "brianlib/dynamic_array.h"
#include "brianlib/stdint_compat.h"
#include "network.h"
#include<random>
#include<vector>
#include<iostream>
#include<fstream>
#include<map>
#include<tuple>
#include<cstdlib>
#include<string>

namespace brian {

std::string results_dir = "results/";  // can be overwritten by --results_dir command line arg

// For multhreading, we need one generator for each thread. We also create a distribution for
// each thread, even though this is not strictly necessary for the uniform distribution, as
// the distribution is stateless.
std::vector< RandomGenerator > _random_generators;

//////////////// networks /////////////////
Network observed_network;

void set_variable_from_value(std::string varname, char* var_pointer, size_t size, char value) {
    #ifdef DEBUG
    std::cout << "Setting '" << varname << "' to " << (value == 1 ? "True" : "False") << std::endl;
    #endif
    std::fill(var_pointer, var_pointer+size, value);
}

template<class T> void set_variable_from_value(std::string varname, T* var_pointer, size_t size, T value) {
    #ifdef DEBUG
    std::cout << "Setting '" << varname << "' to " << value << std::endl;
    #endif
    std::fill(var_pointer, var_pointer+size, value);
}

template<class T> void set_variable_from_file(std::string varname, T* var_pointer, size_t data_size, std::string filename) {
    ifstream f;
    streampos size;
    #ifdef DEBUG
    std::cout << "Setting '" << varname << "' from file '" << filename << "'" << std::endl;
    #endif
    f.open(filename, ios::in | ios::binary | ios::ate);
    size = f.tellg();
    if (size != data_size) {
        std::cerr << "Error reading '" << filename << "': file size " << size << " does not match expected size " << data_size << std::endl;
        return;
    }
    f.seekg(0, ios::beg);
    if (f.is_open())
        f.read(reinterpret_cast<char *>(var_pointer), data_size);
    else
        std::cerr << "Could not read '" << filename << "'" << std::endl;
    if (f.fail())
        std::cerr << "Error reading '" << filename << "'" << std::endl;
}

//////////////// set arrays by name ///////
void set_variable_by_name(std::string name, std::string s_value) {
    size_t var_size;
    size_t data_size;
    // C-style or Python-style capitalization is allowed for boolean values
    if (s_value == "true" || s_value == "True")
        s_value = "1";
    else if (s_value == "false" || s_value == "False")
        s_value = "0";
    // non-dynamic arrays
    if (name == "observed_neurons._spikespace") {
        var_size = 7;
        data_size = 7*sizeof(int32_t);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<int32_t>(name, _array_observed_neurons__spikespace, var_size, (int32_t)atoi(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_observed_neurons__spikespace, data_size, s_value);
        }
        return;
    }
    if (name == "observed_neurons.g") {
        var_size = 6;
        data_size = 6*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_observed_neurons_g, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_observed_neurons_g, data_size, s_value);
        }
        return;
    }
    if (name == "observed_neurons.lastspike") {
        var_size = 6;
        data_size = 6*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_observed_neurons_lastspike, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_observed_neurons_lastspike, data_size, s_value);
        }
        return;
    }
    if (name == "observed_neurons.not_refractory") {
        var_size = 6;
        data_size = 6*sizeof(char);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value(name, _array_observed_neurons_not_refractory, var_size, (char)atoi(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_observed_neurons_not_refractory, data_size, s_value);
        }
        return;
    }
    if (name == "observed_neurons.rfc") {
        var_size = 6;
        data_size = 6*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_observed_neurons_rfc, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_observed_neurons_rfc, data_size, s_value);
        }
        return;
    }
    if (name == "observed_neurons.v") {
        var_size = 6;
        data_size = 6*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_observed_neurons_v, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_observed_neurons_v, data_size, s_value);
        }
        return;
    }
    if (name == "observed_source._spikespace") {
        var_size = 4;
        data_size = 4*sizeof(int32_t);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<int32_t>(name, _array_observed_source__spikespace, var_size, (int32_t)atoi(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_observed_source__spikespace, data_size, s_value);
        }
        return;
    }
    // dynamic arrays (1d)
    if (name == "observed_input.delay") {
        var_size = _dynamic_array_observed_input_delay.size();
        data_size = var_size*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, &_dynamic_array_observed_input_delay[0], var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, &_dynamic_array_observed_input_delay[0], data_size, s_value);
        }
        return;
    }
    if (name == "observed_recurrent.delay") {
        var_size = _dynamic_array_observed_recurrent_delay.size();
        data_size = var_size*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, &_dynamic_array_observed_recurrent_delay[0], var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, &_dynamic_array_observed_recurrent_delay[0], data_size, s_value);
        }
        return;
    }
    if (name == "observed_recurrent.w") {
        var_size = _dynamic_array_observed_recurrent_w.size();
        data_size = var_size*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, &_dynamic_array_observed_recurrent_w[0], var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, &_dynamic_array_observed_recurrent_w[0], data_size, s_value);
        }
        return;
    }
    std::cerr << "Cannot set unknown variable '" << name << "'." << std::endl;
    exit(1);
}
//////////////// arrays ///////////////////
double * _array_defaultclock_dt;
const int _num__array_defaultclock_dt = 1;
double * _array_defaultclock_t;
const int _num__array_defaultclock_t = 1;
int64_t * _array_defaultclock_timestep;
const int _num__array_defaultclock_timestep = 1;
int32_t * _array_observed_before__indices;
const int _num__array_observed_before__indices = 6;
double * _array_observed_before_g;
const int _num__array_observed_before_g = (0, 6);
int32_t * _array_observed_before_N;
const int _num__array_observed_before_N = 1;
char * _array_observed_before_not_refractory;
const int _num__array_observed_before_not_refractory = (0, 6);
double * _array_observed_before_v;
const int _num__array_observed_before_v = (0, 6);
int32_t * _array_observed_end__indices;
const int _num__array_observed_end__indices = 6;
double * _array_observed_end_g;
const int _num__array_observed_end_g = (0, 6);
double * _array_observed_end_lastspike;
const int _num__array_observed_end_lastspike = (0, 6);
int32_t * _array_observed_end_N;
const int _num__array_observed_end_N = 1;
char * _array_observed_end_not_refractory;
const int _num__array_observed_end_not_refractory = (0, 6);
double * _array_observed_end_v;
const int _num__array_observed_end_v = (0, 6);
int32_t * _array_observed_input_N;
const int _num__array_observed_input_N = 1;
int32_t * _array_observed_input_sources;
const int _num__array_observed_input_sources = 3;
int32_t * _array_observed_input_targets;
const int _num__array_observed_input_targets = 3;
int32_t * _array_observed_neurons__spikespace;
const int _num__array_observed_neurons__spikespace = 7;
double * _array_observed_neurons_g;
const int _num__array_observed_neurons_g = 6;
int32_t * _array_observed_neurons_i;
const int _num__array_observed_neurons_i = 6;
double * _array_observed_neurons_lastspike;
const int _num__array_observed_neurons_lastspike = 6;
char * _array_observed_neurons_not_refractory;
const int _num__array_observed_neurons_not_refractory = 6;
double * _array_observed_neurons_rfc;
const int _num__array_observed_neurons_rfc = 6;
double * _array_observed_neurons_v;
const int _num__array_observed_neurons_v = 6;
int32_t * _array_observed_pre__indices;
const int _num__array_observed_pre__indices = 6;
double * _array_observed_pre_g;
const int _num__array_observed_pre_g = (0, 6);
int32_t * _array_observed_pre_N;
const int _num__array_observed_pre_N = 1;
char * _array_observed_pre_not_refractory;
const int _num__array_observed_pre_not_refractory = (0, 6);
double * _array_observed_pre_v;
const int _num__array_observed_pre_v = (0, 6);
int32_t * _array_observed_recurrent_N;
const int _num__array_observed_recurrent_N = 1;
int32_t * _array_observed_recurrent_sources;
const int _num__array_observed_recurrent_sources = 8;
int32_t * _array_observed_recurrent_targets;
const int _num__array_observed_recurrent_targets = 8;
int32_t * _array_observed_source__lastindex;
const int _num__array_observed_source__lastindex = 1;
int32_t * _array_observed_source__period_bins;
const int _num__array_observed_source__period_bins = 1;
int32_t * _array_observed_source__spikespace;
const int _num__array_observed_source__spikespace = 4;
int32_t * _array_observed_source_i;
const int _num__array_observed_source_i = 3;
double * _array_observed_source_period;
const int _num__array_observed_source_period = 1;
int32_t * _array_spikemonitor__source_idx;
const int _num__array_spikemonitor__source_idx = 6;
int32_t * _array_spikemonitor_count;
const int _num__array_spikemonitor_count = 6;
int32_t * _array_spikemonitor_N;
const int _num__array_spikemonitor_N = 1;

//////////////// dynamic arrays 1d /////////
std::vector<double> _dynamic_array_observed_before_t;
std::vector<double> _dynamic_array_observed_end_t;
std::vector<int32_t> _dynamic_array_observed_input__synaptic_post;
std::vector<int32_t> _dynamic_array_observed_input__synaptic_pre;
std::vector<double> _dynamic_array_observed_input_delay;
std::vector<int32_t> _dynamic_array_observed_input_N_incoming;
std::vector<int32_t> _dynamic_array_observed_input_N_outgoing;
std::vector<double> _dynamic_array_observed_pre_t;
std::vector<int32_t> _dynamic_array_observed_recurrent__synaptic_post;
std::vector<int32_t> _dynamic_array_observed_recurrent__synaptic_pre;
std::vector<double> _dynamic_array_observed_recurrent_delay;
std::vector<int32_t> _dynamic_array_observed_recurrent_N_incoming;
std::vector<int32_t> _dynamic_array_observed_recurrent_N_outgoing;
std::vector<double> _dynamic_array_observed_recurrent_w;
std::vector<int32_t> _dynamic_array_observed_source__timebins;
std::vector<int32_t> _dynamic_array_observed_source_neuron_index;
std::vector<int32_t> _dynamic_array_observed_source_spike_number;
std::vector<double> _dynamic_array_observed_source_spike_time;
std::vector<int32_t> _dynamic_array_spikemonitor_i;
std::vector<double> _dynamic_array_spikemonitor_t;

//////////////// dynamic arrays 2d /////////
DynamicArray2D<double> _dynamic_array_observed_before_g;
DynamicArray2D<char> _dynamic_array_observed_before_not_refractory;
DynamicArray2D<double> _dynamic_array_observed_before_v;
DynamicArray2D<double> _dynamic_array_observed_end_g;
DynamicArray2D<double> _dynamic_array_observed_end_lastspike;
DynamicArray2D<char> _dynamic_array_observed_end_not_refractory;
DynamicArray2D<double> _dynamic_array_observed_end_v;
DynamicArray2D<double> _dynamic_array_observed_pre_g;
DynamicArray2D<char> _dynamic_array_observed_pre_not_refractory;
DynamicArray2D<double> _dynamic_array_observed_pre_v;

/////////////// static arrays /////////////
int32_t * _static_array__array_observed_before__indices;
const int _num__static_array__array_observed_before__indices = 6;
int32_t * _static_array__array_observed_end__indices;
const int _num__static_array__array_observed_end__indices = 6;
int32_t * _static_array__array_observed_input_sources;
const int _num__static_array__array_observed_input_sources = 3;
int32_t * _static_array__array_observed_input_targets;
const int _num__static_array__array_observed_input_targets = 3;
double * _static_array__array_observed_neurons_g;
const int _num__static_array__array_observed_neurons_g = 6;
double * _static_array__array_observed_neurons_lastspike;
const int _num__static_array__array_observed_neurons_lastspike = 6;
double * _static_array__array_observed_neurons_rfc;
const int _num__static_array__array_observed_neurons_rfc = 6;
double * _static_array__array_observed_neurons_v;
const int _num__static_array__array_observed_neurons_v = 6;
int32_t * _static_array__array_observed_pre__indices;
const int _num__static_array__array_observed_pre__indices = 6;
int32_t * _static_array__array_observed_recurrent_sources;
const int _num__static_array__array_observed_recurrent_sources = 8;
int32_t * _static_array__array_observed_recurrent_targets;
const int _num__static_array__array_observed_recurrent_targets = 8;
double * _static_array__dynamic_array_observed_recurrent_w;
const int _num__static_array__dynamic_array_observed_recurrent_w = 8;
int32_t * _static_array__dynamic_array_observed_source__timebins;
const int _num__static_array__dynamic_array_observed_source__timebins = 75;
int64_t * _static_array__dynamic_array_observed_source_neuron_index;
const int _num__static_array__dynamic_array_observed_source_neuron_index = 75;
int64_t * _static_array__dynamic_array_observed_source_spike_number;
const int _num__static_array__dynamic_array_observed_source_spike_number = 75;
double * _static_array__dynamic_array_observed_source_spike_time;
const int _num__static_array__dynamic_array_observed_source_spike_time = 75;

//////////////// synapses /////////////////
// observed_input
SynapticPathway observed_input_pre(
    _dynamic_array_observed_input__synaptic_pre,
    0, 3);
// observed_recurrent
SynapticPathway observed_recurrent_pre(
    _dynamic_array_observed_recurrent__synaptic_pre,
    0, 6);

//////////////// clocks ///////////////////
Clock defaultclock;  // attributes will be set in run.cpp

// Profiling information for each code object
}

void _init_arrays()
{
    using namespace brian;

    // Arrays initialized to 0
    _array_defaultclock_dt = new double[1];
    
    for(int i=0; i<1; i++) _array_defaultclock_dt[i] = 0;

    _array_defaultclock_t = new double[1];
    
    for(int i=0; i<1; i++) _array_defaultclock_t[i] = 0;

    _array_defaultclock_timestep = new int64_t[1];
    
    for(int i=0; i<1; i++) _array_defaultclock_timestep[i] = 0;

    _array_observed_before__indices = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_observed_before__indices[i] = 0;

    _array_observed_before_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_observed_before_N[i] = 0;

    _array_observed_end__indices = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_observed_end__indices[i] = 0;

    _array_observed_end_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_observed_end_N[i] = 0;

    _array_observed_input_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_observed_input_N[i] = 0;

    _array_observed_input_sources = new int32_t[3];
    
    for(int i=0; i<3; i++) _array_observed_input_sources[i] = 0;

    _array_observed_input_targets = new int32_t[3];
    
    for(int i=0; i<3; i++) _array_observed_input_targets[i] = 0;

    _array_observed_neurons__spikespace = new int32_t[7];
    
    for(int i=0; i<7; i++) _array_observed_neurons__spikespace[i] = 0;

    _array_observed_neurons_g = new double[6];
    
    for(int i=0; i<6; i++) _array_observed_neurons_g[i] = 0;

    _array_observed_neurons_i = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_observed_neurons_i[i] = 0;

    _array_observed_neurons_lastspike = new double[6];
    
    for(int i=0; i<6; i++) _array_observed_neurons_lastspike[i] = 0;

    _array_observed_neurons_not_refractory = new char[6];
    
    for(int i=0; i<6; i++) _array_observed_neurons_not_refractory[i] = 0;

    _array_observed_neurons_rfc = new double[6];
    
    for(int i=0; i<6; i++) _array_observed_neurons_rfc[i] = 0;

    _array_observed_neurons_v = new double[6];
    
    for(int i=0; i<6; i++) _array_observed_neurons_v[i] = 0;

    _array_observed_pre__indices = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_observed_pre__indices[i] = 0;

    _array_observed_pre_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_observed_pre_N[i] = 0;

    _array_observed_recurrent_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_observed_recurrent_N[i] = 0;

    _array_observed_recurrent_sources = new int32_t[8];
    
    for(int i=0; i<8; i++) _array_observed_recurrent_sources[i] = 0;

    _array_observed_recurrent_targets = new int32_t[8];
    
    for(int i=0; i<8; i++) _array_observed_recurrent_targets[i] = 0;

    _array_observed_source__lastindex = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_observed_source__lastindex[i] = 0;

    _array_observed_source__period_bins = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_observed_source__period_bins[i] = 0;

    _array_observed_source__spikespace = new int32_t[4];
    
    for(int i=0; i<4; i++) _array_observed_source__spikespace[i] = 0;

    _array_observed_source_i = new int32_t[3];
    
    for(int i=0; i<3; i++) _array_observed_source_i[i] = 0;

    _array_observed_source_period = new double[1];
    
    for(int i=0; i<1; i++) _array_observed_source_period[i] = 0;

    _array_spikemonitor__source_idx = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_spikemonitor__source_idx[i] = 0;

    _array_spikemonitor_count = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_spikemonitor_count[i] = 0;

    _array_spikemonitor_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_spikemonitor_N[i] = 0;

    _dynamic_array_observed_recurrent_delay.resize(1);
    
    for(int i=0; i<1; i++) _dynamic_array_observed_recurrent_delay[i] = 0;

    _dynamic_array_observed_source__timebins.resize(75);
    
    for(int i=0; i<75; i++) _dynamic_array_observed_source__timebins[i] = 0;


    // Arrays initialized to an "arange"
    _array_observed_neurons_i = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_observed_neurons_i[i] = 0 + i;

    _array_observed_source_i = new int32_t[3];
    
    for(int i=0; i<3; i++) _array_observed_source_i[i] = 0 + i;

    _array_spikemonitor__source_idx = new int32_t[6];
    
    for(int i=0; i<6; i++) _array_spikemonitor__source_idx[i] = 0 + i;


    // static arrays
    _static_array__array_observed_before__indices = new int32_t[6];
    _static_array__array_observed_end__indices = new int32_t[6];
    _static_array__array_observed_input_sources = new int32_t[3];
    _static_array__array_observed_input_targets = new int32_t[3];
    _static_array__array_observed_neurons_g = new double[6];
    _static_array__array_observed_neurons_lastspike = new double[6];
    _static_array__array_observed_neurons_rfc = new double[6];
    _static_array__array_observed_neurons_v = new double[6];
    _static_array__array_observed_pre__indices = new int32_t[6];
    _static_array__array_observed_recurrent_sources = new int32_t[8];
    _static_array__array_observed_recurrent_targets = new int32_t[8];
    _static_array__dynamic_array_observed_recurrent_w = new double[8];
    _static_array__dynamic_array_observed_source__timebins = new int32_t[75];
    _static_array__dynamic_array_observed_source_neuron_index = new int64_t[75];
    _static_array__dynamic_array_observed_source_spike_number = new int64_t[75];
    _static_array__dynamic_array_observed_source_spike_time = new double[75];

    // Random number generator states
    std::random_device rd;
    for (int i=0; i<1; i++)
        _random_generators.push_back(RandomGenerator());
}

void _load_arrays()
{
    using namespace brian;

    ifstream f_static_array__array_observed_before__indices;
    f_static_array__array_observed_before__indices.open("static_arrays/_static_array__array_observed_before__indices", ios::in | ios::binary);
    if(f_static_array__array_observed_before__indices.is_open())
    {
        f_static_array__array_observed_before__indices.read(reinterpret_cast<char*>(_static_array__array_observed_before__indices), 6*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_before__indices." << endl;
    }
    ifstream f_static_array__array_observed_end__indices;
    f_static_array__array_observed_end__indices.open("static_arrays/_static_array__array_observed_end__indices", ios::in | ios::binary);
    if(f_static_array__array_observed_end__indices.is_open())
    {
        f_static_array__array_observed_end__indices.read(reinterpret_cast<char*>(_static_array__array_observed_end__indices), 6*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_end__indices." << endl;
    }
    ifstream f_static_array__array_observed_input_sources;
    f_static_array__array_observed_input_sources.open("static_arrays/_static_array__array_observed_input_sources", ios::in | ios::binary);
    if(f_static_array__array_observed_input_sources.is_open())
    {
        f_static_array__array_observed_input_sources.read(reinterpret_cast<char*>(_static_array__array_observed_input_sources), 3*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_input_sources." << endl;
    }
    ifstream f_static_array__array_observed_input_targets;
    f_static_array__array_observed_input_targets.open("static_arrays/_static_array__array_observed_input_targets", ios::in | ios::binary);
    if(f_static_array__array_observed_input_targets.is_open())
    {
        f_static_array__array_observed_input_targets.read(reinterpret_cast<char*>(_static_array__array_observed_input_targets), 3*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_input_targets." << endl;
    }
    ifstream f_static_array__array_observed_neurons_g;
    f_static_array__array_observed_neurons_g.open("static_arrays/_static_array__array_observed_neurons_g", ios::in | ios::binary);
    if(f_static_array__array_observed_neurons_g.is_open())
    {
        f_static_array__array_observed_neurons_g.read(reinterpret_cast<char*>(_static_array__array_observed_neurons_g), 6*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_neurons_g." << endl;
    }
    ifstream f_static_array__array_observed_neurons_lastspike;
    f_static_array__array_observed_neurons_lastspike.open("static_arrays/_static_array__array_observed_neurons_lastspike", ios::in | ios::binary);
    if(f_static_array__array_observed_neurons_lastspike.is_open())
    {
        f_static_array__array_observed_neurons_lastspike.read(reinterpret_cast<char*>(_static_array__array_observed_neurons_lastspike), 6*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_neurons_lastspike." << endl;
    }
    ifstream f_static_array__array_observed_neurons_rfc;
    f_static_array__array_observed_neurons_rfc.open("static_arrays/_static_array__array_observed_neurons_rfc", ios::in | ios::binary);
    if(f_static_array__array_observed_neurons_rfc.is_open())
    {
        f_static_array__array_observed_neurons_rfc.read(reinterpret_cast<char*>(_static_array__array_observed_neurons_rfc), 6*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_neurons_rfc." << endl;
    }
    ifstream f_static_array__array_observed_neurons_v;
    f_static_array__array_observed_neurons_v.open("static_arrays/_static_array__array_observed_neurons_v", ios::in | ios::binary);
    if(f_static_array__array_observed_neurons_v.is_open())
    {
        f_static_array__array_observed_neurons_v.read(reinterpret_cast<char*>(_static_array__array_observed_neurons_v), 6*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_neurons_v." << endl;
    }
    ifstream f_static_array__array_observed_pre__indices;
    f_static_array__array_observed_pre__indices.open("static_arrays/_static_array__array_observed_pre__indices", ios::in | ios::binary);
    if(f_static_array__array_observed_pre__indices.is_open())
    {
        f_static_array__array_observed_pre__indices.read(reinterpret_cast<char*>(_static_array__array_observed_pre__indices), 6*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_pre__indices." << endl;
    }
    ifstream f_static_array__array_observed_recurrent_sources;
    f_static_array__array_observed_recurrent_sources.open("static_arrays/_static_array__array_observed_recurrent_sources", ios::in | ios::binary);
    if(f_static_array__array_observed_recurrent_sources.is_open())
    {
        f_static_array__array_observed_recurrent_sources.read(reinterpret_cast<char*>(_static_array__array_observed_recurrent_sources), 8*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_recurrent_sources." << endl;
    }
    ifstream f_static_array__array_observed_recurrent_targets;
    f_static_array__array_observed_recurrent_targets.open("static_arrays/_static_array__array_observed_recurrent_targets", ios::in | ios::binary);
    if(f_static_array__array_observed_recurrent_targets.is_open())
    {
        f_static_array__array_observed_recurrent_targets.read(reinterpret_cast<char*>(_static_array__array_observed_recurrent_targets), 8*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_observed_recurrent_targets." << endl;
    }
    ifstream f_static_array__dynamic_array_observed_recurrent_w;
    f_static_array__dynamic_array_observed_recurrent_w.open("static_arrays/_static_array__dynamic_array_observed_recurrent_w", ios::in | ios::binary);
    if(f_static_array__dynamic_array_observed_recurrent_w.is_open())
    {
        f_static_array__dynamic_array_observed_recurrent_w.read(reinterpret_cast<char*>(_static_array__dynamic_array_observed_recurrent_w), 8*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_observed_recurrent_w." << endl;
    }
    ifstream f_static_array__dynamic_array_observed_source__timebins;
    f_static_array__dynamic_array_observed_source__timebins.open("static_arrays/_static_array__dynamic_array_observed_source__timebins", ios::in | ios::binary);
    if(f_static_array__dynamic_array_observed_source__timebins.is_open())
    {
        f_static_array__dynamic_array_observed_source__timebins.read(reinterpret_cast<char*>(_static_array__dynamic_array_observed_source__timebins), 75*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_observed_source__timebins." << endl;
    }
    ifstream f_static_array__dynamic_array_observed_source_neuron_index;
    f_static_array__dynamic_array_observed_source_neuron_index.open("static_arrays/_static_array__dynamic_array_observed_source_neuron_index", ios::in | ios::binary);
    if(f_static_array__dynamic_array_observed_source_neuron_index.is_open())
    {
        f_static_array__dynamic_array_observed_source_neuron_index.read(reinterpret_cast<char*>(_static_array__dynamic_array_observed_source_neuron_index), 75*sizeof(int64_t));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_observed_source_neuron_index." << endl;
    }
    ifstream f_static_array__dynamic_array_observed_source_spike_number;
    f_static_array__dynamic_array_observed_source_spike_number.open("static_arrays/_static_array__dynamic_array_observed_source_spike_number", ios::in | ios::binary);
    if(f_static_array__dynamic_array_observed_source_spike_number.is_open())
    {
        f_static_array__dynamic_array_observed_source_spike_number.read(reinterpret_cast<char*>(_static_array__dynamic_array_observed_source_spike_number), 75*sizeof(int64_t));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_observed_source_spike_number." << endl;
    }
    ifstream f_static_array__dynamic_array_observed_source_spike_time;
    f_static_array__dynamic_array_observed_source_spike_time.open("static_arrays/_static_array__dynamic_array_observed_source_spike_time", ios::in | ios::binary);
    if(f_static_array__dynamic_array_observed_source_spike_time.is_open())
    {
        f_static_array__dynamic_array_observed_source_spike_time.read(reinterpret_cast<char*>(_static_array__dynamic_array_observed_source_spike_time), 75*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_observed_source_spike_time." << endl;
    }
}

void _write_arrays()
{
    using namespace brian;

    ofstream outfile__array_defaultclock_dt;
    outfile__array_defaultclock_dt.open(results_dir + "_array_defaultclock_dt_1978099143", ios::binary | ios::out);
    if(outfile__array_defaultclock_dt.is_open())
    {
        outfile__array_defaultclock_dt.write(reinterpret_cast<char*>(_array_defaultclock_dt), 1*sizeof(_array_defaultclock_dt[0]));
        outfile__array_defaultclock_dt.close();
    } else
    {
        std::cout << "Error writing output file for _array_defaultclock_dt." << endl;
    }
    ofstream outfile__array_defaultclock_t;
    outfile__array_defaultclock_t.open(results_dir + "_array_defaultclock_t_2669362164", ios::binary | ios::out);
    if(outfile__array_defaultclock_t.is_open())
    {
        outfile__array_defaultclock_t.write(reinterpret_cast<char*>(_array_defaultclock_t), 1*sizeof(_array_defaultclock_t[0]));
        outfile__array_defaultclock_t.close();
    } else
    {
        std::cout << "Error writing output file for _array_defaultclock_t." << endl;
    }
    ofstream outfile__array_defaultclock_timestep;
    outfile__array_defaultclock_timestep.open(results_dir + "_array_defaultclock_timestep_144223508", ios::binary | ios::out);
    if(outfile__array_defaultclock_timestep.is_open())
    {
        outfile__array_defaultclock_timestep.write(reinterpret_cast<char*>(_array_defaultclock_timestep), 1*sizeof(_array_defaultclock_timestep[0]));
        outfile__array_defaultclock_timestep.close();
    } else
    {
        std::cout << "Error writing output file for _array_defaultclock_timestep." << endl;
    }
    ofstream outfile__array_observed_before__indices;
    outfile__array_observed_before__indices.open(results_dir + "_array_observed_before__indices_3767641345", ios::binary | ios::out);
    if(outfile__array_observed_before__indices.is_open())
    {
        outfile__array_observed_before__indices.write(reinterpret_cast<char*>(_array_observed_before__indices), 6*sizeof(_array_observed_before__indices[0]));
        outfile__array_observed_before__indices.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_before__indices." << endl;
    }
    ofstream outfile__array_observed_before_N;
    outfile__array_observed_before_N.open(results_dir + "_array_observed_before_N_4269763053", ios::binary | ios::out);
    if(outfile__array_observed_before_N.is_open())
    {
        outfile__array_observed_before_N.write(reinterpret_cast<char*>(_array_observed_before_N), 1*sizeof(_array_observed_before_N[0]));
        outfile__array_observed_before_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_before_N." << endl;
    }
    ofstream outfile__array_observed_end__indices;
    outfile__array_observed_end__indices.open(results_dir + "_array_observed_end__indices_4046847642", ios::binary | ios::out);
    if(outfile__array_observed_end__indices.is_open())
    {
        outfile__array_observed_end__indices.write(reinterpret_cast<char*>(_array_observed_end__indices), 6*sizeof(_array_observed_end__indices[0]));
        outfile__array_observed_end__indices.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_end__indices." << endl;
    }
    ofstream outfile__array_observed_end_N;
    outfile__array_observed_end_N.open(results_dir + "_array_observed_end_N_3503429746", ios::binary | ios::out);
    if(outfile__array_observed_end_N.is_open())
    {
        outfile__array_observed_end_N.write(reinterpret_cast<char*>(_array_observed_end_N), 1*sizeof(_array_observed_end_N[0]));
        outfile__array_observed_end_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_end_N." << endl;
    }
    ofstream outfile__array_observed_input_N;
    outfile__array_observed_input_N.open(results_dir + "_array_observed_input_N_1464342569", ios::binary | ios::out);
    if(outfile__array_observed_input_N.is_open())
    {
        outfile__array_observed_input_N.write(reinterpret_cast<char*>(_array_observed_input_N), 1*sizeof(_array_observed_input_N[0]));
        outfile__array_observed_input_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_input_N." << endl;
    }
    ofstream outfile__array_observed_input_sources;
    outfile__array_observed_input_sources.open(results_dir + "_array_observed_input_sources_2913457489", ios::binary | ios::out);
    if(outfile__array_observed_input_sources.is_open())
    {
        outfile__array_observed_input_sources.write(reinterpret_cast<char*>(_array_observed_input_sources), 3*sizeof(_array_observed_input_sources[0]));
        outfile__array_observed_input_sources.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_input_sources." << endl;
    }
    ofstream outfile__array_observed_input_targets;
    outfile__array_observed_input_targets.open(results_dir + "_array_observed_input_targets_3501829808", ios::binary | ios::out);
    if(outfile__array_observed_input_targets.is_open())
    {
        outfile__array_observed_input_targets.write(reinterpret_cast<char*>(_array_observed_input_targets), 3*sizeof(_array_observed_input_targets[0]));
        outfile__array_observed_input_targets.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_input_targets." << endl;
    }
    ofstream outfile__array_observed_neurons__spikespace;
    outfile__array_observed_neurons__spikespace.open(results_dir + "_array_observed_neurons__spikespace_2592771597", ios::binary | ios::out);
    if(outfile__array_observed_neurons__spikespace.is_open())
    {
        outfile__array_observed_neurons__spikespace.write(reinterpret_cast<char*>(_array_observed_neurons__spikespace), 7*sizeof(_array_observed_neurons__spikespace[0]));
        outfile__array_observed_neurons__spikespace.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_neurons__spikespace." << endl;
    }
    ofstream outfile__array_observed_neurons_g;
    outfile__array_observed_neurons_g.open(results_dir + "_array_observed_neurons_g_4247049854", ios::binary | ios::out);
    if(outfile__array_observed_neurons_g.is_open())
    {
        outfile__array_observed_neurons_g.write(reinterpret_cast<char*>(_array_observed_neurons_g), 6*sizeof(_array_observed_neurons_g[0]));
        outfile__array_observed_neurons_g.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_neurons_g." << endl;
    }
    ofstream outfile__array_observed_neurons_i;
    outfile__array_observed_neurons_i.open(results_dir + "_array_observed_neurons_i_446495609", ios::binary | ios::out);
    if(outfile__array_observed_neurons_i.is_open())
    {
        outfile__array_observed_neurons_i.write(reinterpret_cast<char*>(_array_observed_neurons_i), 6*sizeof(_array_observed_neurons_i[0]));
        outfile__array_observed_neurons_i.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_neurons_i." << endl;
    }
    ofstream outfile__array_observed_neurons_lastspike;
    outfile__array_observed_neurons_lastspike.open(results_dir + "_array_observed_neurons_lastspike_3268407158", ios::binary | ios::out);
    if(outfile__array_observed_neurons_lastspike.is_open())
    {
        outfile__array_observed_neurons_lastspike.write(reinterpret_cast<char*>(_array_observed_neurons_lastspike), 6*sizeof(_array_observed_neurons_lastspike[0]));
        outfile__array_observed_neurons_lastspike.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_neurons_lastspike." << endl;
    }
    ofstream outfile__array_observed_neurons_not_refractory;
    outfile__array_observed_neurons_not_refractory.open(results_dir + "_array_observed_neurons_not_refractory_1674084268", ios::binary | ios::out);
    if(outfile__array_observed_neurons_not_refractory.is_open())
    {
        outfile__array_observed_neurons_not_refractory.write(reinterpret_cast<char*>(_array_observed_neurons_not_refractory), 6*sizeof(_array_observed_neurons_not_refractory[0]));
        outfile__array_observed_neurons_not_refractory.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_neurons_not_refractory." << endl;
    }
    ofstream outfile__array_observed_neurons_rfc;
    outfile__array_observed_neurons_rfc.open(results_dir + "_array_observed_neurons_rfc_1646547226", ios::binary | ios::out);
    if(outfile__array_observed_neurons_rfc.is_open())
    {
        outfile__array_observed_neurons_rfc.write(reinterpret_cast<char*>(_array_observed_neurons_rfc), 6*sizeof(_array_observed_neurons_rfc[0]));
        outfile__array_observed_neurons_rfc.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_neurons_rfc." << endl;
    }
    ofstream outfile__array_observed_neurons_v;
    outfile__array_observed_neurons_v.open(results_dir + "_array_observed_neurons_v_2543122060", ios::binary | ios::out);
    if(outfile__array_observed_neurons_v.is_open())
    {
        outfile__array_observed_neurons_v.write(reinterpret_cast<char*>(_array_observed_neurons_v), 6*sizeof(_array_observed_neurons_v[0]));
        outfile__array_observed_neurons_v.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_neurons_v." << endl;
    }
    ofstream outfile__array_observed_pre__indices;
    outfile__array_observed_pre__indices.open(results_dir + "_array_observed_pre__indices_782260548", ios::binary | ios::out);
    if(outfile__array_observed_pre__indices.is_open())
    {
        outfile__array_observed_pre__indices.write(reinterpret_cast<char*>(_array_observed_pre__indices), 6*sizeof(_array_observed_pre__indices[0]));
        outfile__array_observed_pre__indices.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_pre__indices." << endl;
    }
    ofstream outfile__array_observed_pre_N;
    outfile__array_observed_pre_N.open(results_dir + "_array_observed_pre_N_1675592336", ios::binary | ios::out);
    if(outfile__array_observed_pre_N.is_open())
    {
        outfile__array_observed_pre_N.write(reinterpret_cast<char*>(_array_observed_pre_N), 1*sizeof(_array_observed_pre_N[0]));
        outfile__array_observed_pre_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_pre_N." << endl;
    }
    ofstream outfile__array_observed_recurrent_N;
    outfile__array_observed_recurrent_N.open(results_dir + "_array_observed_recurrent_N_2301319809", ios::binary | ios::out);
    if(outfile__array_observed_recurrent_N.is_open())
    {
        outfile__array_observed_recurrent_N.write(reinterpret_cast<char*>(_array_observed_recurrent_N), 1*sizeof(_array_observed_recurrent_N[0]));
        outfile__array_observed_recurrent_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_recurrent_N." << endl;
    }
    ofstream outfile__array_observed_recurrent_sources;
    outfile__array_observed_recurrent_sources.open(results_dir + "_array_observed_recurrent_sources_3562999084", ios::binary | ios::out);
    if(outfile__array_observed_recurrent_sources.is_open())
    {
        outfile__array_observed_recurrent_sources.write(reinterpret_cast<char*>(_array_observed_recurrent_sources), 8*sizeof(_array_observed_recurrent_sources[0]));
        outfile__array_observed_recurrent_sources.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_recurrent_sources." << endl;
    }
    ofstream outfile__array_observed_recurrent_targets;
    outfile__array_observed_recurrent_targets.open(results_dir + "_array_observed_recurrent_targets_2839639757", ios::binary | ios::out);
    if(outfile__array_observed_recurrent_targets.is_open())
    {
        outfile__array_observed_recurrent_targets.write(reinterpret_cast<char*>(_array_observed_recurrent_targets), 8*sizeof(_array_observed_recurrent_targets[0]));
        outfile__array_observed_recurrent_targets.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_recurrent_targets." << endl;
    }
    ofstream outfile__array_observed_source__lastindex;
    outfile__array_observed_source__lastindex.open(results_dir + "_array_observed_source__lastindex_1005982299", ios::binary | ios::out);
    if(outfile__array_observed_source__lastindex.is_open())
    {
        outfile__array_observed_source__lastindex.write(reinterpret_cast<char*>(_array_observed_source__lastindex), 1*sizeof(_array_observed_source__lastindex[0]));
        outfile__array_observed_source__lastindex.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_source__lastindex." << endl;
    }
    ofstream outfile__array_observed_source__period_bins;
    outfile__array_observed_source__period_bins.open(results_dir + "_array_observed_source__period_bins_269881995", ios::binary | ios::out);
    if(outfile__array_observed_source__period_bins.is_open())
    {
        outfile__array_observed_source__period_bins.write(reinterpret_cast<char*>(_array_observed_source__period_bins), 1*sizeof(_array_observed_source__period_bins[0]));
        outfile__array_observed_source__period_bins.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_source__period_bins." << endl;
    }
    ofstream outfile__array_observed_source__spikespace;
    outfile__array_observed_source__spikespace.open(results_dir + "_array_observed_source__spikespace_2623371617", ios::binary | ios::out);
    if(outfile__array_observed_source__spikespace.is_open())
    {
        outfile__array_observed_source__spikespace.write(reinterpret_cast<char*>(_array_observed_source__spikespace), 4*sizeof(_array_observed_source__spikespace[0]));
        outfile__array_observed_source__spikespace.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_source__spikespace." << endl;
    }
    ofstream outfile__array_observed_source_i;
    outfile__array_observed_source_i.open(results_dir + "_array_observed_source_i_3129188737", ios::binary | ios::out);
    if(outfile__array_observed_source_i.is_open())
    {
        outfile__array_observed_source_i.write(reinterpret_cast<char*>(_array_observed_source_i), 3*sizeof(_array_observed_source_i[0]));
        outfile__array_observed_source_i.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_source_i." << endl;
    }
    ofstream outfile__array_observed_source_period;
    outfile__array_observed_source_period.open(results_dir + "_array_observed_source_period_430641739", ios::binary | ios::out);
    if(outfile__array_observed_source_period.is_open())
    {
        outfile__array_observed_source_period.write(reinterpret_cast<char*>(_array_observed_source_period), 1*sizeof(_array_observed_source_period[0]));
        outfile__array_observed_source_period.close();
    } else
    {
        std::cout << "Error writing output file for _array_observed_source_period." << endl;
    }
    ofstream outfile__array_spikemonitor__source_idx;
    outfile__array_spikemonitor__source_idx.open(results_dir + "_array_spikemonitor__source_idx_1477951789", ios::binary | ios::out);
    if(outfile__array_spikemonitor__source_idx.is_open())
    {
        outfile__array_spikemonitor__source_idx.write(reinterpret_cast<char*>(_array_spikemonitor__source_idx), 6*sizeof(_array_spikemonitor__source_idx[0]));
        outfile__array_spikemonitor__source_idx.close();
    } else
    {
        std::cout << "Error writing output file for _array_spikemonitor__source_idx." << endl;
    }
    ofstream outfile__array_spikemonitor_count;
    outfile__array_spikemonitor_count.open(results_dir + "_array_spikemonitor_count_598337445", ios::binary | ios::out);
    if(outfile__array_spikemonitor_count.is_open())
    {
        outfile__array_spikemonitor_count.write(reinterpret_cast<char*>(_array_spikemonitor_count), 6*sizeof(_array_spikemonitor_count[0]));
        outfile__array_spikemonitor_count.close();
    } else
    {
        std::cout << "Error writing output file for _array_spikemonitor_count." << endl;
    }
    ofstream outfile__array_spikemonitor_N;
    outfile__array_spikemonitor_N.open(results_dir + "_array_spikemonitor_N_225734567", ios::binary | ios::out);
    if(outfile__array_spikemonitor_N.is_open())
    {
        outfile__array_spikemonitor_N.write(reinterpret_cast<char*>(_array_spikemonitor_N), 1*sizeof(_array_spikemonitor_N[0]));
        outfile__array_spikemonitor_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_spikemonitor_N." << endl;
    }

    ofstream outfile__dynamic_array_observed_before_t;
    outfile__dynamic_array_observed_before_t.open(results_dir + "_dynamic_array_observed_before_t_3735314011", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_before_t.is_open())
    {
        if (! _dynamic_array_observed_before_t.empty() )
        {
            outfile__dynamic_array_observed_before_t.write(reinterpret_cast<char*>(&_dynamic_array_observed_before_t[0]), _dynamic_array_observed_before_t.size()*sizeof(_dynamic_array_observed_before_t[0]));
            outfile__dynamic_array_observed_before_t.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_before_t." << endl;
    }
    ofstream outfile__dynamic_array_observed_end_t;
    outfile__dynamic_array_observed_end_t.open(results_dir + "_dynamic_array_observed_end_t_3413259446", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_end_t.is_open())
    {
        if (! _dynamic_array_observed_end_t.empty() )
        {
            outfile__dynamic_array_observed_end_t.write(reinterpret_cast<char*>(&_dynamic_array_observed_end_t[0]), _dynamic_array_observed_end_t.size()*sizeof(_dynamic_array_observed_end_t[0]));
            outfile__dynamic_array_observed_end_t.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_end_t." << endl;
    }
    ofstream outfile__dynamic_array_observed_input__synaptic_post;
    outfile__dynamic_array_observed_input__synaptic_post.open(results_dir + "_dynamic_array_observed_input__synaptic_post_1961967930", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_input__synaptic_post.is_open())
    {
        if (! _dynamic_array_observed_input__synaptic_post.empty() )
        {
            outfile__dynamic_array_observed_input__synaptic_post.write(reinterpret_cast<char*>(&_dynamic_array_observed_input__synaptic_post[0]), _dynamic_array_observed_input__synaptic_post.size()*sizeof(_dynamic_array_observed_input__synaptic_post[0]));
            outfile__dynamic_array_observed_input__synaptic_post.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_input__synaptic_post." << endl;
    }
    ofstream outfile__dynamic_array_observed_input__synaptic_pre;
    outfile__dynamic_array_observed_input__synaptic_pre.open(results_dir + "_dynamic_array_observed_input__synaptic_pre_1145112988", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_input__synaptic_pre.is_open())
    {
        if (! _dynamic_array_observed_input__synaptic_pre.empty() )
        {
            outfile__dynamic_array_observed_input__synaptic_pre.write(reinterpret_cast<char*>(&_dynamic_array_observed_input__synaptic_pre[0]), _dynamic_array_observed_input__synaptic_pre.size()*sizeof(_dynamic_array_observed_input__synaptic_pre[0]));
            outfile__dynamic_array_observed_input__synaptic_pre.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_input__synaptic_pre." << endl;
    }
    ofstream outfile__dynamic_array_observed_input_delay;
    outfile__dynamic_array_observed_input_delay.open(results_dir + "_dynamic_array_observed_input_delay_1876716731", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_input_delay.is_open())
    {
        if (! _dynamic_array_observed_input_delay.empty() )
        {
            outfile__dynamic_array_observed_input_delay.write(reinterpret_cast<char*>(&_dynamic_array_observed_input_delay[0]), _dynamic_array_observed_input_delay.size()*sizeof(_dynamic_array_observed_input_delay[0]));
            outfile__dynamic_array_observed_input_delay.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_input_delay." << endl;
    }
    ofstream outfile__dynamic_array_observed_input_N_incoming;
    outfile__dynamic_array_observed_input_N_incoming.open(results_dir + "_dynamic_array_observed_input_N_incoming_4097193605", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_input_N_incoming.is_open())
    {
        if (! _dynamic_array_observed_input_N_incoming.empty() )
        {
            outfile__dynamic_array_observed_input_N_incoming.write(reinterpret_cast<char*>(&_dynamic_array_observed_input_N_incoming[0]), _dynamic_array_observed_input_N_incoming.size()*sizeof(_dynamic_array_observed_input_N_incoming[0]));
            outfile__dynamic_array_observed_input_N_incoming.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_input_N_incoming." << endl;
    }
    ofstream outfile__dynamic_array_observed_input_N_outgoing;
    outfile__dynamic_array_observed_input_N_outgoing.open(results_dir + "_dynamic_array_observed_input_N_outgoing_3542763103", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_input_N_outgoing.is_open())
    {
        if (! _dynamic_array_observed_input_N_outgoing.empty() )
        {
            outfile__dynamic_array_observed_input_N_outgoing.write(reinterpret_cast<char*>(&_dynamic_array_observed_input_N_outgoing[0]), _dynamic_array_observed_input_N_outgoing.size()*sizeof(_dynamic_array_observed_input_N_outgoing[0]));
            outfile__dynamic_array_observed_input_N_outgoing.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_input_N_outgoing." << endl;
    }
    ofstream outfile__dynamic_array_observed_pre_t;
    outfile__dynamic_array_observed_pre_t.open(results_dir + "_dynamic_array_observed_pre_t_2021633620", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_pre_t.is_open())
    {
        if (! _dynamic_array_observed_pre_t.empty() )
        {
            outfile__dynamic_array_observed_pre_t.write(reinterpret_cast<char*>(&_dynamic_array_observed_pre_t[0]), _dynamic_array_observed_pre_t.size()*sizeof(_dynamic_array_observed_pre_t[0]));
            outfile__dynamic_array_observed_pre_t.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_pre_t." << endl;
    }
    ofstream outfile__dynamic_array_observed_recurrent__synaptic_post;
    outfile__dynamic_array_observed_recurrent__synaptic_post.open(results_dir + "_dynamic_array_observed_recurrent__synaptic_post_298191383", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_recurrent__synaptic_post.is_open())
    {
        if (! _dynamic_array_observed_recurrent__synaptic_post.empty() )
        {
            outfile__dynamic_array_observed_recurrent__synaptic_post.write(reinterpret_cast<char*>(&_dynamic_array_observed_recurrent__synaptic_post[0]), _dynamic_array_observed_recurrent__synaptic_post.size()*sizeof(_dynamic_array_observed_recurrent__synaptic_post[0]));
            outfile__dynamic_array_observed_recurrent__synaptic_post.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_recurrent__synaptic_post." << endl;
    }
    ofstream outfile__dynamic_array_observed_recurrent__synaptic_pre;
    outfile__dynamic_array_observed_recurrent__synaptic_pre.open(results_dir + "_dynamic_array_observed_recurrent__synaptic_pre_3285443268", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_recurrent__synaptic_pre.is_open())
    {
        if (! _dynamic_array_observed_recurrent__synaptic_pre.empty() )
        {
            outfile__dynamic_array_observed_recurrent__synaptic_pre.write(reinterpret_cast<char*>(&_dynamic_array_observed_recurrent__synaptic_pre[0]), _dynamic_array_observed_recurrent__synaptic_pre.size()*sizeof(_dynamic_array_observed_recurrent__synaptic_pre[0]));
            outfile__dynamic_array_observed_recurrent__synaptic_pre.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_recurrent__synaptic_pre." << endl;
    }
    ofstream outfile__dynamic_array_observed_recurrent_delay;
    outfile__dynamic_array_observed_recurrent_delay.open(results_dir + "_dynamic_array_observed_recurrent_delay_1948586283", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_recurrent_delay.is_open())
    {
        if (! _dynamic_array_observed_recurrent_delay.empty() )
        {
            outfile__dynamic_array_observed_recurrent_delay.write(reinterpret_cast<char*>(&_dynamic_array_observed_recurrent_delay[0]), _dynamic_array_observed_recurrent_delay.size()*sizeof(_dynamic_array_observed_recurrent_delay[0]));
            outfile__dynamic_array_observed_recurrent_delay.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_recurrent_delay." << endl;
    }
    ofstream outfile__dynamic_array_observed_recurrent_N_incoming;
    outfile__dynamic_array_observed_recurrent_N_incoming.open(results_dir + "_dynamic_array_observed_recurrent_N_incoming_2940660241", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_recurrent_N_incoming.is_open())
    {
        if (! _dynamic_array_observed_recurrent_N_incoming.empty() )
        {
            outfile__dynamic_array_observed_recurrent_N_incoming.write(reinterpret_cast<char*>(&_dynamic_array_observed_recurrent_N_incoming[0]), _dynamic_array_observed_recurrent_N_incoming.size()*sizeof(_dynamic_array_observed_recurrent_N_incoming[0]));
            outfile__dynamic_array_observed_recurrent_N_incoming.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_recurrent_N_incoming." << endl;
    }
    ofstream outfile__dynamic_array_observed_recurrent_N_outgoing;
    outfile__dynamic_array_observed_recurrent_N_outgoing.open(results_dir + "_dynamic_array_observed_recurrent_N_outgoing_2287639243", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_recurrent_N_outgoing.is_open())
    {
        if (! _dynamic_array_observed_recurrent_N_outgoing.empty() )
        {
            outfile__dynamic_array_observed_recurrent_N_outgoing.write(reinterpret_cast<char*>(&_dynamic_array_observed_recurrent_N_outgoing[0]), _dynamic_array_observed_recurrent_N_outgoing.size()*sizeof(_dynamic_array_observed_recurrent_N_outgoing[0]));
            outfile__dynamic_array_observed_recurrent_N_outgoing.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_recurrent_N_outgoing." << endl;
    }
    ofstream outfile__dynamic_array_observed_recurrent_w;
    outfile__dynamic_array_observed_recurrent_w.open(results_dir + "_dynamic_array_observed_recurrent_w_158196646", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_recurrent_w.is_open())
    {
        if (! _dynamic_array_observed_recurrent_w.empty() )
        {
            outfile__dynamic_array_observed_recurrent_w.write(reinterpret_cast<char*>(&_dynamic_array_observed_recurrent_w[0]), _dynamic_array_observed_recurrent_w.size()*sizeof(_dynamic_array_observed_recurrent_w[0]));
            outfile__dynamic_array_observed_recurrent_w.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_recurrent_w." << endl;
    }
    ofstream outfile__dynamic_array_observed_source__timebins;
    outfile__dynamic_array_observed_source__timebins.open(results_dir + "_dynamic_array_observed_source__timebins_3434765145", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_source__timebins.is_open())
    {
        if (! _dynamic_array_observed_source__timebins.empty() )
        {
            outfile__dynamic_array_observed_source__timebins.write(reinterpret_cast<char*>(&_dynamic_array_observed_source__timebins[0]), _dynamic_array_observed_source__timebins.size()*sizeof(_dynamic_array_observed_source__timebins[0]));
            outfile__dynamic_array_observed_source__timebins.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_source__timebins." << endl;
    }
    ofstream outfile__dynamic_array_observed_source_neuron_index;
    outfile__dynamic_array_observed_source_neuron_index.open(results_dir + "_dynamic_array_observed_source_neuron_index_3713161988", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_source_neuron_index.is_open())
    {
        if (! _dynamic_array_observed_source_neuron_index.empty() )
        {
            outfile__dynamic_array_observed_source_neuron_index.write(reinterpret_cast<char*>(&_dynamic_array_observed_source_neuron_index[0]), _dynamic_array_observed_source_neuron_index.size()*sizeof(_dynamic_array_observed_source_neuron_index[0]));
            outfile__dynamic_array_observed_source_neuron_index.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_source_neuron_index." << endl;
    }
    ofstream outfile__dynamic_array_observed_source_spike_number;
    outfile__dynamic_array_observed_source_spike_number.open(results_dir + "_dynamic_array_observed_source_spike_number_2931452980", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_source_spike_number.is_open())
    {
        if (! _dynamic_array_observed_source_spike_number.empty() )
        {
            outfile__dynamic_array_observed_source_spike_number.write(reinterpret_cast<char*>(&_dynamic_array_observed_source_spike_number[0]), _dynamic_array_observed_source_spike_number.size()*sizeof(_dynamic_array_observed_source_spike_number[0]));
            outfile__dynamic_array_observed_source_spike_number.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_source_spike_number." << endl;
    }
    ofstream outfile__dynamic_array_observed_source_spike_time;
    outfile__dynamic_array_observed_source_spike_time.open(results_dir + "_dynamic_array_observed_source_spike_time_3157292054", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_source_spike_time.is_open())
    {
        if (! _dynamic_array_observed_source_spike_time.empty() )
        {
            outfile__dynamic_array_observed_source_spike_time.write(reinterpret_cast<char*>(&_dynamic_array_observed_source_spike_time[0]), _dynamic_array_observed_source_spike_time.size()*sizeof(_dynamic_array_observed_source_spike_time[0]));
            outfile__dynamic_array_observed_source_spike_time.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_source_spike_time." << endl;
    }
    ofstream outfile__dynamic_array_spikemonitor_i;
    outfile__dynamic_array_spikemonitor_i.open(results_dir + "_dynamic_array_spikemonitor_i_1976709050", ios::binary | ios::out);
    if(outfile__dynamic_array_spikemonitor_i.is_open())
    {
        if (! _dynamic_array_spikemonitor_i.empty() )
        {
            outfile__dynamic_array_spikemonitor_i.write(reinterpret_cast<char*>(&_dynamic_array_spikemonitor_i[0]), _dynamic_array_spikemonitor_i.size()*sizeof(_dynamic_array_spikemonitor_i[0]));
            outfile__dynamic_array_spikemonitor_i.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_spikemonitor_i." << endl;
    }
    ofstream outfile__dynamic_array_spikemonitor_t;
    outfile__dynamic_array_spikemonitor_t.open(results_dir + "_dynamic_array_spikemonitor_t_383009635", ios::binary | ios::out);
    if(outfile__dynamic_array_spikemonitor_t.is_open())
    {
        if (! _dynamic_array_spikemonitor_t.empty() )
        {
            outfile__dynamic_array_spikemonitor_t.write(reinterpret_cast<char*>(&_dynamic_array_spikemonitor_t[0]), _dynamic_array_spikemonitor_t.size()*sizeof(_dynamic_array_spikemonitor_t[0]));
            outfile__dynamic_array_spikemonitor_t.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_spikemonitor_t." << endl;
    }

    ofstream outfile__dynamic_array_observed_before_g;
    outfile__dynamic_array_observed_before_g.open(results_dir + "_dynamic_array_observed_before_g_1511661445", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_before_g.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_before_g.n; n++)
        {
            if (! _dynamic_array_observed_before_g(n).empty())
            {
                outfile__dynamic_array_observed_before_g.write(reinterpret_cast<char*>(&_dynamic_array_observed_before_g(n, 0)), _dynamic_array_observed_before_g.m*sizeof(_dynamic_array_observed_before_g(0, 0)));
            }
        }
        outfile__dynamic_array_observed_before_g.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_before_g." << endl;
    }
    ofstream outfile__dynamic_array_observed_before_not_refractory;
    outfile__dynamic_array_observed_before_not_refractory.open(results_dir + "_dynamic_array_observed_before_not_refractory_1644825263", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_before_not_refractory.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_before_not_refractory.n; n++)
        {
            if (! _dynamic_array_observed_before_not_refractory(n).empty())
            {
                outfile__dynamic_array_observed_before_not_refractory.write(reinterpret_cast<char*>(&_dynamic_array_observed_before_not_refractory(n, 0)), _dynamic_array_observed_before_not_refractory.m*sizeof(_dynamic_array_observed_before_not_refractory(0, 0)));
            }
        }
        outfile__dynamic_array_observed_before_not_refractory.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_before_not_refractory." << endl;
    }
    ofstream outfile__dynamic_array_observed_before_v;
    outfile__dynamic_array_observed_before_v.open(results_dir + "_dynamic_array_observed_before_v_816463735", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_before_v.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_before_v.n; n++)
        {
            if (! _dynamic_array_observed_before_v(n).empty())
            {
                outfile__dynamic_array_observed_before_v.write(reinterpret_cast<char*>(&_dynamic_array_observed_before_v(n, 0)), _dynamic_array_observed_before_v.m*sizeof(_dynamic_array_observed_before_v(0, 0)));
            }
        }
        outfile__dynamic_array_observed_before_v.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_before_v." << endl;
    }
    ofstream outfile__dynamic_array_observed_end_g;
    outfile__dynamic_array_observed_end_g.open(results_dir + "_dynamic_array_observed_end_g_1338799464", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_end_g.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_end_g.n; n++)
        {
            if (! _dynamic_array_observed_end_g(n).empty())
            {
                outfile__dynamic_array_observed_end_g.write(reinterpret_cast<char*>(&_dynamic_array_observed_end_g(n, 0)), _dynamic_array_observed_end_g.m*sizeof(_dynamic_array_observed_end_g(0, 0)));
            }
        }
        outfile__dynamic_array_observed_end_g.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_end_g." << endl;
    }
    ofstream outfile__dynamic_array_observed_end_lastspike;
    outfile__dynamic_array_observed_end_lastspike.open(results_dir + "_dynamic_array_observed_end_lastspike_2655575218", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_end_lastspike.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_end_lastspike.n; n++)
        {
            if (! _dynamic_array_observed_end_lastspike(n).empty())
            {
                outfile__dynamic_array_observed_end_lastspike.write(reinterpret_cast<char*>(&_dynamic_array_observed_end_lastspike(n, 0)), _dynamic_array_observed_end_lastspike.m*sizeof(_dynamic_array_observed_end_lastspike(0, 0)));
            }
        }
        outfile__dynamic_array_observed_end_lastspike.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_end_lastspike." << endl;
    }
    ofstream outfile__dynamic_array_observed_end_not_refractory;
    outfile__dynamic_array_observed_end_not_refractory.open(results_dir + "_dynamic_array_observed_end_not_refractory_1874295205", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_end_not_refractory.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_end_not_refractory.n; n++)
        {
            if (! _dynamic_array_observed_end_not_refractory(n).empty())
            {
                outfile__dynamic_array_observed_end_not_refractory.write(reinterpret_cast<char*>(&_dynamic_array_observed_end_not_refractory(n, 0)), _dynamic_array_observed_end_not_refractory.m*sizeof(_dynamic_array_observed_end_not_refractory(0, 0)));
            }
        }
        outfile__dynamic_array_observed_end_not_refractory.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_end_not_refractory." << endl;
    }
    ofstream outfile__dynamic_array_observed_end_v;
    outfile__dynamic_array_observed_end_v.open(results_dir + "_dynamic_array_observed_end_v_628905370", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_end_v.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_end_v.n; n++)
        {
            if (! _dynamic_array_observed_end_v(n).empty())
            {
                outfile__dynamic_array_observed_end_v.write(reinterpret_cast<char*>(&_dynamic_array_observed_end_v(n, 0)), _dynamic_array_observed_end_v.m*sizeof(_dynamic_array_observed_end_v(0, 0)));
            }
        }
        outfile__dynamic_array_observed_end_v.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_end_v." << endl;
    }
    ofstream outfile__dynamic_array_observed_pre_g;
    outfile__dynamic_array_observed_pre_g.open(results_dir + "_dynamic_array_observed_pre_g_4240568202", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_pre_g.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_pre_g.n; n++)
        {
            if (! _dynamic_array_observed_pre_g(n).empty())
            {
                outfile__dynamic_array_observed_pre_g.write(reinterpret_cast<char*>(&_dynamic_array_observed_pre_g(n, 0)), _dynamic_array_observed_pre_g.m*sizeof(_dynamic_array_observed_pre_g(0, 0)));
            }
        }
        outfile__dynamic_array_observed_pre_g.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_pre_g." << endl;
    }
    ofstream outfile__dynamic_array_observed_pre_not_refractory;
    outfile__dynamic_array_observed_pre_not_refractory.open(results_dir + "_dynamic_array_observed_pre_not_refractory_2312053991", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_pre_not_refractory.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_pre_not_refractory.n; n++)
        {
            if (! _dynamic_array_observed_pre_not_refractory(n).empty())
            {
                outfile__dynamic_array_observed_pre_not_refractory.write(reinterpret_cast<char*>(&_dynamic_array_observed_pre_not_refractory(n, 0)), _dynamic_array_observed_pre_not_refractory.m*sizeof(_dynamic_array_observed_pre_not_refractory(0, 0)));
            }
        }
        outfile__dynamic_array_observed_pre_not_refractory.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_pre_not_refractory." << endl;
    }
    ofstream outfile__dynamic_array_observed_pre_v;
    outfile__dynamic_array_observed_pre_v.open(results_dir + "_dynamic_array_observed_pre_v_2524041080", ios::binary | ios::out);
    if(outfile__dynamic_array_observed_pre_v.is_open())
    {
        for (int n=0; n<_dynamic_array_observed_pre_v.n; n++)
        {
            if (! _dynamic_array_observed_pre_v(n).empty())
            {
                outfile__dynamic_array_observed_pre_v.write(reinterpret_cast<char*>(&_dynamic_array_observed_pre_v(n, 0)), _dynamic_array_observed_pre_v.m*sizeof(_dynamic_array_observed_pre_v(0, 0)));
            }
        }
        outfile__dynamic_array_observed_pre_v.close();
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_observed_pre_v." << endl;
    }
    // Write last run info to disk
    ofstream outfile_last_run_info;
    outfile_last_run_info.open(results_dir + "last_run_info.txt", ios::out);
    if(outfile_last_run_info.is_open())
    {
        outfile_last_run_info << (Network::_last_run_time) << " " << (Network::_last_run_completed_fraction) << std::endl;
        outfile_last_run_info.close();
    } else
    {
        std::cout << "Error writing last run info to file." << std::endl;
    }
}

void _dealloc_arrays()
{
    using namespace brian;


    // static arrays
    if(_static_array__array_observed_before__indices!=0)
    {
        delete [] _static_array__array_observed_before__indices;
        _static_array__array_observed_before__indices = 0;
    }
    if(_static_array__array_observed_end__indices!=0)
    {
        delete [] _static_array__array_observed_end__indices;
        _static_array__array_observed_end__indices = 0;
    }
    if(_static_array__array_observed_input_sources!=0)
    {
        delete [] _static_array__array_observed_input_sources;
        _static_array__array_observed_input_sources = 0;
    }
    if(_static_array__array_observed_input_targets!=0)
    {
        delete [] _static_array__array_observed_input_targets;
        _static_array__array_observed_input_targets = 0;
    }
    if(_static_array__array_observed_neurons_g!=0)
    {
        delete [] _static_array__array_observed_neurons_g;
        _static_array__array_observed_neurons_g = 0;
    }
    if(_static_array__array_observed_neurons_lastspike!=0)
    {
        delete [] _static_array__array_observed_neurons_lastspike;
        _static_array__array_observed_neurons_lastspike = 0;
    }
    if(_static_array__array_observed_neurons_rfc!=0)
    {
        delete [] _static_array__array_observed_neurons_rfc;
        _static_array__array_observed_neurons_rfc = 0;
    }
    if(_static_array__array_observed_neurons_v!=0)
    {
        delete [] _static_array__array_observed_neurons_v;
        _static_array__array_observed_neurons_v = 0;
    }
    if(_static_array__array_observed_pre__indices!=0)
    {
        delete [] _static_array__array_observed_pre__indices;
        _static_array__array_observed_pre__indices = 0;
    }
    if(_static_array__array_observed_recurrent_sources!=0)
    {
        delete [] _static_array__array_observed_recurrent_sources;
        _static_array__array_observed_recurrent_sources = 0;
    }
    if(_static_array__array_observed_recurrent_targets!=0)
    {
        delete [] _static_array__array_observed_recurrent_targets;
        _static_array__array_observed_recurrent_targets = 0;
    }
    if(_static_array__dynamic_array_observed_recurrent_w!=0)
    {
        delete [] _static_array__dynamic_array_observed_recurrent_w;
        _static_array__dynamic_array_observed_recurrent_w = 0;
    }
    if(_static_array__dynamic_array_observed_source__timebins!=0)
    {
        delete [] _static_array__dynamic_array_observed_source__timebins;
        _static_array__dynamic_array_observed_source__timebins = 0;
    }
    if(_static_array__dynamic_array_observed_source_neuron_index!=0)
    {
        delete [] _static_array__dynamic_array_observed_source_neuron_index;
        _static_array__dynamic_array_observed_source_neuron_index = 0;
    }
    if(_static_array__dynamic_array_observed_source_spike_number!=0)
    {
        delete [] _static_array__dynamic_array_observed_source_spike_number;
        _static_array__dynamic_array_observed_source_spike_number = 0;
    }
    if(_static_array__dynamic_array_observed_source_spike_time!=0)
    {
        delete [] _static_array__dynamic_array_observed_source_spike_time;
        _static_array__dynamic_array_observed_source_spike_time = 0;
    }
}

