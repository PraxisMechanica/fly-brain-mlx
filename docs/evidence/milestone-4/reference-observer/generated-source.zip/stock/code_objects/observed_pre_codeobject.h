#ifndef _INCLUDED_observed_pre_codeobject
#define _INCLUDED_observed_pre_codeobject

void _run_observed_pre_codeobject();


#endif
