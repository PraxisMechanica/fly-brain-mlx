#ifndef _INCLUDED_observed_input_pre_push_spikes
#define _INCLUDED_observed_input_pre_push_spikes

void _run_observed_input_pre_push_spikes();


#endif
