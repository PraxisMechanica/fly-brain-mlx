#ifndef _INCLUDED_observed_source_codeobject
#define _INCLUDED_observed_source_codeobject

void _run_observed_source_codeobject();


#endif
