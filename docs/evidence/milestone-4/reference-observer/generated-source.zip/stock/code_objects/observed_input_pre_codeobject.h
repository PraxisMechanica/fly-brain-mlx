#ifndef _INCLUDED_observed_input_pre_codeobject
#define _INCLUDED_observed_input_pre_codeobject

void _run_observed_input_pre_codeobject();

void _debugmsg_observed_input_pre_codeobject();

#endif
