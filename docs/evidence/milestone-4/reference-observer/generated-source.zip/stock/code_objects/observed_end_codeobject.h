#ifndef _INCLUDED_observed_end_codeobject
#define _INCLUDED_observed_end_codeobject

void _run_observed_end_codeobject();


#endif
