#include "code_objects/observed_pre_codeobject.h"
#include "objects.h"
#include "brianlib/common_math.h"
#include "brianlib/stdint_compat.h"
#include<cmath>
#include<ctime>
#include<iostream>
#include<fstream>
#include<climits>

////// SUPPORT CODE ///////
namespace {
        
    template < typename T1, typename T2 > struct _higher_type;
    template < > struct _higher_type<int32_t,int32_t> { typedef int32_t type; };
    template < > struct _higher_type<int32_t,int64_t> { typedef int64_t type; };
    template < > struct _higher_type<int32_t,float> { typedef float type; };
    template < > struct _higher_type<int32_t,double> { typedef double type; };
    template < > struct _higher_type<int32_t,long double> { typedef long double type; };
    template < > struct _higher_type<int64_t,int32_t> { typedef int64_t type; };
    template < > struct _higher_type<int64_t,int64_t> { typedef int64_t type; };
    template < > struct _higher_type<int64_t,float> { typedef float type; };
    template < > struct _higher_type<int64_t,double> { typedef double type; };
    template < > struct _higher_type<int64_t,long double> { typedef long double type; };
    template < > struct _higher_type<float,int32_t> { typedef float type; };
    template < > struct _higher_type<float,int64_t> { typedef float type; };
    template < > struct _higher_type<float,float> { typedef float type; };
    template < > struct _higher_type<float,double> { typedef double type; };
    template < > struct _higher_type<float,long double> { typedef long double type; };
    template < > struct _higher_type<double,int32_t> { typedef double type; };
    template < > struct _higher_type<double,int64_t> { typedef double type; };
    template < > struct _higher_type<double,float> { typedef double type; };
    template < > struct _higher_type<double,double> { typedef double type; };
    template < > struct _higher_type<double,long double> { typedef long double type; };
    template < > struct _higher_type<long double,int32_t> { typedef long double type; };
    template < > struct _higher_type<long double,int64_t> { typedef long double type; };
    template < > struct _higher_type<long double,float> { typedef long double type; };
    template < > struct _higher_type<long double,double> { typedef long double type; };
    template < > struct _higher_type<long double,long double> { typedef long double type; };
    // General template, used for floating point types
    template < typename T1, typename T2 >
    static inline typename _higher_type<T1,T2>::type
    _brian_mod(T1 x, T2 y)
    {
        return x-y*floor(1.0*x/y);
    }
    // Specific implementations for integer types
    // (from Cython, see LICENSE file)
    template <>
    inline int32_t _brian_mod(int32_t x, int32_t y)
    {
        int32_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    template <>
    inline int64_t _brian_mod(int32_t x, int64_t y)
    {
        int64_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    template <>
    inline int64_t _brian_mod(int64_t x, int32_t y)
    {
        int64_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    template <>
    inline int64_t _brian_mod(int64_t x, int64_t y)
    {
        int64_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    // General implementation, used for floating point types
    template < typename T1, typename T2 >
    static inline typename _higher_type<T1,T2>::type
    _brian_floordiv(T1 x, T2 y)
    {{
        return floor(1.0*x/y);
    }}
    // Specific implementations for integer types
    // (from Cython, see LICENSE file)
    template <>
    inline int32_t _brian_floordiv<int32_t, int32_t>(int32_t a, int32_t b) {
        int32_t q = a / b;
        int32_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    template <>
    inline int64_t _brian_floordiv<int32_t, int64_t>(int32_t a, int64_t b) {
        int64_t q = a / b;
        int64_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    template <>
    inline int64_t _brian_floordiv<int64_t, int>(int64_t a, int32_t b) {
        int64_t q = a / b;
        int64_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    template <>
    inline int64_t _brian_floordiv<int64_t, int64_t>(int64_t a, int64_t b) {
        int64_t q = a / b;
        int64_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    #ifdef _MSC_VER
    #define _brian_pow(x, y) (pow((double)(x), (y)))
    #else
    #define _brian_pow(x, y) (pow((x), (y)))
    #endif

}

////// HASH DEFINES ///////



void _run_observed_pre_codeobject()
{
    using namespace brian;


    ///// CONSTANTS ///////////
    const size_t _numN = 1;
const size_t _num_clock_t = 1;
const size_t _num_indices = 6;
const size_t _num_source_g = 6;
const size_t _num_source_not_refractory = 6;
const size_t _num_source_v = 6;
double* const _array_observed_pre_t = _dynamic_array_observed_pre_t.empty()? 0 : &_dynamic_array_observed_pre_t[0];
const size_t _numt = _dynamic_array_observed_pre_t.size();
    ///// POINTERS ////////////
        
    int32_t*   _ptr_array_observed_pre_N = _array_observed_pre_N;
    double*   _ptr_array_defaultclock_t = _array_defaultclock_t;
    int32_t* __restrict  _ptr_array_observed_pre__indices = _array_observed_pre__indices;
    double* __restrict  _ptr_array_observed_neurons_g = _array_observed_neurons_g;
    char* __restrict  _ptr_array_observed_neurons_not_refractory = _array_observed_neurons_not_refractory;
    double* __restrict  _ptr_array_observed_neurons_v = _array_observed_neurons_v;
    double* __restrict  _ptr_array_observed_pre_t = _array_observed_pre_t;


    _dynamic_array_observed_pre_t.push_back(_ptr_array_defaultclock_t[0]);

    const size_t _new_size = _dynamic_array_observed_pre_t.size();
    // Resize the dynamic arrays
    _dynamic_array_observed_pre_g.resize(_new_size, _num_indices);
    _dynamic_array_observed_pre_not_refractory.resize(_new_size, _num_indices);
    _dynamic_array_observed_pre_v.resize(_new_size, _num_indices);

    // scalar code
    const size_t _vectorisation_idx = -1;
        


    
    for (int _i = 0; _i < (int)_num_indices; _i++)
    {
        // vector code
        const size_t _idx = _ptr_array_observed_pre__indices[_i];
        const size_t _vectorisation_idx = _idx;
                
        const double _source_g = _ptr_array_observed_neurons_g[_idx];
        const char _source_not_refractory = _ptr_array_observed_neurons_not_refractory[_idx];
        const double _source_v = _ptr_array_observed_neurons_v[_idx];
        const double _to_record_v = _source_v;
        const double _to_record_g = _source_g;
        char _to_record_not_refractory;
        if(!_source_not_refractory)
            _to_record_not_refractory = false;
        else 
            _to_record_not_refractory = true;


        _dynamic_array_observed_pre_g(_new_size-1, _i) = _to_record_g;
        _dynamic_array_observed_pre_not_refractory(_new_size-1, _i) = _to_record_not_refractory;
        _dynamic_array_observed_pre_v(_new_size-1, _i) = _to_record_v;
    }

    _ptr_array_observed_pre_N[0] = _new_size;


}


