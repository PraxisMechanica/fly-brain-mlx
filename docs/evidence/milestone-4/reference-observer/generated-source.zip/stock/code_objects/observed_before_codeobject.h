#ifndef _INCLUDED_observed_before_codeobject
#define _INCLUDED_observed_before_codeobject

void _run_observed_before_codeobject();


#endif
