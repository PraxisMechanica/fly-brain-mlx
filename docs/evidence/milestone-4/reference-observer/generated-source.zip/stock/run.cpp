#include<stdlib.h>
#include "objects.h"
#include<ctime>
#include<random>

#include "code_objects/observed_before_codeobject.h"
#include "code_objects/observed_end_codeobject.h"
#include "code_objects/observed_input_pre_codeobject.h"
#include "code_objects/observed_input_pre_push_spikes.h"
#include "code_objects/observed_input_synapses_create_array_codeobject.h"
#include "code_objects/observed_neurons_spike_resetter_codeobject.h"
#include "code_objects/observed_neurons_spike_thresholder_codeobject.h"
#include "code_objects/observed_neurons_stateupdater_codeobject.h"
#include "code_objects/observed_pre_codeobject.h"
#include "code_objects/observed_recurrent_pre_codeobject.h"
#include "code_objects/observed_recurrent_pre_push_spikes.h"
#include "code_objects/observed_recurrent_synapses_create_array_codeobject.h"
#include "code_objects/observed_source_codeobject.h"
#include "code_objects/spikemonitor_codeobject.h"


void brian_start()
{
	_init_arrays();
	_load_arrays();
	// Initialize clocks (link timestep and dt to the respective arrays)
    brian::defaultclock.timestep = brian::_array_defaultclock_timestep;
    brian::defaultclock.dt = brian::_array_defaultclock_dt;
    brian::defaultclock.t = brian::_array_defaultclock_t;
}

void brian_end()
{
	_write_arrays();
	_dealloc_arrays();
}


