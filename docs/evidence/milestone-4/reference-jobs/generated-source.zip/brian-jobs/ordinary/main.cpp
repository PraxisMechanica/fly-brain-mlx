#include <stdlib.h>
#include "objects.h"
#include <ctime>
#include <time.h>

#include "run.h"
#include "brianlib/common_math.h"

#include "code_objects/default_neurons_spike_resetter_codeobject.h"
#include "code_objects/default_neurons_spike_thresholder_codeobject.h"
#include "code_objects/after_run_default_neurons_spike_thresholder_codeobject.h"
#include "code_objects/default_neurons_stateupdater_codeobject.h"
#include "code_objects/default_synapses_group_variable_set_conditional_codeobject.h"
#include "code_objects/default_synapses_pre_codeobject.h"
#include "code_objects/default_synapses_pre_push_spikes.h"
#include "code_objects/before_run_default_synapses_pre_push_spikes.h"
#include "code_objects/default_synapses_synapses_create_array_codeobject.h"
#include "code_objects/reference_spikes_codeobject.h"
#include "code_objects/replay_input_pre_codeobject.h"
#include "code_objects/replay_input_pre_push_spikes.h"
#include "code_objects/before_run_replay_input_pre_push_spikes.h"
#include "code_objects/replay_input_synapses_create_array_codeobject.h"
#include "code_objects/replay_source_codeobject.h"


#include <iostream>
#include <fstream>
#include <string>




void set_from_command_line(const std::vector<std::string> args)
{
    for (const auto& arg : args) {
		// Split into two parts
		size_t equal_sign = arg.find("=");
		auto name = arg.substr(0, equal_sign);
		auto value = arg.substr(equal_sign + 1, arg.length());
		brian::set_variable_by_name(name, value);
	}
}
int main(int argc, char **argv)
{
	std::random_device _rd;
	std::vector<std::string> args(argv + 1, argv + argc);
	if (args.size() >=2 && args[0] == "--results_dir")
	{
		brian::results_dir = args[1];
		#ifdef DEBUG
		std::cout << "Setting results dir to '" << brian::results_dir << "'" << std::endl;
		#endif
		args.erase(args.begin(), args.begin()+2);
	}
        

	brian_start();
        

	{
		using namespace brian;

		
                
        _array_defaultclock_dt[0] = 0.0001;
        _array_defaultclock_dt[0] = 0.0001;
        _array_defaultclock_dt[0] = 0.0001;
        _array_defaultclock_dt[0] = 0.0001;
        
                        
                        for(int i=0; i<_num__array_default_neurons_lastspike; i++)
                        {
                            _array_default_neurons_lastspike[i] = - 10000.0;
                        }
                        
        
                        
                        for(int i=0; i<_num__array_default_neurons_not_refractory; i++)
                        {
                            _array_default_neurons_not_refractory[i] = true;
                        }
                        
        
                        
                        for(int i=0; i<_num__array_default_neurons_v; i++)
                        {
                            _array_default_neurons_v[i] = - 0.052000000000000005;
                        }
                        
        
                        
                        for(int i=0; i<_num__array_default_neurons_g; i++)
                        {
                            _array_default_neurons_g[i] = 0.0;
                        }
                        
        
                        
                        for(int i=0; i<_num__array_default_neurons_lastspike; i++)
                        {
                            _array_default_neurons_lastspike[i] = - 10000.0;
                        }
                        
        
                        
                        for(int i=0; i<_num__array_default_neurons_rfc; i++)
                        {
                            _array_default_neurons_rfc[i] = _static_array__array_default_neurons_rfc[i];
                        }
                        
        _dynamic_array_default_synapses_delay.resize(1);
        _dynamic_array_default_synapses_delay.resize(1);
        _dynamic_array_default_synapses_delay[0] = 0.0018000000000000002;
        
                        
                        for(int i=0; i<_num__array_default_synapses_sources; i++)
                        {
                            _array_default_synapses_sources[i] = _static_array__array_default_synapses_sources[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_default_synapses_targets; i++)
                        {
                            _array_default_synapses_targets[i] = _static_array__array_default_synapses_targets[i];
                        }
                        
        _run_default_synapses_synapses_create_array_codeobject();
        
                        
                        for(int i=0; i<_dynamic_array_default_synapses_w.size(); i++)
                        {
                            _dynamic_array_default_synapses_w[i] = _static_array__dynamic_array_default_synapses_w[i];
                        }
                        
        _run_default_synapses_group_variable_set_conditional_codeobject();
        _dynamic_array_replay_source_spike_number.resize(75);
        
                        
                        for(int i=0; i<_dynamic_array_replay_source_spike_number.size(); i++)
                        {
                            _dynamic_array_replay_source_spike_number[i] = _static_array__dynamic_array_replay_source_spike_number[i];
                        }
                        
        _dynamic_array_replay_source_neuron_index.resize(75);
        
                        
                        for(int i=0; i<_dynamic_array_replay_source_neuron_index.size(); i++)
                        {
                            _dynamic_array_replay_source_neuron_index[i] = _static_array__dynamic_array_replay_source_neuron_index[i];
                        }
                        
        _dynamic_array_replay_source_spike_time.resize(75);
        
                        
                        for(int i=0; i<_dynamic_array_replay_source_spike_time.size(); i++)
                        {
                            _dynamic_array_replay_source_spike_time[i] = _static_array__dynamic_array_replay_source_spike_time[i];
                        }
                        
        _dynamic_array_replay_source__timebins.resize(75);
        _array_replay_source__lastindex[0] = 0;
        _array_replay_source_period[0] = 0.0;
        
                        
                        for(int i=0; i<_num__array_replay_input_sources; i++)
                        {
                            _array_replay_input_sources[i] = _static_array__array_replay_input_sources[i];
                        }
                        
        
                        
                        for(int i=0; i<_num__array_replay_input_targets; i++)
                        {
                            _array_replay_input_targets[i] = _static_array__array_replay_input_targets[i];
                        }
                        
        _run_replay_input_synapses_create_array_codeobject();
        _array_defaultclock_timestep[0] = 0;
        _array_defaultclock_t[0] = 0.0;
        _array_replay_source__lastindex[0] = 0;
        
                        
                        for(int i=0; i<_dynamic_array_replay_source__timebins.size(); i++)
                        {
                            _dynamic_array_replay_source__timebins[i] = _static_array__dynamic_array_replay_source__timebins[i];
                        }
                        
        _array_replay_source__period_bins[0] = 0.0;
        _before_run_default_synapses_pre_push_spikes();
        _before_run_replay_input_pre_push_spikes();
        reference_network.clear();
        reference_network.add(&defaultclock, _run_default_neurons_stateupdater_codeobject);
        reference_network.add(&defaultclock, _run_default_neurons_spike_thresholder_codeobject);
        reference_network.add(&defaultclock, _run_replay_source_codeobject);
        reference_network.add(&defaultclock, _run_reference_spikes_codeobject);
        reference_network.add(&defaultclock, _run_default_synapses_pre_push_spikes);
        reference_network.add(&defaultclock, _run_default_synapses_pre_codeobject);
        reference_network.add(&defaultclock, _run_replay_input_pre_push_spikes);
        reference_network.add(&defaultclock, _run_replay_input_pre_codeobject);
        reference_network.add(&defaultclock, _run_default_neurons_spike_resetter_codeobject);
        set_from_command_line(args);
        reference_network.run(0.010100000000000001, NULL, 10.0);
        _after_run_default_neurons_spike_thresholder_codeobject();
        #ifdef DEBUG
        _debugmsg_reference_spikes_codeobject();
        #endif
        
        #ifdef DEBUG
        _debugmsg_default_synapses_pre_codeobject();
        #endif
        
        #ifdef DEBUG
        _debugmsg_replay_input_pre_codeobject();
        #endif

	}
        

	brian_end();
        

	return 0;
}