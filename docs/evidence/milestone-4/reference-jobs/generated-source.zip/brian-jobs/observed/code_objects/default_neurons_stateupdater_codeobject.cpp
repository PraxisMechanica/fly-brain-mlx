#include "code_objects/default_neurons_stateupdater_codeobject.h"
#include "objects.h"
#include "brianlib/common_math.h"
#include "brianlib/stdint_compat.h"
#include<cmath>
#include<ctime>
#include<iostream>
#include<fstream>
#include<climits>

////// SUPPORT CODE ///////
namespace {
        
    static inline int64_t _timestep(double t, double dt)
    {
        return (int64_t)((t + 1e-3*dt)/dt);
    }
    template < typename T1, typename T2 > struct _higher_type;
    template < > struct _higher_type<int32_t,int32_t> { typedef int32_t type; };
    template < > struct _higher_type<int32_t,int64_t> { typedef int64_t type; };
    template < > struct _higher_type<int32_t,float> { typedef float type; };
    template < > struct _higher_type<int32_t,double> { typedef double type; };
    template < > struct _higher_type<int32_t,long double> { typedef long double type; };
    template < > struct _higher_type<int64_t,int32_t> { typedef int64_t type; };
    template < > struct _higher_type<int64_t,int64_t> { typedef int64_t type; };
    template < > struct _higher_type<int64_t,float> { typedef float type; };
    template < > struct _higher_type<int64_t,double> { typedef double type; };
    template < > struct _higher_type<int64_t,long double> { typedef long double type; };
    template < > struct _higher_type<float,int32_t> { typedef float type; };
    template < > struct _higher_type<float,int64_t> { typedef float type; };
    template < > struct _higher_type<float,float> { typedef float type; };
    template < > struct _higher_type<float,double> { typedef double type; };
    template < > struct _higher_type<float,long double> { typedef long double type; };
    template < > struct _higher_type<double,int32_t> { typedef double type; };
    template < > struct _higher_type<double,int64_t> { typedef double type; };
    template < > struct _higher_type<double,float> { typedef double type; };
    template < > struct _higher_type<double,double> { typedef double type; };
    template < > struct _higher_type<double,long double> { typedef long double type; };
    template < > struct _higher_type<long double,int32_t> { typedef long double type; };
    template < > struct _higher_type<long double,int64_t> { typedef long double type; };
    template < > struct _higher_type<long double,float> { typedef long double type; };
    template < > struct _higher_type<long double,double> { typedef long double type; };
    template < > struct _higher_type<long double,long double> { typedef long double type; };
    // General template, used for floating point types
    template < typename T1, typename T2 >
    static inline typename _higher_type<T1,T2>::type
    _brian_mod(T1 x, T2 y)
    {
        return x-y*floor(1.0*x/y);
    }
    // Specific implementations for integer types
    // (from Cython, see LICENSE file)
    template <>
    inline int32_t _brian_mod(int32_t x, int32_t y)
    {
        int32_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    template <>
    inline int64_t _brian_mod(int32_t x, int64_t y)
    {
        int64_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    template <>
    inline int64_t _brian_mod(int64_t x, int32_t y)
    {
        int64_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    template <>
    inline int64_t _brian_mod(int64_t x, int64_t y)
    {
        int64_t r = x % y;
        r += ((r != 0) & ((r ^ y) < 0)) * y;
        return r;
    }
    // General implementation, used for floating point types
    template < typename T1, typename T2 >
    static inline typename _higher_type<T1,T2>::type
    _brian_floordiv(T1 x, T2 y)
    {{
        return floor(1.0*x/y);
    }}
    // Specific implementations for integer types
    // (from Cython, see LICENSE file)
    template <>
    inline int32_t _brian_floordiv<int32_t, int32_t>(int32_t a, int32_t b) {
        int32_t q = a / b;
        int32_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    template <>
    inline int64_t _brian_floordiv<int32_t, int64_t>(int32_t a, int64_t b) {
        int64_t q = a / b;
        int64_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    template <>
    inline int64_t _brian_floordiv<int64_t, int>(int64_t a, int32_t b) {
        int64_t q = a / b;
        int64_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    template <>
    inline int64_t _brian_floordiv<int64_t, int64_t>(int64_t a, int64_t b) {
        int64_t q = a / b;
        int64_t r = a - q*b;
        q -= ((r != 0) & ((r ^ b) < 0));
        return q;
    }
    #ifdef _MSC_VER
    #define _brian_pow(x, y) (pow((double)(x), (y)))
    #else
    #define _brian_pow(x, y) (pow((x), (y)))
    #endif

}

////// HASH DEFINES ///////



void _run_default_neurons_stateupdater_codeobject()
{
    using namespace brian;


    ///// CONSTANTS ///////////
    const int64_t N = 6;
const size_t _numdt = 1;
const size_t _numg = 6;
const size_t _numlastspike = 6;
const size_t _numnot_refractory = 6;
const size_t _numrfc = 6;
const size_t _numt = 1;
const double t_mbr = 0.02;
const double tau = 0.005;
const size_t _numv = 6;
const double v_0 = - 0.052000000000000005;
    ///// POINTERS ////////////
        
    double*   _ptr_array_defaultclock_dt = _array_defaultclock_dt;
    double* __restrict  _ptr_array_default_neurons_g = _array_default_neurons_g;
    double* __restrict  _ptr_array_default_neurons_lastspike = _array_default_neurons_lastspike;
    char* __restrict  _ptr_array_default_neurons_not_refractory = _array_default_neurons_not_refractory;
    double* __restrict  _ptr_array_default_neurons_rfc = _array_default_neurons_rfc;
    double*   _ptr_array_defaultclock_t = _array_defaultclock_t;
    double* __restrict  _ptr_array_default_neurons_v = _array_default_neurons_v;


    //// MAIN CODE ////////////
    // scalar code
    const size_t _vectorisation_idx = -1;
        
    const double dt = _ptr_array_defaultclock_dt[0];
    const double t = _ptr_array_defaultclock_t[0];
    const double _lio_1 = 1.0f*(- dt)/tau;
    const double _lio_2 = exp(_lio_1);
    const double _lio_3 = 1.0f*tau/(t_mbr - tau);
    const double _lio_4 = 1.0f*dt/t_mbr;
    const double _lio_5 = 1.0f*dt/tau;
    const double _lio_6 = 1.0f*(- dt)/t_mbr;
    const double _lio_7 = v_0 - v_0;
    const double _lio_8 = v_0 - (v_0 * exp(_lio_6));
    const double _lio_9 = ((_lio_3 * ((- exp(_lio_4)) + exp(_lio_5))) * exp(_lio_6)) * exp(_lio_1);
    const double _lio_10 = exp(_lio_6);


    const int _N = N;
    
    for(int _idx=0; _idx<_N; _idx++)
    {
        // vector code
        const size_t _vectorisation_idx = _idx;
                
        double g = _ptr_array_default_neurons_g[_idx];
        const double lastspike = _ptr_array_default_neurons_lastspike[_idx];
        char not_refractory = _ptr_array_default_neurons_not_refractory[_idx];
        const double rfc = _ptr_array_default_neurons_rfc[_idx];
        double v = _ptr_array_default_neurons_v[_idx];
        not_refractory = _timestep(t - lastspike, dt) >= _timestep(rfc, dt);
        double _g;
        if(!not_refractory)
            _g = g;
        else 
            _g = _lio_2 * g;
        double _v;
        if(!not_refractory)
            _v = _lio_7 + v;
        else 
            _v = _lio_8 + ((_lio_9 * g) + (_lio_10 * v));
        if(not_refractory)
            g = _g;
        if(not_refractory)
            v = _v;
        _ptr_array_default_neurons_g[_idx] = g;
        _ptr_array_default_neurons_not_refractory[_idx] = not_refractory;
        _ptr_array_default_neurons_v[_idx] = v;

    }

}


