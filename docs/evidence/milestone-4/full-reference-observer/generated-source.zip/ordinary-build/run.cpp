#include<stdlib.h>
#include "objects.h"
#include<ctime>
#include<random>

#include "code_objects/default_neurons_spike_resetter_codeobject.h"
#include "code_objects/default_neurons_spike_thresholder_codeobject.h"
#include "code_objects/default_neurons_stateupdater_codeobject.h"
#include "code_objects/default_synapses_pre_codeobject.h"
#include "code_objects/default_synapses_pre_push_spikes.h"
#include "code_objects/default_synapses_synapses_create_array_codeobject.h"
#include "code_objects/reference_spikes_codeobject.h"
#include "code_objects/replay_input_pre_codeobject.h"
#include "code_objects/replay_input_pre_push_spikes.h"
#include "code_objects/replay_input_synapses_create_array_codeobject.h"
#include "code_objects/replay_source_codeobject.h"


void brian_start()
{
	_init_arrays();
	_load_arrays();
	// Initialize clocks (link timestep and dt to the respective arrays)
    brian::defaultclock.timestep = brian::_array_defaultclock_timestep;
    brian::defaultclock.dt = brian::_array_defaultclock_dt;
    brian::defaultclock.t = brian::_array_defaultclock_t;
}

void brian_end()
{
	_write_arrays();
	_dealloc_arrays();
}


