

#include "objects.h"
#include "synapses_classes.h"
#include "brianlib/clocks.h"
#include "brianlib/dynamic_array.h"
#include "brianlib/stdint_compat.h"
#include "network.h"
#include<random>
#include<vector>
#include<iostream>
#include<fstream>
#include<map>
#include<tuple>
#include<cstdlib>
#include<string>

namespace brian {

std::string results_dir = "results/";  // can be overwritten by --results_dir command line arg

// For multhreading, we need one generator for each thread. We also create a distribution for
// each thread, even though this is not strictly necessary for the uniform distribution, as
// the distribution is stateless.
std::vector< RandomGenerator > _random_generators;

//////////////// networks /////////////////
Network reference_network;

void set_variable_from_value(std::string varname, char* var_pointer, size_t size, char value) {
    #ifdef DEBUG
    std::cout << "Setting '" << varname << "' to " << (value == 1 ? "True" : "False") << std::endl;
    #endif
    std::fill(var_pointer, var_pointer+size, value);
}

template<class T> void set_variable_from_value(std::string varname, T* var_pointer, size_t size, T value) {
    #ifdef DEBUG
    std::cout << "Setting '" << varname << "' to " << value << std::endl;
    #endif
    std::fill(var_pointer, var_pointer+size, value);
}

template<class T> void set_variable_from_file(std::string varname, T* var_pointer, size_t data_size, std::string filename) {
    ifstream f;
    streampos size;
    #ifdef DEBUG
    std::cout << "Setting '" << varname << "' from file '" << filename << "'" << std::endl;
    #endif
    f.open(filename, ios::in | ios::binary | ios::ate);
    size = f.tellg();
    if (size != data_size) {
        std::cerr << "Error reading '" << filename << "': file size " << size << " does not match expected size " << data_size << std::endl;
        return;
    }
    f.seekg(0, ios::beg);
    if (f.is_open())
        f.read(reinterpret_cast<char *>(var_pointer), data_size);
    else
        std::cerr << "Could not read '" << filename << "'" << std::endl;
    if (f.fail())
        std::cerr << "Error reading '" << filename << "'" << std::endl;
}

//////////////// set arrays by name ///////
void set_variable_by_name(std::string name, std::string s_value) {
    size_t var_size;
    size_t data_size;
    // C-style or Python-style capitalization is allowed for boolean values
    if (s_value == "true" || s_value == "True")
        s_value = "1";
    else if (s_value == "false" || s_value == "False")
        s_value = "0";
    // non-dynamic arrays
    if (name == "default_neurons._spikespace") {
        var_size = 138640;
        data_size = 138640*sizeof(int32_t);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<int32_t>(name, _array_default_neurons__spikespace, var_size, (int32_t)atoi(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_default_neurons__spikespace, data_size, s_value);
        }
        return;
    }
    if (name == "default_neurons.g") {
        var_size = 138639;
        data_size = 138639*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_default_neurons_g, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_default_neurons_g, data_size, s_value);
        }
        return;
    }
    if (name == "default_neurons.lastspike") {
        var_size = 138639;
        data_size = 138639*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_default_neurons_lastspike, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_default_neurons_lastspike, data_size, s_value);
        }
        return;
    }
    if (name == "default_neurons.not_refractory") {
        var_size = 138639;
        data_size = 138639*sizeof(char);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value(name, _array_default_neurons_not_refractory, var_size, (char)atoi(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_default_neurons_not_refractory, data_size, s_value);
        }
        return;
    }
    if (name == "default_neurons.rfc") {
        var_size = 138639;
        data_size = 138639*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_default_neurons_rfc, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_default_neurons_rfc, data_size, s_value);
        }
        return;
    }
    if (name == "default_neurons.v") {
        var_size = 138639;
        data_size = 138639*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, _array_default_neurons_v, var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_default_neurons_v, data_size, s_value);
        }
        return;
    }
    if (name == "replay_source._spikespace") {
        var_size = 22;
        data_size = 22*sizeof(int32_t);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<int32_t>(name, _array_replay_source__spikespace, var_size, (int32_t)atoi(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, _array_replay_source__spikespace, data_size, s_value);
        }
        return;
    }
    // dynamic arrays (1d)
    if (name == "default_synapses.delay") {
        var_size = _dynamic_array_default_synapses_delay.size();
        data_size = var_size*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, &_dynamic_array_default_synapses_delay[0], var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, &_dynamic_array_default_synapses_delay[0], data_size, s_value);
        }
        return;
    }
    if (name == "default_synapses.w") {
        var_size = _dynamic_array_default_synapses_w.size();
        data_size = var_size*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, &_dynamic_array_default_synapses_w[0], var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, &_dynamic_array_default_synapses_w[0], data_size, s_value);
        }
        return;
    }
    if (name == "replay_input.delay") {
        var_size = _dynamic_array_replay_input_delay.size();
        data_size = var_size*sizeof(double);
        if (s_value[0] == '-' || (s_value[0] >= '0' && s_value[0] <= '9')) {
            // set from single value
            set_variable_from_value<double>(name, &_dynamic_array_replay_input_delay[0], var_size, (double)atof(s_value.c_str()));

        } else {
            // set from file
            set_variable_from_file(name, &_dynamic_array_replay_input_delay[0], data_size, s_value);
        }
        return;
    }
    std::cerr << "Cannot set unknown variable '" << name << "'." << std::endl;
    exit(1);
}
//////////////// arrays ///////////////////
int32_t * _array_default_neurons__spikespace;
const int _num__array_default_neurons__spikespace = 138640;
double * _array_default_neurons_g;
const int _num__array_default_neurons_g = 138639;
int32_t * _array_default_neurons_i;
const int _num__array_default_neurons_i = 138639;
double * _array_default_neurons_lastspike;
const int _num__array_default_neurons_lastspike = 138639;
char * _array_default_neurons_not_refractory;
const int _num__array_default_neurons_not_refractory = 138639;
double * _array_default_neurons_rfc;
const int _num__array_default_neurons_rfc = 138639;
double * _array_default_neurons_v;
const int _num__array_default_neurons_v = 138639;
int32_t * _array_default_synapses_N;
const int _num__array_default_synapses_N = 1;
int32_t * _array_default_synapses_sources;
const int _num__array_default_synapses_sources = 15091983;
int32_t * _array_default_synapses_targets;
const int _num__array_default_synapses_targets = 15091983;
double * _array_defaultclock_dt;
const int _num__array_defaultclock_dt = 1;
double * _array_defaultclock_t;
const int _num__array_defaultclock_t = 1;
int64_t * _array_defaultclock_timestep;
const int _num__array_defaultclock_timestep = 1;
int32_t * _array_reference_spikes__source_idx;
const int _num__array_reference_spikes__source_idx = 138639;
int32_t * _array_reference_spikes_count;
const int _num__array_reference_spikes_count = 138639;
int32_t * _array_reference_spikes_N;
const int _num__array_reference_spikes_N = 1;
int32_t * _array_replay_input_N;
const int _num__array_replay_input_N = 1;
int32_t * _array_replay_input_sources;
const int _num__array_replay_input_sources = 21;
int32_t * _array_replay_input_targets;
const int _num__array_replay_input_targets = 21;
int32_t * _array_replay_source__lastindex;
const int _num__array_replay_source__lastindex = 1;
int32_t * _array_replay_source__period_bins;
const int _num__array_replay_source__period_bins = 1;
int32_t * _array_replay_source__spikespace;
const int _num__array_replay_source__spikespace = 22;
int32_t * _array_replay_source_i;
const int _num__array_replay_source_i = 21;
double * _array_replay_source_period;
const int _num__array_replay_source_period = 1;

//////////////// dynamic arrays 1d /////////
std::vector<int32_t> _dynamic_array_default_synapses__synaptic_post;
std::vector<int32_t> _dynamic_array_default_synapses__synaptic_pre;
std::vector<double> _dynamic_array_default_synapses_delay;
std::vector<int32_t> _dynamic_array_default_synapses_N_incoming;
std::vector<int32_t> _dynamic_array_default_synapses_N_outgoing;
std::vector<double> _dynamic_array_default_synapses_w;
std::vector<int32_t> _dynamic_array_reference_spikes_i;
std::vector<double> _dynamic_array_reference_spikes_t;
std::vector<int32_t> _dynamic_array_replay_input__synaptic_post;
std::vector<int32_t> _dynamic_array_replay_input__synaptic_pre;
std::vector<double> _dynamic_array_replay_input_delay;
std::vector<int32_t> _dynamic_array_replay_input_N_incoming;
std::vector<int32_t> _dynamic_array_replay_input_N_outgoing;
std::vector<int32_t> _dynamic_array_replay_source__timebins;
std::vector<int32_t> _dynamic_array_replay_source_neuron_index;
std::vector<int32_t> _dynamic_array_replay_source_spike_number;
std::vector<double> _dynamic_array_replay_source_spike_time;

//////////////// dynamic arrays 2d /////////

/////////////// static arrays /////////////
double * _static_array__array_default_neurons_rfc;
const int _num__static_array__array_default_neurons_rfc = 138639;
int32_t * _static_array__array_default_synapses_sources;
const int _num__static_array__array_default_synapses_sources = 15091983;
int32_t * _static_array__array_default_synapses_targets;
const int _num__static_array__array_default_synapses_targets = 15091983;
int32_t * _static_array__array_replay_input_sources;
const int _num__static_array__array_replay_input_sources = 21;
int32_t * _static_array__array_replay_input_targets;
const int _num__static_array__array_replay_input_targets = 21;
double * _static_array__dynamic_array_default_synapses_w;
const int _num__static_array__dynamic_array_default_synapses_w = 15091983;
int32_t * _static_array__dynamic_array_replay_source__timebins;
const int _num__static_array__dynamic_array_replay_source__timebins = 417;
int64_t * _static_array__dynamic_array_replay_source_neuron_index;
const int _num__static_array__dynamic_array_replay_source_neuron_index = 417;
int64_t * _static_array__dynamic_array_replay_source_spike_number;
const int _num__static_array__dynamic_array_replay_source_spike_number = 417;
double * _static_array__dynamic_array_replay_source_spike_time;
const int _num__static_array__dynamic_array_replay_source_spike_time = 417;

//////////////// synapses /////////////////
// default_synapses
SynapticPathway default_synapses_pre(
    _dynamic_array_default_synapses__synaptic_pre,
    0, 138639);
// replay_input
SynapticPathway replay_input_pre(
    _dynamic_array_replay_input__synaptic_pre,
    0, 21);

//////////////// clocks ///////////////////
Clock defaultclock;  // attributes will be set in run.cpp

// Profiling information for each code object
}

void _init_arrays()
{
    using namespace brian;

    // Arrays initialized to 0
    _array_default_neurons__spikespace = new int32_t[138640];
    
    for(int i=0; i<138640; i++) _array_default_neurons__spikespace[i] = 0;

    _array_default_neurons_g = new double[138639];
    
    for(int i=0; i<138639; i++) _array_default_neurons_g[i] = 0;

    _array_default_neurons_i = new int32_t[138639];
    
    for(int i=0; i<138639; i++) _array_default_neurons_i[i] = 0;

    _array_default_neurons_lastspike = new double[138639];
    
    for(int i=0; i<138639; i++) _array_default_neurons_lastspike[i] = 0;

    _array_default_neurons_not_refractory = new char[138639];
    
    for(int i=0; i<138639; i++) _array_default_neurons_not_refractory[i] = 0;

    _array_default_neurons_rfc = new double[138639];
    
    for(int i=0; i<138639; i++) _array_default_neurons_rfc[i] = 0;

    _array_default_neurons_v = new double[138639];
    
    for(int i=0; i<138639; i++) _array_default_neurons_v[i] = 0;

    _array_default_synapses_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_default_synapses_N[i] = 0;

    _array_default_synapses_sources = new int32_t[15091983];
    
    for(int i=0; i<15091983; i++) _array_default_synapses_sources[i] = 0;

    _array_default_synapses_targets = new int32_t[15091983];
    
    for(int i=0; i<15091983; i++) _array_default_synapses_targets[i] = 0;

    _array_defaultclock_dt = new double[1];
    
    for(int i=0; i<1; i++) _array_defaultclock_dt[i] = 0;

    _array_defaultclock_t = new double[1];
    
    for(int i=0; i<1; i++) _array_defaultclock_t[i] = 0;

    _array_defaultclock_timestep = new int64_t[1];
    
    for(int i=0; i<1; i++) _array_defaultclock_timestep[i] = 0;

    _array_reference_spikes__source_idx = new int32_t[138639];
    
    for(int i=0; i<138639; i++) _array_reference_spikes__source_idx[i] = 0;

    _array_reference_spikes_count = new int32_t[138639];
    
    for(int i=0; i<138639; i++) _array_reference_spikes_count[i] = 0;

    _array_reference_spikes_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_reference_spikes_N[i] = 0;

    _array_replay_input_N = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_replay_input_N[i] = 0;

    _array_replay_input_sources = new int32_t[21];
    
    for(int i=0; i<21; i++) _array_replay_input_sources[i] = 0;

    _array_replay_input_targets = new int32_t[21];
    
    for(int i=0; i<21; i++) _array_replay_input_targets[i] = 0;

    _array_replay_source__lastindex = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_replay_source__lastindex[i] = 0;

    _array_replay_source__period_bins = new int32_t[1];
    
    for(int i=0; i<1; i++) _array_replay_source__period_bins[i] = 0;

    _array_replay_source__spikespace = new int32_t[22];
    
    for(int i=0; i<22; i++) _array_replay_source__spikespace[i] = 0;

    _array_replay_source_i = new int32_t[21];
    
    for(int i=0; i<21; i++) _array_replay_source_i[i] = 0;

    _array_replay_source_period = new double[1];
    
    for(int i=0; i<1; i++) _array_replay_source_period[i] = 0;

    _dynamic_array_default_synapses_delay.resize(1);
    
    for(int i=0; i<1; i++) _dynamic_array_default_synapses_delay[i] = 0;

    _dynamic_array_replay_source__timebins.resize(417);
    
    for(int i=0; i<417; i++) _dynamic_array_replay_source__timebins[i] = 0;


    // Arrays initialized to an "arange"
    _array_default_neurons_i = new int32_t[138639];
    
    for(int i=0; i<138639; i++) _array_default_neurons_i[i] = 0 + i;

    _array_reference_spikes__source_idx = new int32_t[138639];
    
    for(int i=0; i<138639; i++) _array_reference_spikes__source_idx[i] = 0 + i;

    _array_replay_source_i = new int32_t[21];
    
    for(int i=0; i<21; i++) _array_replay_source_i[i] = 0 + i;


    // static arrays
    _static_array__array_default_neurons_rfc = new double[138639];
    _static_array__array_default_synapses_sources = new int32_t[15091983];
    _static_array__array_default_synapses_targets = new int32_t[15091983];
    _static_array__array_replay_input_sources = new int32_t[21];
    _static_array__array_replay_input_targets = new int32_t[21];
    _static_array__dynamic_array_default_synapses_w = new double[15091983];
    _static_array__dynamic_array_replay_source__timebins = new int32_t[417];
    _static_array__dynamic_array_replay_source_neuron_index = new int64_t[417];
    _static_array__dynamic_array_replay_source_spike_number = new int64_t[417];
    _static_array__dynamic_array_replay_source_spike_time = new double[417];

    // Random number generator states
    std::random_device rd;
    for (int i=0; i<1; i++)
        _random_generators.push_back(RandomGenerator());
}

void _load_arrays()
{
    using namespace brian;

    ifstream f_static_array__array_default_neurons_rfc;
    f_static_array__array_default_neurons_rfc.open("static_arrays/_static_array__array_default_neurons_rfc", ios::in | ios::binary);
    if(f_static_array__array_default_neurons_rfc.is_open())
    {
        f_static_array__array_default_neurons_rfc.read(reinterpret_cast<char*>(_static_array__array_default_neurons_rfc), 138639*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__array_default_neurons_rfc." << endl;
    }
    ifstream f_static_array__array_default_synapses_sources;
    f_static_array__array_default_synapses_sources.open("static_arrays/_static_array__array_default_synapses_sources", ios::in | ios::binary);
    if(f_static_array__array_default_synapses_sources.is_open())
    {
        f_static_array__array_default_synapses_sources.read(reinterpret_cast<char*>(_static_array__array_default_synapses_sources), 15091983*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_default_synapses_sources." << endl;
    }
    ifstream f_static_array__array_default_synapses_targets;
    f_static_array__array_default_synapses_targets.open("static_arrays/_static_array__array_default_synapses_targets", ios::in | ios::binary);
    if(f_static_array__array_default_synapses_targets.is_open())
    {
        f_static_array__array_default_synapses_targets.read(reinterpret_cast<char*>(_static_array__array_default_synapses_targets), 15091983*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_default_synapses_targets." << endl;
    }
    ifstream f_static_array__array_replay_input_sources;
    f_static_array__array_replay_input_sources.open("static_arrays/_static_array__array_replay_input_sources", ios::in | ios::binary);
    if(f_static_array__array_replay_input_sources.is_open())
    {
        f_static_array__array_replay_input_sources.read(reinterpret_cast<char*>(_static_array__array_replay_input_sources), 21*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_replay_input_sources." << endl;
    }
    ifstream f_static_array__array_replay_input_targets;
    f_static_array__array_replay_input_targets.open("static_arrays/_static_array__array_replay_input_targets", ios::in | ios::binary);
    if(f_static_array__array_replay_input_targets.is_open())
    {
        f_static_array__array_replay_input_targets.read(reinterpret_cast<char*>(_static_array__array_replay_input_targets), 21*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__array_replay_input_targets." << endl;
    }
    ifstream f_static_array__dynamic_array_default_synapses_w;
    f_static_array__dynamic_array_default_synapses_w.open("static_arrays/_static_array__dynamic_array_default_synapses_w", ios::in | ios::binary);
    if(f_static_array__dynamic_array_default_synapses_w.is_open())
    {
        f_static_array__dynamic_array_default_synapses_w.read(reinterpret_cast<char*>(_static_array__dynamic_array_default_synapses_w), 15091983*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_default_synapses_w." << endl;
    }
    ifstream f_static_array__dynamic_array_replay_source__timebins;
    f_static_array__dynamic_array_replay_source__timebins.open("static_arrays/_static_array__dynamic_array_replay_source__timebins", ios::in | ios::binary);
    if(f_static_array__dynamic_array_replay_source__timebins.is_open())
    {
        f_static_array__dynamic_array_replay_source__timebins.read(reinterpret_cast<char*>(_static_array__dynamic_array_replay_source__timebins), 417*sizeof(int32_t));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_replay_source__timebins." << endl;
    }
    ifstream f_static_array__dynamic_array_replay_source_neuron_index;
    f_static_array__dynamic_array_replay_source_neuron_index.open("static_arrays/_static_array__dynamic_array_replay_source_neuron_index", ios::in | ios::binary);
    if(f_static_array__dynamic_array_replay_source_neuron_index.is_open())
    {
        f_static_array__dynamic_array_replay_source_neuron_index.read(reinterpret_cast<char*>(_static_array__dynamic_array_replay_source_neuron_index), 417*sizeof(int64_t));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_replay_source_neuron_index." << endl;
    }
    ifstream f_static_array__dynamic_array_replay_source_spike_number;
    f_static_array__dynamic_array_replay_source_spike_number.open("static_arrays/_static_array__dynamic_array_replay_source_spike_number", ios::in | ios::binary);
    if(f_static_array__dynamic_array_replay_source_spike_number.is_open())
    {
        f_static_array__dynamic_array_replay_source_spike_number.read(reinterpret_cast<char*>(_static_array__dynamic_array_replay_source_spike_number), 417*sizeof(int64_t));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_replay_source_spike_number." << endl;
    }
    ifstream f_static_array__dynamic_array_replay_source_spike_time;
    f_static_array__dynamic_array_replay_source_spike_time.open("static_arrays/_static_array__dynamic_array_replay_source_spike_time", ios::in | ios::binary);
    if(f_static_array__dynamic_array_replay_source_spike_time.is_open())
    {
        f_static_array__dynamic_array_replay_source_spike_time.read(reinterpret_cast<char*>(_static_array__dynamic_array_replay_source_spike_time), 417*sizeof(double));
    } else
    {
        std::cout << "Error opening static array _static_array__dynamic_array_replay_source_spike_time." << endl;
    }
}

void _write_arrays()
{
    using namespace brian;

    ofstream outfile__array_default_neurons__spikespace;
    outfile__array_default_neurons__spikespace.open(results_dir + "_array_default_neurons__spikespace_261038356", ios::binary | ios::out);
    if(outfile__array_default_neurons__spikespace.is_open())
    {
        outfile__array_default_neurons__spikespace.write(reinterpret_cast<char*>(_array_default_neurons__spikespace), 138640*sizeof(_array_default_neurons__spikespace[0]));
        outfile__array_default_neurons__spikespace.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_neurons__spikespace." << endl;
    }
    ofstream outfile__array_default_neurons_g;
    outfile__array_default_neurons_g.open(results_dir + "_array_default_neurons_g_817030174", ios::binary | ios::out);
    if(outfile__array_default_neurons_g.is_open())
    {
        outfile__array_default_neurons_g.write(reinterpret_cast<char*>(_array_default_neurons_g), 138639*sizeof(_array_default_neurons_g[0]));
        outfile__array_default_neurons_g.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_neurons_g." << endl;
    }
    ofstream outfile__array_default_neurons_i;
    outfile__array_default_neurons_i.open(results_dir + "_array_default_neurons_i_3607808281", ios::binary | ios::out);
    if(outfile__array_default_neurons_i.is_open())
    {
        outfile__array_default_neurons_i.write(reinterpret_cast<char*>(_array_default_neurons_i), 138639*sizeof(_array_default_neurons_i[0]));
        outfile__array_default_neurons_i.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_neurons_i." << endl;
    }
    ofstream outfile__array_default_neurons_lastspike;
    outfile__array_default_neurons_lastspike.open(results_dir + "_array_default_neurons_lastspike_4150403714", ios::binary | ios::out);
    if(outfile__array_default_neurons_lastspike.is_open())
    {
        outfile__array_default_neurons_lastspike.write(reinterpret_cast<char*>(_array_default_neurons_lastspike), 138639*sizeof(_array_default_neurons_lastspike[0]));
        outfile__array_default_neurons_lastspike.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_neurons_lastspike." << endl;
    }
    ofstream outfile__array_default_neurons_not_refractory;
    outfile__array_default_neurons_not_refractory.open(results_dir + "_array_default_neurons_not_refractory_701150063", ios::binary | ios::out);
    if(outfile__array_default_neurons_not_refractory.is_open())
    {
        outfile__array_default_neurons_not_refractory.write(reinterpret_cast<char*>(_array_default_neurons_not_refractory), 138639*sizeof(_array_default_neurons_not_refractory[0]));
        outfile__array_default_neurons_not_refractory.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_neurons_not_refractory." << endl;
    }
    ofstream outfile__array_default_neurons_rfc;
    outfile__array_default_neurons_rfc.open(results_dir + "_array_default_neurons_rfc_3473843883", ios::binary | ios::out);
    if(outfile__array_default_neurons_rfc.is_open())
    {
        outfile__array_default_neurons_rfc.write(reinterpret_cast<char*>(_array_default_neurons_rfc), 138639*sizeof(_array_default_neurons_rfc[0]));
        outfile__array_default_neurons_rfc.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_neurons_rfc." << endl;
    }
    ofstream outfile__array_default_neurons_v;
    outfile__array_default_neurons_v.open(results_dir + "_array_default_neurons_v_1510130924", ios::binary | ios::out);
    if(outfile__array_default_neurons_v.is_open())
    {
        outfile__array_default_neurons_v.write(reinterpret_cast<char*>(_array_default_neurons_v), 138639*sizeof(_array_default_neurons_v[0]));
        outfile__array_default_neurons_v.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_neurons_v." << endl;
    }
    ofstream outfile__array_default_synapses_N;
    outfile__array_default_synapses_N.open(results_dir + "_array_default_synapses_N_1867576527", ios::binary | ios::out);
    if(outfile__array_default_synapses_N.is_open())
    {
        outfile__array_default_synapses_N.write(reinterpret_cast<char*>(_array_default_synapses_N), 1*sizeof(_array_default_synapses_N[0]));
        outfile__array_default_synapses_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_synapses_N." << endl;
    }
    ofstream outfile__array_default_synapses_sources;
    outfile__array_default_synapses_sources.open(results_dir + "_array_default_synapses_sources_1061932104", ios::binary | ios::out);
    if(outfile__array_default_synapses_sources.is_open())
    {
        outfile__array_default_synapses_sources.write(reinterpret_cast<char*>(_array_default_synapses_sources), 15091983*sizeof(_array_default_synapses_sources[0]));
        outfile__array_default_synapses_sources.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_synapses_sources." << endl;
    }
    ofstream outfile__array_default_synapses_targets;
    outfile__array_default_synapses_targets.open(results_dir + "_array_default_synapses_targets_1112913833", ios::binary | ios::out);
    if(outfile__array_default_synapses_targets.is_open())
    {
        outfile__array_default_synapses_targets.write(reinterpret_cast<char*>(_array_default_synapses_targets), 15091983*sizeof(_array_default_synapses_targets[0]));
        outfile__array_default_synapses_targets.close();
    } else
    {
        std::cout << "Error writing output file for _array_default_synapses_targets." << endl;
    }
    ofstream outfile__array_defaultclock_dt;
    outfile__array_defaultclock_dt.open(results_dir + "_array_defaultclock_dt_1978099143", ios::binary | ios::out);
    if(outfile__array_defaultclock_dt.is_open())
    {
        outfile__array_defaultclock_dt.write(reinterpret_cast<char*>(_array_defaultclock_dt), 1*sizeof(_array_defaultclock_dt[0]));
        outfile__array_defaultclock_dt.close();
    } else
    {
        std::cout << "Error writing output file for _array_defaultclock_dt." << endl;
    }
    ofstream outfile__array_defaultclock_t;
    outfile__array_defaultclock_t.open(results_dir + "_array_defaultclock_t_2669362164", ios::binary | ios::out);
    if(outfile__array_defaultclock_t.is_open())
    {
        outfile__array_defaultclock_t.write(reinterpret_cast<char*>(_array_defaultclock_t), 1*sizeof(_array_defaultclock_t[0]));
        outfile__array_defaultclock_t.close();
    } else
    {
        std::cout << "Error writing output file for _array_defaultclock_t." << endl;
    }
    ofstream outfile__array_defaultclock_timestep;
    outfile__array_defaultclock_timestep.open(results_dir + "_array_defaultclock_timestep_144223508", ios::binary | ios::out);
    if(outfile__array_defaultclock_timestep.is_open())
    {
        outfile__array_defaultclock_timestep.write(reinterpret_cast<char*>(_array_defaultclock_timestep), 1*sizeof(_array_defaultclock_timestep[0]));
        outfile__array_defaultclock_timestep.close();
    } else
    {
        std::cout << "Error writing output file for _array_defaultclock_timestep." << endl;
    }
    ofstream outfile__array_reference_spikes__source_idx;
    outfile__array_reference_spikes__source_idx.open(results_dir + "_array_reference_spikes__source_idx_189273408", ios::binary | ios::out);
    if(outfile__array_reference_spikes__source_idx.is_open())
    {
        outfile__array_reference_spikes__source_idx.write(reinterpret_cast<char*>(_array_reference_spikes__source_idx), 138639*sizeof(_array_reference_spikes__source_idx[0]));
        outfile__array_reference_spikes__source_idx.close();
    } else
    {
        std::cout << "Error writing output file for _array_reference_spikes__source_idx." << endl;
    }
    ofstream outfile__array_reference_spikes_count;
    outfile__array_reference_spikes_count.open(results_dir + "_array_reference_spikes_count_3953053495", ios::binary | ios::out);
    if(outfile__array_reference_spikes_count.is_open())
    {
        outfile__array_reference_spikes_count.write(reinterpret_cast<char*>(_array_reference_spikes_count), 138639*sizeof(_array_reference_spikes_count[0]));
        outfile__array_reference_spikes_count.close();
    } else
    {
        std::cout << "Error writing output file for _array_reference_spikes_count." << endl;
    }
    ofstream outfile__array_reference_spikes_N;
    outfile__array_reference_spikes_N.open(results_dir + "_array_reference_spikes_N_1794194249", ios::binary | ios::out);
    if(outfile__array_reference_spikes_N.is_open())
    {
        outfile__array_reference_spikes_N.write(reinterpret_cast<char*>(_array_reference_spikes_N), 1*sizeof(_array_reference_spikes_N[0]));
        outfile__array_reference_spikes_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_reference_spikes_N." << endl;
    }
    ofstream outfile__array_replay_input_N;
    outfile__array_replay_input_N.open(results_dir + "_array_replay_input_N_3940080179", ios::binary | ios::out);
    if(outfile__array_replay_input_N.is_open())
    {
        outfile__array_replay_input_N.write(reinterpret_cast<char*>(_array_replay_input_N), 1*sizeof(_array_replay_input_N[0]));
        outfile__array_replay_input_N.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_input_N." << endl;
    }
    ofstream outfile__array_replay_input_sources;
    outfile__array_replay_input_sources.open(results_dir + "_array_replay_input_sources_3975791600", ios::binary | ios::out);
    if(outfile__array_replay_input_sources.is_open())
    {
        outfile__array_replay_input_sources.write(reinterpret_cast<char*>(_array_replay_input_sources), 21*sizeof(_array_replay_input_sources[0]));
        outfile__array_replay_input_sources.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_input_sources." << endl;
    }
    ofstream outfile__array_replay_input_targets;
    outfile__array_replay_input_targets.open(results_dir + "_array_replay_input_targets_2447882257", ios::binary | ios::out);
    if(outfile__array_replay_input_targets.is_open())
    {
        outfile__array_replay_input_targets.write(reinterpret_cast<char*>(_array_replay_input_targets), 21*sizeof(_array_replay_input_targets[0]));
        outfile__array_replay_input_targets.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_input_targets." << endl;
    }
    ofstream outfile__array_replay_source__lastindex;
    outfile__array_replay_source__lastindex.open(results_dir + "_array_replay_source__lastindex_4083790373", ios::binary | ios::out);
    if(outfile__array_replay_source__lastindex.is_open())
    {
        outfile__array_replay_source__lastindex.write(reinterpret_cast<char*>(_array_replay_source__lastindex), 1*sizeof(_array_replay_source__lastindex[0]));
        outfile__array_replay_source__lastindex.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_source__lastindex." << endl;
    }
    ofstream outfile__array_replay_source__period_bins;
    outfile__array_replay_source__period_bins.open(results_dir + "_array_replay_source__period_bins_2004626820", ios::binary | ios::out);
    if(outfile__array_replay_source__period_bins.is_open())
    {
        outfile__array_replay_source__period_bins.write(reinterpret_cast<char*>(_array_replay_source__period_bins), 1*sizeof(_array_replay_source__period_bins[0]));
        outfile__array_replay_source__period_bins.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_source__period_bins." << endl;
    }
    ofstream outfile__array_replay_source__spikespace;
    outfile__array_replay_source__spikespace.open(results_dir + "_array_replay_source__spikespace_724089594", ios::binary | ios::out);
    if(outfile__array_replay_source__spikespace.is_open())
    {
        outfile__array_replay_source__spikespace.write(reinterpret_cast<char*>(_array_replay_source__spikespace), 22*sizeof(_array_replay_source__spikespace[0]));
        outfile__array_replay_source__spikespace.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_source__spikespace." << endl;
    }
    ofstream outfile__array_replay_source_i;
    outfile__array_replay_source_i.open(results_dir + "_array_replay_source_i_1197262905", ios::binary | ios::out);
    if(outfile__array_replay_source_i.is_open())
    {
        outfile__array_replay_source_i.write(reinterpret_cast<char*>(_array_replay_source_i), 21*sizeof(_array_replay_source_i[0]));
        outfile__array_replay_source_i.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_source_i." << endl;
    }
    ofstream outfile__array_replay_source_period;
    outfile__array_replay_source_period.open(results_dir + "_array_replay_source_period_1492452586", ios::binary | ios::out);
    if(outfile__array_replay_source_period.is_open())
    {
        outfile__array_replay_source_period.write(reinterpret_cast<char*>(_array_replay_source_period), 1*sizeof(_array_replay_source_period[0]));
        outfile__array_replay_source_period.close();
    } else
    {
        std::cout << "Error writing output file for _array_replay_source_period." << endl;
    }

    ofstream outfile__dynamic_array_default_synapses__synaptic_post;
    outfile__dynamic_array_default_synapses__synaptic_post.open(results_dir + "_dynamic_array_default_synapses__synaptic_post_1892736623", ios::binary | ios::out);
    if(outfile__dynamic_array_default_synapses__synaptic_post.is_open())
    {
        if (! _dynamic_array_default_synapses__synaptic_post.empty() )
        {
            outfile__dynamic_array_default_synapses__synaptic_post.write(reinterpret_cast<char*>(&_dynamic_array_default_synapses__synaptic_post[0]), _dynamic_array_default_synapses__synaptic_post.size()*sizeof(_dynamic_array_default_synapses__synaptic_post[0]));
            outfile__dynamic_array_default_synapses__synaptic_post.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_default_synapses__synaptic_post." << endl;
    }
    ofstream outfile__dynamic_array_default_synapses__synaptic_pre;
    outfile__dynamic_array_default_synapses__synaptic_pre.open(results_dir + "_dynamic_array_default_synapses__synaptic_pre_3203942682", ios::binary | ios::out);
    if(outfile__dynamic_array_default_synapses__synaptic_pre.is_open())
    {
        if (! _dynamic_array_default_synapses__synaptic_pre.empty() )
        {
            outfile__dynamic_array_default_synapses__synaptic_pre.write(reinterpret_cast<char*>(&_dynamic_array_default_synapses__synaptic_pre[0]), _dynamic_array_default_synapses__synaptic_pre.size()*sizeof(_dynamic_array_default_synapses__synaptic_pre[0]));
            outfile__dynamic_array_default_synapses__synaptic_pre.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_default_synapses__synaptic_pre." << endl;
    }
    ofstream outfile__dynamic_array_default_synapses_delay;
    outfile__dynamic_array_default_synapses_delay.open(results_dir + "_dynamic_array_default_synapses_delay_178826599", ios::binary | ios::out);
    if(outfile__dynamic_array_default_synapses_delay.is_open())
    {
        if (! _dynamic_array_default_synapses_delay.empty() )
        {
            outfile__dynamic_array_default_synapses_delay.write(reinterpret_cast<char*>(&_dynamic_array_default_synapses_delay[0]), _dynamic_array_default_synapses_delay.size()*sizeof(_dynamic_array_default_synapses_delay[0]));
            outfile__dynamic_array_default_synapses_delay.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_default_synapses_delay." << endl;
    }
    ofstream outfile__dynamic_array_default_synapses_N_incoming;
    outfile__dynamic_array_default_synapses_N_incoming.open(results_dir + "_dynamic_array_default_synapses_N_incoming_1034973904", ios::binary | ios::out);
    if(outfile__dynamic_array_default_synapses_N_incoming.is_open())
    {
        if (! _dynamic_array_default_synapses_N_incoming.empty() )
        {
            outfile__dynamic_array_default_synapses_N_incoming.write(reinterpret_cast<char*>(&_dynamic_array_default_synapses_N_incoming[0]), _dynamic_array_default_synapses_N_incoming.size()*sizeof(_dynamic_array_default_synapses_N_incoming[0]));
            outfile__dynamic_array_default_synapses_N_incoming.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_default_synapses_N_incoming." << endl;
    }
    ofstream outfile__dynamic_array_default_synapses_N_outgoing;
    outfile__dynamic_array_default_synapses_N_outgoing.open(results_dir + "_dynamic_array_default_synapses_N_outgoing_447480330", ios::binary | ios::out);
    if(outfile__dynamic_array_default_synapses_N_outgoing.is_open())
    {
        if (! _dynamic_array_default_synapses_N_outgoing.empty() )
        {
            outfile__dynamic_array_default_synapses_N_outgoing.write(reinterpret_cast<char*>(&_dynamic_array_default_synapses_N_outgoing[0]), _dynamic_array_default_synapses_N_outgoing.size()*sizeof(_dynamic_array_default_synapses_N_outgoing[0]));
            outfile__dynamic_array_default_synapses_N_outgoing.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_default_synapses_N_outgoing." << endl;
    }
    ofstream outfile__dynamic_array_default_synapses_w;
    outfile__dynamic_array_default_synapses_w.open(results_dir + "_dynamic_array_default_synapses_w_937324336", ios::binary | ios::out);
    if(outfile__dynamic_array_default_synapses_w.is_open())
    {
        if (! _dynamic_array_default_synapses_w.empty() )
        {
            outfile__dynamic_array_default_synapses_w.write(reinterpret_cast<char*>(&_dynamic_array_default_synapses_w[0]), _dynamic_array_default_synapses_w.size()*sizeof(_dynamic_array_default_synapses_w[0]));
            outfile__dynamic_array_default_synapses_w.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_default_synapses_w." << endl;
    }
    ofstream outfile__dynamic_array_reference_spikes_i;
    outfile__dynamic_array_reference_spikes_i.open(results_dir + "_dynamic_array_reference_spikes_i_3362823637", ios::binary | ios::out);
    if(outfile__dynamic_array_reference_spikes_i.is_open())
    {
        if (! _dynamic_array_reference_spikes_i.empty() )
        {
            outfile__dynamic_array_reference_spikes_i.write(reinterpret_cast<char*>(&_dynamic_array_reference_spikes_i[0]), _dynamic_array_reference_spikes_i.size()*sizeof(_dynamic_array_reference_spikes_i[0]));
            outfile__dynamic_array_reference_spikes_i.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_reference_spikes_i." << endl;
    }
    ofstream outfile__dynamic_array_reference_spikes_t;
    outfile__dynamic_array_reference_spikes_t.open(results_dir + "_dynamic_array_reference_spikes_t_2876698892", ios::binary | ios::out);
    if(outfile__dynamic_array_reference_spikes_t.is_open())
    {
        if (! _dynamic_array_reference_spikes_t.empty() )
        {
            outfile__dynamic_array_reference_spikes_t.write(reinterpret_cast<char*>(&_dynamic_array_reference_spikes_t[0]), _dynamic_array_reference_spikes_t.size()*sizeof(_dynamic_array_reference_spikes_t[0]));
            outfile__dynamic_array_reference_spikes_t.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_reference_spikes_t." << endl;
    }
    ofstream outfile__dynamic_array_replay_input__synaptic_post;
    outfile__dynamic_array_replay_input__synaptic_post.open(results_dir + "_dynamic_array_replay_input__synaptic_post_4047175472", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_input__synaptic_post.is_open())
    {
        if (! _dynamic_array_replay_input__synaptic_post.empty() )
        {
            outfile__dynamic_array_replay_input__synaptic_post.write(reinterpret_cast<char*>(&_dynamic_array_replay_input__synaptic_post[0]), _dynamic_array_replay_input__synaptic_post.size()*sizeof(_dynamic_array_replay_input__synaptic_post[0]));
            outfile__dynamic_array_replay_input__synaptic_post.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_input__synaptic_post." << endl;
    }
    ofstream outfile__dynamic_array_replay_input__synaptic_pre;
    outfile__dynamic_array_replay_input__synaptic_pre.open(results_dir + "_dynamic_array_replay_input__synaptic_pre_3939490766", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_input__synaptic_pre.is_open())
    {
        if (! _dynamic_array_replay_input__synaptic_pre.empty() )
        {
            outfile__dynamic_array_replay_input__synaptic_pre.write(reinterpret_cast<char*>(&_dynamic_array_replay_input__synaptic_pre[0]), _dynamic_array_replay_input__synaptic_pre.size()*sizeof(_dynamic_array_replay_input__synaptic_pre[0]));
            outfile__dynamic_array_replay_input__synaptic_pre.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_input__synaptic_pre." << endl;
    }
    ofstream outfile__dynamic_array_replay_input_delay;
    outfile__dynamic_array_replay_input_delay.open(results_dir + "_dynamic_array_replay_input_delay_3725262493", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_input_delay.is_open())
    {
        if (! _dynamic_array_replay_input_delay.empty() )
        {
            outfile__dynamic_array_replay_input_delay.write(reinterpret_cast<char*>(&_dynamic_array_replay_input_delay[0]), _dynamic_array_replay_input_delay.size()*sizeof(_dynamic_array_replay_input_delay[0]));
            outfile__dynamic_array_replay_input_delay.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_input_delay." << endl;
    }
    ofstream outfile__dynamic_array_replay_input_N_incoming;
    outfile__dynamic_array_replay_input_N_incoming.open(results_dir + "_dynamic_array_replay_input_N_incoming_3643020149", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_input_N_incoming.is_open())
    {
        if (! _dynamic_array_replay_input_N_incoming.empty() )
        {
            outfile__dynamic_array_replay_input_N_incoming.write(reinterpret_cast<char*>(&_dynamic_array_replay_input_N_incoming[0]), _dynamic_array_replay_input_N_incoming.size()*sizeof(_dynamic_array_replay_input_N_incoming[0]));
            outfile__dynamic_array_replay_input_N_incoming.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_input_N_incoming." << endl;
    }
    ofstream outfile__dynamic_array_replay_input_N_outgoing;
    outfile__dynamic_array_replay_input_N_outgoing.open(results_dir + "_dynamic_array_replay_input_N_outgoing_4265108399", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_input_N_outgoing.is_open())
    {
        if (! _dynamic_array_replay_input_N_outgoing.empty() )
        {
            outfile__dynamic_array_replay_input_N_outgoing.write(reinterpret_cast<char*>(&_dynamic_array_replay_input_N_outgoing[0]), _dynamic_array_replay_input_N_outgoing.size()*sizeof(_dynamic_array_replay_input_N_outgoing[0]));
            outfile__dynamic_array_replay_input_N_outgoing.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_input_N_outgoing." << endl;
    }
    ofstream outfile__dynamic_array_replay_source__timebins;
    outfile__dynamic_array_replay_source__timebins.open(results_dir + "_dynamic_array_replay_source__timebins_3785916073", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_source__timebins.is_open())
    {
        if (! _dynamic_array_replay_source__timebins.empty() )
        {
            outfile__dynamic_array_replay_source__timebins.write(reinterpret_cast<char*>(&_dynamic_array_replay_source__timebins[0]), _dynamic_array_replay_source__timebins.size()*sizeof(_dynamic_array_replay_source__timebins[0]));
            outfile__dynamic_array_replay_source__timebins.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_source__timebins." << endl;
    }
    ofstream outfile__dynamic_array_replay_source_neuron_index;
    outfile__dynamic_array_replay_source_neuron_index.open(results_dir + "_dynamic_array_replay_source_neuron_index_1943832918", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_source_neuron_index.is_open())
    {
        if (! _dynamic_array_replay_source_neuron_index.empty() )
        {
            outfile__dynamic_array_replay_source_neuron_index.write(reinterpret_cast<char*>(&_dynamic_array_replay_source_neuron_index[0]), _dynamic_array_replay_source_neuron_index.size()*sizeof(_dynamic_array_replay_source_neuron_index[0]));
            outfile__dynamic_array_replay_source_neuron_index.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_source_neuron_index." << endl;
    }
    ofstream outfile__dynamic_array_replay_source_spike_number;
    outfile__dynamic_array_replay_source_spike_number.open(results_dir + "_dynamic_array_replay_source_spike_number_3456614", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_source_spike_number.is_open())
    {
        if (! _dynamic_array_replay_source_spike_number.empty() )
        {
            outfile__dynamic_array_replay_source_spike_number.write(reinterpret_cast<char*>(&_dynamic_array_replay_source_spike_number[0]), _dynamic_array_replay_source_spike_number.size()*sizeof(_dynamic_array_replay_source_spike_number[0]));
            outfile__dynamic_array_replay_source_spike_number.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_source_spike_number." << endl;
    }
    ofstream outfile__dynamic_array_replay_source_spike_time;
    outfile__dynamic_array_replay_source_spike_time.open(results_dir + "_dynamic_array_replay_source_spike_time_27300911", ios::binary | ios::out);
    if(outfile__dynamic_array_replay_source_spike_time.is_open())
    {
        if (! _dynamic_array_replay_source_spike_time.empty() )
        {
            outfile__dynamic_array_replay_source_spike_time.write(reinterpret_cast<char*>(&_dynamic_array_replay_source_spike_time[0]), _dynamic_array_replay_source_spike_time.size()*sizeof(_dynamic_array_replay_source_spike_time[0]));
            outfile__dynamic_array_replay_source_spike_time.close();
        }
    } else
    {
        std::cout << "Error writing output file for _dynamic_array_replay_source_spike_time." << endl;
    }

    // Write last run info to disk
    ofstream outfile_last_run_info;
    outfile_last_run_info.open(results_dir + "last_run_info.txt", ios::out);
    if(outfile_last_run_info.is_open())
    {
        outfile_last_run_info << (Network::_last_run_time) << " " << (Network::_last_run_completed_fraction) << std::endl;
        outfile_last_run_info.close();
    } else
    {
        std::cout << "Error writing last run info to file." << std::endl;
    }
}

void _dealloc_arrays()
{
    using namespace brian;


    // static arrays
    if(_static_array__array_default_neurons_rfc!=0)
    {
        delete [] _static_array__array_default_neurons_rfc;
        _static_array__array_default_neurons_rfc = 0;
    }
    if(_static_array__array_default_synapses_sources!=0)
    {
        delete [] _static_array__array_default_synapses_sources;
        _static_array__array_default_synapses_sources = 0;
    }
    if(_static_array__array_default_synapses_targets!=0)
    {
        delete [] _static_array__array_default_synapses_targets;
        _static_array__array_default_synapses_targets = 0;
    }
    if(_static_array__array_replay_input_sources!=0)
    {
        delete [] _static_array__array_replay_input_sources;
        _static_array__array_replay_input_sources = 0;
    }
    if(_static_array__array_replay_input_targets!=0)
    {
        delete [] _static_array__array_replay_input_targets;
        _static_array__array_replay_input_targets = 0;
    }
    if(_static_array__dynamic_array_default_synapses_w!=0)
    {
        delete [] _static_array__dynamic_array_default_synapses_w;
        _static_array__dynamic_array_default_synapses_w = 0;
    }
    if(_static_array__dynamic_array_replay_source__timebins!=0)
    {
        delete [] _static_array__dynamic_array_replay_source__timebins;
        _static_array__dynamic_array_replay_source__timebins = 0;
    }
    if(_static_array__dynamic_array_replay_source_neuron_index!=0)
    {
        delete [] _static_array__dynamic_array_replay_source_neuron_index;
        _static_array__dynamic_array_replay_source_neuron_index = 0;
    }
    if(_static_array__dynamic_array_replay_source_spike_number!=0)
    {
        delete [] _static_array__dynamic_array_replay_source_spike_number;
        _static_array__dynamic_array_replay_source_spike_number = 0;
    }
    if(_static_array__dynamic_array_replay_source_spike_time!=0)
    {
        delete [] _static_array__dynamic_array_replay_source_spike_time;
        _static_array__dynamic_array_replay_source_spike_time = 0;
    }
}

