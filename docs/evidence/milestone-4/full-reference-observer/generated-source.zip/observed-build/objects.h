
#ifndef _BRIAN_OBJECTS_H
#define _BRIAN_OBJECTS_H

#include "synapses_classes.h"
#include "brianlib/clocks.h"
#include "brianlib/dynamic_array.h"
#include "brianlib/stdint_compat.h"
#include "network.h"
#include<random>
#include<vector>


namespace brian {

extern std::string results_dir;

class RandomGenerator {
    private:
        std::mt19937 gen;
        double stored_gauss;
        bool has_stored_gauss = false;
    public:
        RandomGenerator() {
            seed();
        }
        void seed() {
            std::random_device rd;
            gen.seed(rd());
            has_stored_gauss = false;
        }
        void seed(unsigned long seed) {
            gen.seed(seed);
            has_stored_gauss = false;
        }
        double rand() {
            /* shifts : 67108864 = 0x4000000, 9007199254740992 = 0x20000000000000 */
            const long a = gen() >> 5;
            const long b = gen() >> 6;
            return (a * 67108864.0 + b) / 9007199254740992.0;
        }

        double randn() {
            if (has_stored_gauss) {
                const double tmp = stored_gauss;
                has_stored_gauss = false;
                return tmp;
            }
            else {
                double f, x1, x2, r2;

                do {
                    x1 = 2.0*rand() - 1.0;
                    x2 = 2.0*rand() - 1.0;
                    r2 = x1*x1 + x2*x2;
                }
                while (r2 >= 1.0 || r2 == 0.0);

                /* Box-Muller transform */
                f = sqrt(-2.0*log(r2)/r2);
                /* Keep for next call */
                stored_gauss = f*x1;
                has_stored_gauss = true;
                return f*x2;
            }
        }
};

// In OpenMP we need one state per thread
extern std::vector< RandomGenerator > _random_generators;

//////////////// clocks ///////////////////
extern Clock defaultclock;

//////////////// networks /////////////////
extern Network reference_network;



void set_variable_by_name(std::string, std::string);

//////////////// dynamic arrays ///////////
extern std::vector<int32_t> _dynamic_array_default_synapses__synaptic_post;
extern std::vector<int32_t> _dynamic_array_default_synapses__synaptic_pre;
extern std::vector<double> _dynamic_array_default_synapses_delay;
extern std::vector<int32_t> _dynamic_array_default_synapses_N_incoming;
extern std::vector<int32_t> _dynamic_array_default_synapses_N_outgoing;
extern std::vector<double> _dynamic_array_default_synapses_w;
extern std::vector<double> _dynamic_array_reference_before_t;
extern std::vector<double> _dynamic_array_reference_end_t;
extern std::vector<double> _dynamic_array_reference_pre_t;
extern std::vector<int32_t> _dynamic_array_reference_spikes_i;
extern std::vector<double> _dynamic_array_reference_spikes_t;
extern std::vector<int32_t> _dynamic_array_replay_input__synaptic_post;
extern std::vector<int32_t> _dynamic_array_replay_input__synaptic_pre;
extern std::vector<double> _dynamic_array_replay_input_delay;
extern std::vector<int32_t> _dynamic_array_replay_input_N_incoming;
extern std::vector<int32_t> _dynamic_array_replay_input_N_outgoing;
extern std::vector<int32_t> _dynamic_array_replay_source__timebins;
extern std::vector<int32_t> _dynamic_array_replay_source_neuron_index;
extern std::vector<int32_t> _dynamic_array_replay_source_spike_number;
extern std::vector<double> _dynamic_array_replay_source_spike_time;

//////////////// arrays ///////////////////
extern int32_t *_array_default_neurons__spikespace;
extern const int _num__array_default_neurons__spikespace;
extern double *_array_default_neurons_g;
extern const int _num__array_default_neurons_g;
extern int32_t *_array_default_neurons_i;
extern const int _num__array_default_neurons_i;
extern double *_array_default_neurons_lastspike;
extern const int _num__array_default_neurons_lastspike;
extern char *_array_default_neurons_not_refractory;
extern const int _num__array_default_neurons_not_refractory;
extern double *_array_default_neurons_rfc;
extern const int _num__array_default_neurons_rfc;
extern double *_array_default_neurons_v;
extern const int _num__array_default_neurons_v;
extern int32_t *_array_default_synapses_N;
extern const int _num__array_default_synapses_N;
extern int32_t *_array_default_synapses_sources;
extern const int _num__array_default_synapses_sources;
extern int32_t *_array_default_synapses_targets;
extern const int _num__array_default_synapses_targets;
extern double *_array_defaultclock_dt;
extern const int _num__array_defaultclock_dt;
extern double *_array_defaultclock_t;
extern const int _num__array_defaultclock_t;
extern int64_t *_array_defaultclock_timestep;
extern const int _num__array_defaultclock_timestep;
extern int32_t *_array_reference_before__indices;
extern const int _num__array_reference_before__indices;
extern double *_array_reference_before_g;
extern const int _num__array_reference_before_g;
extern int32_t *_array_reference_before_N;
extern const int _num__array_reference_before_N;
extern char *_array_reference_before_not_refractory;
extern const int _num__array_reference_before_not_refractory;
extern double *_array_reference_before_v;
extern const int _num__array_reference_before_v;
extern int32_t *_array_reference_end__indices;
extern const int _num__array_reference_end__indices;
extern double *_array_reference_end_g;
extern const int _num__array_reference_end_g;
extern double *_array_reference_end_lastspike;
extern const int _num__array_reference_end_lastspike;
extern int32_t *_array_reference_end_N;
extern const int _num__array_reference_end_N;
extern char *_array_reference_end_not_refractory;
extern const int _num__array_reference_end_not_refractory;
extern double *_array_reference_end_v;
extern const int _num__array_reference_end_v;
extern int32_t *_array_reference_pre__indices;
extern const int _num__array_reference_pre__indices;
extern double *_array_reference_pre_g;
extern const int _num__array_reference_pre_g;
extern int32_t *_array_reference_pre_N;
extern const int _num__array_reference_pre_N;
extern char *_array_reference_pre_not_refractory;
extern const int _num__array_reference_pre_not_refractory;
extern double *_array_reference_pre_v;
extern const int _num__array_reference_pre_v;
extern int32_t *_array_reference_spikes__source_idx;
extern const int _num__array_reference_spikes__source_idx;
extern int32_t *_array_reference_spikes_count;
extern const int _num__array_reference_spikes_count;
extern int32_t *_array_reference_spikes_N;
extern const int _num__array_reference_spikes_N;
extern int32_t *_array_replay_input_N;
extern const int _num__array_replay_input_N;
extern int32_t *_array_replay_input_sources;
extern const int _num__array_replay_input_sources;
extern int32_t *_array_replay_input_targets;
extern const int _num__array_replay_input_targets;
extern int32_t *_array_replay_source__lastindex;
extern const int _num__array_replay_source__lastindex;
extern int32_t *_array_replay_source__period_bins;
extern const int _num__array_replay_source__period_bins;
extern int32_t *_array_replay_source__spikespace;
extern const int _num__array_replay_source__spikespace;
extern int32_t *_array_replay_source_i;
extern const int _num__array_replay_source_i;
extern double *_array_replay_source_period;
extern const int _num__array_replay_source_period;

//////////////// dynamic arrays 2d /////////
extern DynamicArray2D<double> _dynamic_array_reference_before_g;
extern DynamicArray2D<char> _dynamic_array_reference_before_not_refractory;
extern DynamicArray2D<double> _dynamic_array_reference_before_v;
extern DynamicArray2D<double> _dynamic_array_reference_end_g;
extern DynamicArray2D<double> _dynamic_array_reference_end_lastspike;
extern DynamicArray2D<char> _dynamic_array_reference_end_not_refractory;
extern DynamicArray2D<double> _dynamic_array_reference_end_v;
extern DynamicArray2D<double> _dynamic_array_reference_pre_g;
extern DynamicArray2D<char> _dynamic_array_reference_pre_not_refractory;
extern DynamicArray2D<double> _dynamic_array_reference_pre_v;

/////////////// static arrays /////////////
extern double *_static_array__array_default_neurons_rfc;
extern const int _num__static_array__array_default_neurons_rfc;
extern int32_t *_static_array__array_default_synapses_sources;
extern const int _num__static_array__array_default_synapses_sources;
extern int32_t *_static_array__array_default_synapses_targets;
extern const int _num__static_array__array_default_synapses_targets;
extern int32_t *_static_array__array_reference_before__indices;
extern const int _num__static_array__array_reference_before__indices;
extern int32_t *_static_array__array_reference_end__indices;
extern const int _num__static_array__array_reference_end__indices;
extern int32_t *_static_array__array_reference_pre__indices;
extern const int _num__static_array__array_reference_pre__indices;
extern int32_t *_static_array__array_replay_input_sources;
extern const int _num__static_array__array_replay_input_sources;
extern int32_t *_static_array__array_replay_input_targets;
extern const int _num__static_array__array_replay_input_targets;
extern double *_static_array__dynamic_array_default_synapses_w;
extern const int _num__static_array__dynamic_array_default_synapses_w;
extern int32_t *_static_array__dynamic_array_replay_source__timebins;
extern const int _num__static_array__dynamic_array_replay_source__timebins;
extern int64_t *_static_array__dynamic_array_replay_source_neuron_index;
extern const int _num__static_array__dynamic_array_replay_source_neuron_index;
extern int64_t *_static_array__dynamic_array_replay_source_spike_number;
extern const int _num__static_array__dynamic_array_replay_source_spike_number;
extern double *_static_array__dynamic_array_replay_source_spike_time;
extern const int _num__static_array__dynamic_array_replay_source_spike_time;

//////////////// synapses /////////////////
// default_synapses
extern SynapticPathway default_synapses_pre;
// replay_input
extern SynapticPathway replay_input_pre;

// Profiling information for each code object
}

void _init_arrays();
void _load_arrays();
void _write_arrays();
void _dealloc_arrays();

#endif


