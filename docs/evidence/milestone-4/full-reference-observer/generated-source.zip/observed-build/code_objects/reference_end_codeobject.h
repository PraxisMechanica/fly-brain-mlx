#ifndef _INCLUDED_reference_end_codeobject
#define _INCLUDED_reference_end_codeobject

void _run_reference_end_codeobject();


#endif
