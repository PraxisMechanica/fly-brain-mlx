#ifndef _INCLUDED_replay_input_pre_push_spikes
#define _INCLUDED_replay_input_pre_push_spikes

void _run_replay_input_pre_push_spikes();


#endif
