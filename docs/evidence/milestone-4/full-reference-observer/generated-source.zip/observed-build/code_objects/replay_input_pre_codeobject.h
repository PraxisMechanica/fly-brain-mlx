#ifndef _INCLUDED_replay_input_pre_codeobject
#define _INCLUDED_replay_input_pre_codeobject

void _run_replay_input_pre_codeobject();

void _debugmsg_replay_input_pre_codeobject();

#endif
