#ifndef _INCLUDED_reference_spikes_codeobject
#define _INCLUDED_reference_spikes_codeobject

void _run_reference_spikes_codeobject();

void _debugmsg_reference_spikes_codeobject();

#endif
