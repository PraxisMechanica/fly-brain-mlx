#ifndef _INCLUDED_reference_pre_codeobject
#define _INCLUDED_reference_pre_codeobject

void _run_reference_pre_codeobject();


#endif
