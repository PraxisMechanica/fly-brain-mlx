#ifndef _INCLUDED_reference_before_codeobject
#define _INCLUDED_reference_before_codeobject

void _run_reference_before_codeobject();


#endif
