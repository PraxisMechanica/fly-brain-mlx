# Code quality package

`@eng-metrics/code-quality` is the analysis engine used by the code-quality application. It provides an ECMAScript module (ESM), TypeScript declarations, and a command-line tool. It does not need the application server, credentials, or a database.

## Use the package

From this repository, run `pnpm --dir packages/code-quality pack --pack-destination ../../tmp/quality-gates`. Install the resulting archive in another project with `pnpm add -D /absolute/path/eng-metrics-code-quality-0.1.0.tgz`. The package is ready for archive installation; it has not been published to a registry.

Node.js 22 or later and Git are required. Python files also require Radon 6.0.1: `uv tool install radon==6.0.1`. C# requires a C++ build toolchain when a matching native prebuild is unavailable. Consumers that use pnpm must allow the pinned `tree-sitter-c-sharp` and `@ast-grep/lang-go` install scripts in their `onlyBuiltDependencies` setting. If those scripts were skipped during installation, run `pnpm rebuild tree-sitter-c-sharp @ast-grep/lang-go` after adding that setting.

```js
import { analyzeSnapshot, checkStaged, checkCommits } from '@eng-metrics/code-quality';

const snapshot = await analyzeSnapshot({ repositoryPath: '/path/to/repository', revision: 'HEAD' });
console.log(snapshot.summary);

const staged = await checkStaged({ repositoryPath: '/path/to/repository' });
if (!staged.passed) console.error(staged.findings);

const range = await checkCommits({ repositoryPath: '/path/to/repository', base: 'main', head: 'HEAD' });
if (!range.passed) console.error(range.commits);
```

```sh
pnpm exec code-quality analyze --revision HEAD --json quality-report.json
pnpm exec code-quality check --staged
pnpm exec code-quality check --base main --head HEAD --json quality-report.json
```

The staged check reads the Git index through `git write-tree`. It does not check the working copy and does not stash or change source files. The range check compares every submitted commit with each of its parents. A later repair cannot hide an earlier regression. Both sides use the same installed analyzer. New repositories establish their first measured baseline explicitly.

Exit codes are 0 for a passing check or successful analysis, 1 for a metric regression, and 2 for an analysis or command error. An unsupported source language, failed parser, missing tool, missing history, or empty source scope must not be presented as clean coverage. Unsupported file paths are listed in each snapshot. Unsupported non-source assets do not fail an otherwise covered source scope.

## Git hooks and GitHub Actions

A consuming project's Git pre-commit hook can run:

```sh
#!/bin/sh
set -eu
exec pnpm exec code-quality check --staged
```

For the Python `pre-commit` framework, use a local hook after installing the package:

```yaml
repos:
  - repo: local
    hooks:
      - id: code-quality
        name: Code quality regression gate
        language: system
        entry: pnpm exec code-quality check --staged
        pass_filenames: false
        always_run: true
```

A GitHub Actions step can run the same command against explicit commit references. Fetch complete history and pass event data through action inputs or environment variables, rather than putting untrusted values directly in a shell script. This repository's `.github/workflows/code-quality.yml` and `scripts/quality-ci.mjs` are the complete working example.

See [the gate specification](../../docs/quality-gates.md) for exact predicates, scope, and limits.
