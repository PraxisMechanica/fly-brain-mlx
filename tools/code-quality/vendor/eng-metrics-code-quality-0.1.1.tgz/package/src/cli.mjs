#!/usr/bin/env node
import { parseArgs } from 'node:util';
import { writeFile } from 'node:fs/promises';

try {
  const { analyzeSnapshot, checkStaged, checkCommits } = await import('./index.mjs');
  const { values, positionals } = parseArgs({ allowPositionals: true, options: { repo: { type: 'string', default: '.' }, revision: { type: 'string', default: 'HEAD' }, base: { type: 'string' }, head: { type: 'string', default: 'HEAD' }, staged: { type: 'boolean' }, json: { type: 'string' } } });
  const [command] = positionals;
  let result;
  if (command === 'analyze') result = await analyzeSnapshot({ repositoryPath: values.repo, revision: values.revision });
  else if (command === 'check' && values.staged) result = await checkStaged({ repositoryPath: values.repo });
  else if (command === 'check' && values.base) result = await checkCommits({ repositoryPath: values.repo, base: values.base, head: values.head });
  else throw new Error('Use code-quality analyze [--revision HEAD] or code-quality check --staged / --base REF [--head HEAD]');
  if (values.json) await writeFile(values.json, JSON.stringify(result, null, 2) + '\n');
  const comparisons = result.commits ? result.commits.flatMap(commit => commit.comparisons) : result.after ? [result] : [];
  for (const comparison of comparisons) {
    console.log(`${comparison.after.revision}: ${comparison.passed ? 'PASS' : 'FAIL'}`);
    console.table({ before: comparison.before?.summary, after: comparison.after.summary });
    for (const finding of comparison.findings) console.error(`${finding.rule} ${finding.path}: ${finding.metric} ${finding.before.toFixed(4)} → ${finding.after.toFixed(4)}`);
  }
  if (!comparisons.length) console.log(JSON.stringify(result.summary || { passed: result.passed, commits: result.commits.length }, null, 2));
  process.exitCode = result.passed === false ? 1 : 0;
} catch (error) {
  console.error(`Analysis failed: ${error.message}`);
  process.exitCode = 2;
}
