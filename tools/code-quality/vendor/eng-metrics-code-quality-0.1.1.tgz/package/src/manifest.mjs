import { createHash } from 'node:crypto';
import path from 'node:path';
import { configuredCSharpSymbols } from './csharp-preprocessor.mjs';

export const CSHARP_GRAMMAR_REVISION = '8c0abe0b84a3681d3e6852ce2e2a1eecb4f731c5';

export const LANGUAGE_EXTENSIONS = Object.freeze({
  '.js': 'javascript', '.jsx': 'javascript', '.mjs': 'javascript', '.cjs': 'javascript',
  '.ts': 'typescript', '.tsx': 'typescript', '.mts': 'typescript', '.cts': 'typescript',
  '.py': 'python', '.cs': 'csharp', '.go': 'go',
});
export const EXCLUDED_DIRECTORIES = new Set(['node_modules', 'dist', 'build', 'bin', 'obj', 'vendor']);
export const DUPLICATION_SETTINGS = Object.freeze({ minTokens: 50, minLines: 5 });

/** @param {string} a @param {string} b */
export function compareIdentityStrings(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** @param {unknown} value */
export function fingerprint(value) {
  return createHash('sha256').update(JSON.stringify(canonicalize(value))).digest('hex');
}

/** @param {unknown} value @returns {unknown} */
function canonicalize(value) {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).sort(([a], [b]) => compareIdentityStrings(a, b)).map(([key, item]) => [key, canonicalize(item)]));
  }
  return value;
}


export function createAnalysisManifest() {
  return {
    languages: {
      javascript: fingerprint({ algorithm: 'javascript-v2', typescript: '5.9.3' }),
      typescript: fingerprint({ algorithm: 'javascript-v1', language: 'typescript' }),
      python: fingerprint({ algorithm: 'python-v3-whole-file', radon: '6.0.1' }),
      csharp: fingerprint({ algorithm: 'csharp-v3', parser: CSHARP_GRAMMAR_REVISION, astGrep: '0.45.3', symbols: configuredCSharpSymbols() }),
      go: fingerprint({ algorithm: 'go-v1', parser: '0.0.6', astGrep: '0.45.3' }),
    },
    discovery_key: fingerprint({ extensions: LANGUAGE_EXTENSIONS, exclusions: [...EXCLUDED_DIRECTORIES].sort(), hidden: true, gitRegularFiles: true }),
    summary_key: fingerprint({ algorithm: 'summary-v1', maintainability: 'maintainability-v1' }),
    duplication_key: fingerprint({ algorithm: 'duplication-v2', jscpd: '4.0.8', tokenizer: '4.0.4', ...DUPLICATION_SETTINGS }),
  };
}

/** @param {string} filePath */
export function getFileLanguage(filePath) {
  return /** @type {Record<string, string>} */ (LANGUAGE_EXTENSIONS)[path.posix.extname(filePath).toLowerCase()] ?? null;
}

/** @param {string} filePath */
export function isIncludedPath(filePath) {
  const parts = filePath.split('/');
  return !parts.some((part) => part.startsWith('.')) &&
    !parts.slice(0, -1).some((part) => EXCLUDED_DIRECTORIES.has(part)) &&
    !/\.(min|bundle)\.js$/i.test(filePath);
}

/**
 * @param {Record<string, unknown> | null} metrics
 * @param {ReturnType<typeof createAnalysisManifest>} manifest
 */
export function isAnalysisCurrent(metrics, manifest) {
  if (!metrics || metrics.discovery_key !== manifest.discovery_key || metrics.summary_key !== manifest.summary_key || typeof metrics.duplication_key !== 'string') return false;
  const coverage = /** @type {Record<string, string> | null} */ (metrics.language_coverage);
  return Boolean(coverage && Object.keys(coverage).length === Object.keys(manifest.languages).length &&
    Object.entries(manifest.languages).every(([language, key]) => coverage[language] === key) &&
    metrics.duplication_key.startsWith(`${manifest.duplication_key}:`));
}

/** @param {unknown} manifest */
export function assertWorkerManifest(manifest) {
  if (fingerprint(manifest) !== fingerprint(createAnalysisManifest())) {
    throw new Error('Worker analyzers do not match the job manifest. Restart analysis with the current deployment.');
  }
}
