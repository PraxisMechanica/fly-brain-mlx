import { promises as fs } from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const decisions = new Set([ts.SyntaxKind.IfStatement, ts.SyntaxKind.ForStatement, ts.SyntaxKind.ForInStatement, ts.SyntaxKind.ForOfStatement, ts.SyntaxKind.WhileStatement, ts.SyntaxKind.DoStatement, ts.SyntaxKind.CatchClause, ts.SyntaxKind.ConditionalExpression]);
const logical = new Set([ts.SyntaxKind.AmpersandAmpersandToken, ts.SyntaxKind.BarBarToken, ts.SyntaxKind.QuestionQuestionToken, ts.SyntaxKind.AmpersandAmpersandEqualsToken, ts.SyntaxKind.BarBarEqualsToken, ts.SyntaxKind.QuestionQuestionEqualsToken]);

export function calculateJavaScriptComplexity(content, language = 'TypeScript') {
  const source = content.replace(/^\uFEFF/, '');
  const script = language === 'JavaScript' ? ts.ScriptKind.JSX : ts.ScriptKind.TS;
  let root = ts.createSourceFile('source.ts', source, ts.ScriptTarget.Latest, true, script);
  if (script === ts.ScriptKind.TS && root.parseDiagnostics.length) root = ts.createSourceFile('source.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  if (root.parseDiagnostics.length) {
    const diagnostic = root.parseDiagnostics[0];
    const line = root.getLineAndCharacterOfPosition(diagnostic.start).line + 1;
    throw new SyntaxError(`JavaScript/TypeScript parser rejected syntax at line ${line}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText, ' ')}`);
  }
  let cyclomatic = 1;
  let cognitive = 0;
  function visit(node, nesting) {
    let childNesting = nesting;
    if (decisions.has(node.kind)) { cyclomatic++; cognitive += 1 + nesting; childNesting++; }
    if (node.kind === ts.SyntaxKind.CaseClause) cyclomatic++;
    if (node.kind === ts.SyntaxKind.SwitchStatement) { cognitive += 1 + nesting; childNesting++; }
    if (ts.isBinaryExpression(node) && logical.has(node.operatorToken.kind)) {
      cyclomatic++;
      if (!ts.isBinaryExpression(node.parent) || node.parent.operatorToken.kind !== node.operatorToken.kind) cognitive++;
    }
    if (node.kind === ts.SyntaxKind.BreakStatement || node.kind === ts.SyntaxKind.ContinueStatement) cognitive++;
    ts.forEachChild(node, child => visit(child, childNesting));
  }
  visit(root, 0);
  return { cyclomatic_complexity: cyclomatic, cognitive_complexity: cognitive, lines_of_code: content.split('\n').filter(line => line.trim() !== '').length };
}

export function calculateCognitiveComplexity(content) {
  return calculateJavaScriptComplexity(content).cognitive_complexity;
}

export async function analyzeJavaScriptComplexity(filePath) {
  const language = ['.ts', '.tsx', '.mts', '.cts'].includes(path.extname(filePath).toLowerCase()) ? 'TypeScript' : 'JavaScript';
  return calculateJavaScriptComplexity(await fs.readFile(filePath, 'utf8'), language);
}
