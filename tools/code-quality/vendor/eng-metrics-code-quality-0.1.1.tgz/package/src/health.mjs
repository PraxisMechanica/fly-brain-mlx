/** @param {number} complexity @param {number} loc */
export function calculateMaintainabilityIndex(complexity, loc) {
    if (loc <= 0)
        return 100;
    if (complexity <= 0)
        complexity = 1;
    let score = 100;
    const locPenalty = Math.min(30, (loc / 100) * 5);
    score -= locPenalty;
    const complexityPenalty = Math.min(40, Math.max(0, complexity - 1) * 3);
    score -= complexityPenalty;
    const complexityDensity = (complexity / Math.max(loc, 1)) * 100;
    const densityPenalty = Math.min(20, complexityDensity * 2);
    score -= densityPenalty;
    return Math.max(0, Math.min(100, Math.round(score * 100) / 100));
}
