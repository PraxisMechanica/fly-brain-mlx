import { execa } from 'execa';
import { analyzeSnapshot } from './snapshot.mjs';
import { compareSnapshots } from './gate.mjs';
import { readHead, resolveCommit as resolve } from './git-reference.mjs';

const git = async (repositoryPath, args) => (await execa('git', ['-C', repositoryPath, ...args])).stdout;

async function renamedPaths(repositoryPath, before, after) {
  const records = (await git(repositoryPath, ['diff', '--name-status', '-z', '--find-renames', before, after, '--'])).split('\0');
  const renames = new Map();
  for (let index = 0; index < records.length - 1;) {
    const status = records[index++];
    const previous = records[index++];
    if (status.startsWith('R') || status.startsWith('C')) {
      const next = records[index++];
      if (status.startsWith('R')) renames.set(next, previous);
    }
  }
  return renames;
}

async function checkPair(repositoryPath, before, after, cache) {
  const baseline = await analyzeSnapshot({ repositoryPath, revision: before, cache });
  const candidate = await analyzeSnapshot({ repositoryPath, revision: after, cache });
  return compareSnapshots(baseline, candidate, await renamedPaths(repositoryPath, before, after));
}

export async function checkStaged({ repositoryPath = '.' } = {}) {
  const before = await readHead(repositoryPath);
  const after = (await git(repositoryPath, ['write-tree'])).trim();
  if (!before) return { passed: true, findings: [], before: null, after: await analyzeSnapshot({ repositoryPath, revision: after }), initial: true };
  return checkPair(repositoryPath, before, after, new Map());
}

export async function checkCommits({ repositoryPath = '.', base, head = 'HEAD' }) {
  const target = await resolve(repositoryPath, head);
  const boundary = await resolve(repositoryPath, base);
  const revisions = (await git(repositoryPath, ['rev-list', '--reverse', '--topo-order', `${boundary}..${target}`])).split('\n').filter(Boolean);
  const cache = new Map();
  const results = [];
  for (const commit of revisions) {
    const parents = (await git(repositoryPath, ['rev-list', '--parents', '-n', '1', commit])).trim().split(' ').slice(1);
    const comparisons = parents.length ? await Promise.all(parents.map(parent => checkPair(repositoryPath, parent, commit, cache))) : [];
    if (!parents.length) comparisons.push({ passed: true, findings: [], before: null, after: await analyzeSnapshot({ repositoryPath, revision: commit, cache }), initial: true });
    results.push({ commit, comparisons, passed: comparisons.every(result => result.passed) });
  }
  return { passed: results.every(result => result.passed), base: boundary, head: target, commits: results };
}
