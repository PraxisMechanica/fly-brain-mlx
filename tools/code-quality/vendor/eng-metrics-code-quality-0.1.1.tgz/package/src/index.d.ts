export interface Calculation { cyclomatic_complexity: number; cognitive_complexity: number; lines_of_code: number; }
export interface FileMetrics extends Calculation { path: string; language: string; blob: string; code_health: number; maintainability_index: number; }
export interface Summary { total_files: number; total_loc: number; avg_cyclomatic_complexity: number; max_cyclomatic_complexity: number; code_health: number; maintainability_index: number; }
export interface Snapshot { revision: string; tree: string; analyzer: string; files: FileMetrics[]; summary: Summary; unsupported_paths: string[]; }
export interface Finding { rule: 'CQ001' | 'CQ002' | 'CQ003'; path: string; metric: string; before: number; after: number; }
export interface Comparison { passed: boolean; findings: Finding[]; before: Snapshot | null; after: Snapshot; initial?: boolean; }
export interface CommitCheck { passed: boolean; base: string; head: string; commits: { commit: string; comparisons: Comparison[]; passed: boolean }[]; }
export function analyzeSnapshot(options?: { repositoryPath?: string; revision?: string; cache?: Map<string, Calculation> }): Promise<Snapshot>;
export function compareSnapshots(before: Snapshot, after: Snapshot, renames?: Map<string, string>): Comparison;
export function checkStaged(options?: { repositoryPath?: string }): Promise<Comparison>;
export function checkCommits(options: { repositoryPath?: string; base: string; head?: string }): Promise<CommitCheck>;
export function analyzeLanguageFile(path: string, language: string): Promise<Calculation>;
export function calculateJavaScriptComplexity(content: string, language?: string): Calculation;
export function calculateCSharpComplexity(content: string, definedSymbols?: string[]): Calculation;
export function calculateGoComplexity(content: string): Calculation;
export function calculateMaintainabilityIndex(complexity: number, lines: number): number;
export function getFileLanguage(path: string): string | null;
export function isIncludedPath(path: string): boolean;
export function createAnalysisManifest(): { languages: Record<string, string>; discovery_key: string; summary_key: string; duplication_key: string; };
