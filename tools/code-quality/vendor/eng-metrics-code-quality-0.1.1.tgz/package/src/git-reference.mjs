import { execa } from 'execa';

export async function resolveCommit(repositoryPath, revision) {
  return (await execa('git', ['-C', repositoryPath, 'rev-parse', '--verify', '--end-of-options', `${revision}^{commit}`])).stdout.trim();
}

export async function readHead(repositoryPath) {
  try { return await resolveCommit(repositoryPath, 'HEAD'); }
  catch (error) {
    const branch = await execa('git', ['-C', repositoryPath, 'symbolic-ref', '--quiet', 'HEAD']);
    const reference = await execa('git', ['-C', repositoryPath, 'show-ref', '--verify', '--quiet', branch.stdout.trim()], { reject: false });
    if (reference.exitCode === 1) return null;
    throw error;
  }
}
