import { promises as fs } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { analyzeLanguageFile, calculateMaintainabilityIndex } from './analyzers.mjs';
import { createAnalysisManifest, fingerprint } from './manifest.mjs';
import { createGitBlobReader, discoverGitFiles } from './git-files.mjs';

export async function analyzeSnapshot({ repositoryPath = '.', revision = 'HEAD', cache = new Map() } = {}) {
  const inventory = await discoverGitFiles(repositoryPath, revision);
  const supported = inventory.files.filter(file => file.language);
  if (!supported.length) throw new Error(`No supported source files in ${revision}`);
  const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'code-quality-'));
  const reader = createGitBlobReader(repositoryPath);
  const files = [];
  const manifest = createAnalysisManifest();
  try {
    for (const file of supported) {
      const key = `${manifest.languages[file.language]}:${file.blob_oid}`;
      let calculation = cache.get(key);
      if (!calculation) {
        const filename = path.join(folder, `${files.length}${path.posix.extname(file.file_path)}`);
        await fs.writeFile(filename, await reader.read(file.blob_oid));
        try { calculation = await analyzeLanguageFile(filename, file.language); }
        catch (error) { throw new Error(`${file.file_path}: ${error.message}`, { cause: error }); }
        cache.set(key, calculation);
      }
      if (!Object.values(calculation).every(value => Number.isFinite(value) && value >= 0)) throw new Error(`Invalid analyzer result for ${file.file_path}`);
      const health = calculateMaintainabilityIndex(calculation.cyclomatic_complexity, calculation.lines_of_code);
      files.push({ path: file.file_path, language: file.language, blob: file.blob_oid, ...calculation, code_health: health, maintainability_index: health });
    }
  } finally { await reader.close(); await fs.rm(folder, { recursive: true, force: true }); }
  const lines = files.reduce((sum, file) => sum + file.lines_of_code, 0);
  const rounded = value => Math.round(value * 100) / 100;
  const health = lines ? files.reduce((sum, file) => sum + file.code_health * file.lines_of_code, 0) / lines : 100;
  return {
    revision, tree: inventory.tree_oid, analyzer: fingerprint(manifest), files,
    summary: { total_files: files.length, total_loc: lines, avg_cyclomatic_complexity: rounded(files.reduce((sum, file) => sum + file.cyclomatic_complexity, 0) / files.length), max_cyclomatic_complexity: Math.max(...files.map(file => file.cyclomatic_complexity)), code_health: rounded(health), maintainability_index: rounded(health) },
    unsupported_paths: inventory.files.filter(file => !file.language).map(file => file.file_path),
  };
}
