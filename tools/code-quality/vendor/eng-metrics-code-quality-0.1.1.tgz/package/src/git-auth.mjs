export function gitSafeEnvironment(environment = process.env) {
  return Object.fromEntries(Object.entries(environment).filter(([name]) => !/^(?:GIT_(TRACE|CURL_VERBOSE)|GITHUB_APP_|GITHUB_CONNECTION_|GITHUB_TOKEN$|PAT_GITHUB$)/.test(name)));
}

export function gitAuthenticationEnvironment(url, token, environment = process.env) {
  const safe = gitSafeEnvironment(environment);
  if (!url.startsWith('https://github.com/')) return safe;
  const clean = Object.fromEntries(Object.entries(safe).filter(([name]) => !/^GIT_CONFIG_/.test(name)));
  return {
    ...clean, GIT_TERMINAL_PROMPT: '0', GIT_CONFIG_COUNT: '3',
    GIT_CONFIG_KEY_0: 'http.https://github.com/.extraheader', GIT_CONFIG_VALUE_0: '',
    GIT_CONFIG_KEY_1: 'http.https://github.com/.extraheader',
    GIT_CONFIG_VALUE_1: token ? `Authorization: Basic ${Buffer.from(`x-access-token:${token}`).toString('base64')}` : '',
    GIT_CONFIG_KEY_2: 'credential.helper', GIT_CONFIG_VALUE_2: '',
  };
}

export function gitTransferFailure() {
  throw new Error('Git could not clone or fetch this repository. Check its connection, branch and network, then retry.');
}
