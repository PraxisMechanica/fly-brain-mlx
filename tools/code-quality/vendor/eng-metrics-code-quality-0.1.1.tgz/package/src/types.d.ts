export interface FileCalculation { cyclomatic_complexity: number; cognitive_complexity: number; lines_of_code: number; }
