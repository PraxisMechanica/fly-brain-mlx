import { createRequire } from 'node:module';
import path from 'node:path';
import nodeGypBuild from 'node-gyp-build';
import go from '@ast-grep/lang-go';
import { registerDynamicLanguage } from '@ast-grep/napi';

const runtimeRequire = createRequire(import.meta.url);
const csharpDirectory = path.dirname(runtimeRequire.resolve('tree-sitter-c-sharp/package.json'));
registerDynamicLanguage({
  go,
  csharp: {
    libraryPath: nodeGypBuild.path(csharpDirectory),
    languageSymbol: 'tree_sitter_c_sharp',
    extensions: ['cs'],
    expandoChar: 'µ',
  },
});

export { parse } from '@ast-grep/napi';
