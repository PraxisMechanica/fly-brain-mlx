const rules = [
  { id: 'CQ001', metric: 'code_health', direction: 'higher' },
  { id: 'CQ002', metric: 'cyclomatic_complexity', direction: 'lower' },
  { id: 'CQ003', metric: 'maintainability_index', direction: 'higher' },
];
const worsened = (before, after, direction) => direction === 'higher' ? after < before : after > before;

export function compareSnapshots(before, after, renames = new Map()) {
  if (before.analyzer !== after.analyzer) throw new Error('Baseline and candidate analyzers differ');
  const findings = [];
  const compare = (path, metric, baseline, candidate, rule) => {
    if (!Number.isFinite(baseline) || !Number.isFinite(candidate)) throw new Error(`Missing ${metric} for ${path}`);
    if (worsened(baseline, candidate, rule.direction)) findings.push({ rule: rule.id, path, metric, before: baseline, after: candidate });
  };
  for (const rule of rules) {
    const metrics = rule.metric === 'cyclomatic_complexity' ? ['avg_cyclomatic_complexity', 'max_cyclomatic_complexity'] : [rule.metric];
    for (const metric of metrics) compare('<repository>', metric, before.summary[metric], after.summary[metric], rule);
  }
  const baseline = new Map(before.files.map(file => [file.path, file]));
  for (const file of after.files) {
    const previous = baseline.get(renames.get(file.path) || file.path);
    if (!previous || previous.language !== file.language) continue;
    const rule = rules.find(rule => rule.metric === 'cyclomatic_complexity');
    compare(file.path, rule.metric, previous[rule.metric], file[rule.metric], rule);
  }
  return { passed: findings.length === 0, findings, before, after };
}
