const identifier = /^[_\p{ID_Start}][_\p{ID_Continue}]*$/u;
const protectedKinds = ['comment', 'string_literal', 'verbatim_string_literal', 'raw_string_literal', 'character_literal', 'interpolated_string_expression'];

/** @param {string} value */
export function configuredCSharpSymbols(value = process.env.CSHARP_DEFINE_SYMBOLS ?? '') {
  const symbols = [...new Set(value.split(/[\s,;]+/).filter(Boolean))].sort();
  if (symbols.some(symbol => !identifier.test(symbol) || symbol === 'true' || symbol === 'false')) {
    throw new Error('CSHARP_DEFINE_SYMBOLS must contain C# identifiers separated by commas, semicolons, or spaces');
  }
  return symbols;
}

/**
 * @param {string} content
 * @param {string[]} definedSymbols
 * @param {(source: string) => import('@ast-grep/napi').SgNode} parseRoot
 */
export function preprocessCSharp(content, definedSymbols, parseRoot) {
  if (!/^\s*#\s*(?:if|elif|else|endif|define|undef)\b/m.test(content)) return content;
  const protectedRanges = parseRoot(content).findAll({ rule: { any: protectedKinds.map(kind => ({ kind })) } }).map(node => node.range());
  const symbols = new Set(definedSymbols);
  /** @type {{parentActive: boolean, branchTaken: boolean, elseSeen: boolean}[]} */
  const stack = [];
  let active = true;
  let offset = 0;

  /** @param {import('@ast-grep/napi').SgNode} node @returns {boolean} */
  function evaluate(node) {
    switch (node.kind()) {
      case 'identifier': return symbols.has(node.text());
      case 'boolean_literal': return node.text() === 'true';
      case 'parenthesized_expression': return evaluate(node.children()[1]);
      case 'unary_expression': return !evaluate(node.field('argument'));
      case 'binary_expression': {
        const left = evaluate(node.field('left'));
        const right = evaluate(node.field('right'));
        switch (node.field('operator')?.text()) {
          case '&&': return left && right;
          case '||': return left || right;
          case '==': return left === right;
          case '!=': return left !== right;
        }
      }
    }
    throw new SyntaxError('Unsupported C# preprocessor expression');
  }

  /** @param {string} expression @param {number} line */
  function condition(expression, line) {
    const root = parseRoot(`#if ${expression}\n#endif`);
    const node = root.find({ rule: { kind: 'preproc_if' } })?.field('condition');
    if (!node || root.find({ rule: { kind: 'ERROR' } })) throw new SyntaxError(`Invalid C# preprocessor condition at line ${line}`);
    return evaluate(node);
  }

  const output = content.split('\n').map((text, index) => {
    const start = offset;
    offset += text.length + 1;
    const directive = text.match(/^\s*#\s*(if|elif|else|endif|define|undef)\b(.*)\r?$/);
    const hash = start + text.indexOf('#');
    if (!directive || protectedRanges.some(range => range.start.index <= hash && hash < range.end.index)) return active ? text : text.replace(/[^\r]/g, ' ');
    const [, kind, value] = directive;
    const line = index + 1;
    const expression = value.replace(/\/\/.*$/, '').trim();
    if (kind === 'if') {
      const selected = condition(expression, line);
      stack.push({ parentActive: active, branchTaken: selected, elseSeen: false });
      active = active && selected;
    } else if (kind === 'define' || kind === 'undef') {
      if (!identifier.test(expression) || expression === 'true' || expression === 'false') throw new SyntaxError(`Invalid C# preprocessor symbol at line ${line}`);
      if (active) {
        if (kind === 'define') symbols.add(expression);
        else symbols.delete(expression);
      }
    } else {
      const frame = stack.at(-1);
      if (!frame || (frame.elseSeen && kind !== 'endif') || (kind !== 'elif' && expression)) throw new SyntaxError(`Unexpected C# #${kind} at line ${line}`);
      if (kind === 'elif') {
        const selected = condition(expression, line);
        active = frame.parentActive && !frame.branchTaken && selected;
        frame.branchTaken ||= selected;
      } else if (kind === 'else') {
        active = frame.parentActive && !frame.branchTaken;
        frame.branchTaken = true;
        frame.elseSeen = true;
      } else {
        active = frame.parentActive;
        stack.pop();
      }
    }
    return text.replace(/[^\r]/g, ' ');
  });
  if (stack.length) throw new SyntaxError('Unclosed C# #if directive');
  return output.join('\n');
}
