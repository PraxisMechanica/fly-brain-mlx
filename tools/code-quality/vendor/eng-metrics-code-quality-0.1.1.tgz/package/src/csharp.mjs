import { promises as fs } from 'node:fs';
import { parse } from './parsers.mjs';
import { configuredCSharpSymbols, preprocessCSharp } from './csharp-preprocessor.mjs';

const controlFlow = new Set([
  'if_statement',
  'for_statement',
  'foreach_statement',
  'while_statement',
  'do_statement',
  'catch_clause',
  'conditional_expression',
]);
const literals = new Set([
  'comment',
  'string_literal',
  'verbatim_string_literal',
  'raw_string_literal',
  'character_literal',
]);

/** @param {string} content @param {string[]} definedSymbols */
export function calculateCSharpComplexity(content, definedSymbols = []) {
  const root = parse('csharp', preprocessCSharp(content, definedSymbols, source => parse('csharp', source).root())).root();
  let cyclomatic = 1;
  let cognitive = 0;

  /**
   * @param {import('@ast-grep/napi').SgNode} node
   * @param {number} nesting
   * @param {boolean} elseIf
   */
  function visit(node, nesting, elseIf = false) {
    const kind = node.kind();
    if (kind === 'ERROR') {
      throw new SyntaxError(`C# parser rejected syntax at line ${node.range().start.line + 1}`);
    }
    if (literals.has(kind)) return;

    let childNesting = nesting;
    if (controlFlow.has(kind)) {
      cyclomatic += 1;
      cognitive += elseIf ? 1 : 1 + nesting;
      childNesting += elseIf ? 0 : 1;
    } else if (kind === 'switch_statement' || kind === 'switch_expression') {
      cognitive += 1 + nesting;
      childNesting += 1;
    } else if (kind === 'lambda_expression' || kind === 'local_function_statement') {
      childNesting += 1;
    }

    if (kind === 'binary_expression') {
      const operator = node.field('operator')?.text();
      if (operator === '&&' || operator === '||') {
        cyclomatic += 1;
        const parent = node.parent();
        if (parent?.kind() !== 'binary_expression' || parent.field('operator')?.text() !== operator) {
          cognitive += 1;
        }
      } else if (operator === '??') {
        cyclomatic += 1;
      }
    }
    if (kind === 'case' || kind === 'when_clause' || kind === 'catch_filter_clause') {
      cyclomatic += 1;
    }
    if (kind === 'switch_expression_arm' && node.children()[0]?.kind() !== 'discard') {
      cyclomatic += 1;
    }
    if (kind === 'conditional_access_expression' || kind === 'and_pattern' || kind === 'or_pattern') {
      cyclomatic += 1;
      if (kind !== 'conditional_access_expression' && node.parent()?.kind() !== kind) cognitive += 1;
    }
    if (kind === 'goto_statement' || kind === 'continue_statement') {
      cognitive += 1;
    }

    const alternative = kind === 'if_statement' ? node.field('alternative') : null;
    for (const child of node.children()) {
      if (alternative && child.id() === alternative.id()) {
        const isElseIf = child.kind() === 'if_statement';
        if (!isElseIf) cognitive += 1;
        visit(child, isElseIf ? nesting : nesting + 1, isElseIf);
      } else {
        visit(child, childNesting);
      }
    }
  }

  visit(root, 0);
  return {
    cyclomatic_complexity: cyclomatic,
    cognitive_complexity: cognitive,
    lines_of_code: content.split('\n').filter((line) => line.trim() !== '').length,
  };
}

/** @param {string} filePath */
export async function analyzeCSharpComplexity(filePath) {
  return calculateCSharpComplexity(await fs.readFile(filePath, 'utf8'), configuredCSharpSymbols());
}
