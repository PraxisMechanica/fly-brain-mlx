import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { gitAuthenticationEnvironment, gitTransferFailure } from './git-auth.mjs';
import { createRequire } from 'node:module';
import { promises as fs } from 'node:fs';
import { compareIdentityStrings, fingerprint, getFileLanguage, isIncludedPath } from './manifest.mjs';

const exec = promisify(execFile);
const { getFormatByFile } = createRequire(import.meta.url)('@jscpd/tokenizer');

/** @param {string} repositoryPath @param {string[]} args */
async function git(repositoryPath, args) {
  return (await exec('git', ['-C', repositoryPath, ...args], { maxBuffer: 64 * 1024 * 1024 })).stdout;
}

/** @param {{url: string, default_branch: string}} repository @param {string} directory @param {{token?:string,environment?:Record<string,string|undefined>}} [options] */
export async function prepareGitRepository(repository, directory, options = {}) {
  const env = gitAuthenticationEnvironment(repository.url, options.token, options.environment);
  const run = (/** @type {string[]} */ args) => exec('git', args, { env, maxBuffer: 64 * 1024 * 1024, timeout: 15 * 60_000 }).catch(gitTransferFailure);
  const exists = await fs.stat(directory).then(() => true, error => {
    if (error.code === 'ENOENT') return false;
    throw error;
  });
  if (!exists) {
    await run(['clone', '--no-checkout', '--branch', repository.default_branch, '--', repository.url, directory]);
  } else {
    const shallow = (await git(directory, ['rev-parse', '--is-shallow-repository'])).trim() === 'true';
    await run(['-C', directory, 'fetch', ...(shallow ? ['--unshallow'] : []), 'origin', `+refs/heads/${repository.default_branch}:refs/remotes/origin/${repository.default_branch}`]);
  }
  return directory;
}

/** @param {string} repositoryPath @param {string} branch */
export async function readGitHistory(repositoryPath, branch) {
  const output = await git(repositoryPath, ['log', '--format=%H%x00%cI', `refs/remotes/origin/${branch}`]);
  return output.trim().split('\n').filter(Boolean).map((line, sequenceNumber) => {
    const [commitSha, commitDate] = line.split('\0');
    return { commitSha, commitDate, sequenceNumber };
  });
}

/** @param {string} repositoryPath @param {string} blobOid */
export async function readGitBlob(repositoryPath, blobOid) {
  return (await exec('git', ['-C', repositoryPath, 'cat-file', 'blob', blobOid.split(':')[1]], { encoding: 'buffer', maxBuffer: 64 * 1024 * 1024 })).stdout;
}

/** @param {string} repositoryPath */
export function createGitBlobReader(repositoryPath) {
  const child = spawn('git', ['-C', repositoryPath, 'cat-file', '--batch']);
  const output = child.stdout[Symbol.asyncIterator]();
  let buffer = Buffer.alloc(0);
  let stderr = '';
  let failure;
  child.stderr.setEncoding('utf8').on('data', chunk => { stderr += chunk; });
  const exited = new Promise(resolve => {
    child.once('error', error => { failure = error; resolve(); });
    child.once('close', resolve);
  });
  child.stdin.on('error', error => { failure = error; });
  const fill = async () => {
    const next = await output.next();
    if (next.done) {
      await exited;
      throw failure ?? new Error(stderr.trim() || 'Git blob reader exited before completing its response');
    }
    buffer = Buffer.concat([buffer, next.value]);
  };
  return {
    /** @param {string} blobOid */
    async read(blobOid) {
      await new Promise((resolve, reject) => child.stdin.write(`${blobOid.split(':')[1]}\n`, error => error ? reject(error) : resolve()));
      while (!buffer.includes(10)) await fill();
      const end = buffer.indexOf(10);
      const [oid, type, size] = buffer.subarray(0, end).toString('utf8').split(' ');
      buffer = buffer.subarray(end + 1);
      if (type !== 'blob') throw new Error(`Git object ${oid} is not an available blob (${type})`);
      const length = Number(size);
      const content = Buffer.allocUnsafe(length);
      let offset = 0;
      while (offset < length) {
        if (!buffer.length) await fill();
        const count = Math.min(length - offset, buffer.length);
        buffer.copy(content, offset, 0, count);
        buffer = buffer.subarray(count);
        offset += count;
      }
      if (!buffer.length) await fill();
      buffer = buffer.subarray(1);
      return content;
    },
    async close() {
      child.stdin.end();
      child.kill();
      await exited;
    },
  };
}

/** @param {string} repositoryPath @param {string} commitSha */
export async function readGitCommit(repositoryPath, commitSha) {
  const [author_name, author_email, message, committed_at] = (await git(repositoryPath, ['show', '-s', '--format=%an%x00%ae%x00%B%x00%cI', commitSha])).split('\0');
  const diff = await git(repositoryPath, ['diff-tree', '--root', '--first-parent', '--diff-merges=first-parent', '--no-renames', '--no-commit-id', '--numstat', '-r', '-z', commitSha]);
  let files_changed = 0;
  let lines_added = 0;
  let lines_deleted = 0;
  for (const record of diff.split('\0')) {
    if (!record) continue;
    const [added, deleted] = record.split('\t');
    files_changed++;
    lines_added += Number.parseInt(added, 10) || 0;
    lines_deleted += Number.parseInt(deleted, 10) || 0;
  }
  return { author_name, author_email, message: message.trimEnd(), committed_at: committed_at.trim(), files_changed, lines_added, lines_deleted };
}

/** @param {string} repositoryPath @param {string} commitSha */
export async function discoverGitFiles(repositoryPath, commitSha) {
  const treeOid = (await git(repositoryPath, ['rev-parse', '--verify', '--end-of-options', `${commitSha}^{tree}`])).trim();
  const objectFormat = (await git(repositoryPath, ['rev-parse', '--show-object-format'])).trim();
  const tree = await git(repositoryPath, ['ls-tree', '-r', '-z', treeOid]);
  const files = [];
  for (const record of tree.split('\0')) {
    if (!record) continue;
    const tab = record.indexOf('\t');
    const [mode, type, oid] = record.slice(0, tab).split(' ');
    const filePath = record.slice(tab + 1);
    if (type !== 'blob' || !['100644', '100755'].includes(mode) || !isIncludedPath(filePath)) continue;
    files.push({ file_path: filePath, blob_oid: `${objectFormat}:${oid}`, language: getFileLanguage(filePath), duplication_format: getFormatByFile(filePath) || null });
  }
  return { tree_oid: `${objectFormat}:${treeOid}`, files };
}

/**
 * @param {Awaited<ReturnType<typeof discoverGitFiles>>['files']} files
 * @param {string} analyzerKey
 */
export function duplicationInputKey(files, analyzerKey) {
  const inputs = files.filter((file) => file.duplication_format).map((file) => [file.file_path, file.blob_oid, file.duplication_format]).sort(([a], [b]) => compareIdentityStrings(a, b));
  return `${analyzerKey}:${fingerprint(inputs)}`;
}
