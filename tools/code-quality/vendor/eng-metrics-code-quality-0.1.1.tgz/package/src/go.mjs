import { promises as fs } from 'node:fs';
import { parse } from './parsers.mjs';

const controlFlow = new Set(['if_statement', 'for_statement']);
const selections = new Set(['expression_switch_statement', 'type_switch_statement', 'select_statement']);
const cases = new Set(['expression_case', 'type_case', 'communication_case']);
const literals = new Set(['comment', 'interpreted_string_literal', 'raw_string_literal', 'rune_literal']);

/** @param {string} content */
export function calculateGoComplexity(content) {
  const root = parse('go', content).root();
  if (!root.find({ rule: { kind: 'package_clause' } })) throw new SyntaxError('Go parser expected a package clause at line 1');
  let cyclomatic = 1;
  let cognitive = 0;

  /** @param {import('@ast-grep/napi').SgNode} node @param {number} nesting @param {boolean} elseIf */
  function visit(node, nesting, elseIf = false) {
    const kind = node.kind();
    if (kind === 'ERROR' || (node.isLeaf() && node.text() === '')) {
      throw new SyntaxError(`Go parser rejected syntax at line ${node.range().start.line + 1}`);
    }
    if (literals.has(kind)) return;

    let childNesting = nesting;
    if (controlFlow.has(kind)) {
      cyclomatic += 1;
      cognitive += elseIf ? 1 : 1 + nesting;
      childNesting += elseIf ? 0 : 1;
    } else if (selections.has(kind)) {
      cognitive += 1 + nesting;
      childNesting += 1;
    } else if (kind === 'func_literal') {
      childNesting += 1;
    }

    if (cases.has(kind)) cyclomatic += 1;
    if (kind === 'binary_expression') {
      const operator = node.field('operator')?.text();
      if (operator === '&&' || operator === '||') {
        cyclomatic += 1;
        const parent = node.parent();
        if (parent?.kind() !== 'binary_expression' || parent.field('operator')?.text() !== operator) cognitive += 1;
      }
    }
    if (kind === 'goto_statement' || kind === 'continue_statement' || kind === 'fallthrough_statement' || (kind === 'break_statement' && node.namedChildren().length > 0)) cognitive += 1;

    const alternative = kind === 'if_statement' ? node.field('alternative') : null;
    for (const child of node.children()) {
      if (alternative && child.id() === alternative.id()) {
        const isElseIf = child.kind() === 'if_statement';
        if (!isElseIf) cognitive += 1;
        visit(child, isElseIf ? nesting : nesting + 1, isElseIf);
      } else {
        visit(child, childNesting);
      }
    }
  }

  visit(root, 0);
  return {
    cyclomatic_complexity: cyclomatic,
    cognitive_complexity: cognitive,
    lines_of_code: content.split('\n').filter(line => line.trim() !== '').length,
  };
}

/** @param {string} filePath */
export async function analyzeGoComplexity(filePath) {
  return calculateGoComplexity(await fs.readFile(filePath, 'utf8'));
}
