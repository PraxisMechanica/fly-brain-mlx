import { execa } from 'execa';
import { promises as fs } from 'node:fs';
import { analyzeCSharpComplexity } from './csharp.mjs';
import { analyzeGoComplexity } from './go.mjs';

export { analyzeJavaScriptComplexity, calculateCognitiveComplexity } from './javascript.mjs';
import { analyzeJavaScriptComplexity } from './javascript.mjs';

/** @param {string} filePath */
export async function analyzePythonComplexity(filePath) {
    const content = await fs.readFile(filePath, 'utf8');
    const program = "import sys\nimport radon\nfrom radon.visitors import ComplexityVisitor\nif radon.__version__ != '6.0.1':\n    raise RuntimeError('Required Radon 6.0.1 is unavailable')\nclass FileDecisionVisitor(ComplexityVisitor):\n    visit_FunctionDef = ComplexityVisitor.generic_visit\n    visit_ClassDef = ComplexityVisitor.generic_visit\nsource = sys.stdin.read()\nprint(str(FileDecisionVisitor.from_code(source).complexity) + ':' + str(len(ComplexityVisitor.from_code(source).blocks)))\n";
    const { stdout } = await execa('python', ['-c', program], { input: content.replace(/^\uFEFF/, '') });
    const fields = stdout.trim().split(':');
    const [cyclomatic, blocks] = fields.map(Number);
    if (!/^[1-9]\d*:\d+$/.test(stdout.trim()) || fields.length !== 2 || !Number.isSafeInteger(cyclomatic) || cyclomatic < 1 || !Number.isSafeInteger(blocks) || blocks < 0) throw new Error(`Radon could not analyze ${filePath}: ${stdout}`);
    return {
        cyclomatic_complexity: cyclomatic,
        cognitive_complexity: blocks === 0 ? 1 : calculateCognitiveComplexityPython(content),
        lines_of_code: content.split('\n').filter(line => line.trim() !== '').length,
    };
}

/** @type {Record<string, (filePath: string) => Promise<import('./types.js').FileCalculation>>} */
const languageAnalyzers = {
    javascript: analyzeJavaScriptComplexity,
    typescript: analyzeJavaScriptComplexity,
    python: analyzePythonComplexity,
    csharp: analyzeCSharpComplexity,
    go: analyzeGoComplexity,
};

/** @param {string} filePath @param {string} language */
export async function analyzeLanguageFile(filePath, language) {
    const analyze = languageAnalyzers[language];
    if (!Object.hasOwn(languageAnalyzers, language)) throw new Error(`Unsupported analyzer: ${language}`);
    return analyze(filePath);
}

/** @param {string} content */
function calculateCognitiveComplexityPython(content) {
    let complexity = 0;
    let nestingLevel = 0;
    const lines = content.split('\n');
    for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) {
            continue;
        }
        const leadingSpaces = line.search(/\S/);
        const currentIndent = leadingSpaces >= 0 ? Math.floor(leadingSpaces / 4) : 0;
        if (currentIndent < nestingLevel) {
            nestingLevel = currentIndent;
        }
        const nestingKeywords = [
            /^if\s+/,
            /^elif\s+/,
            /^for\s+/,
            /^while\s+/,
            /^try\s*:/,
            /^except(\s+|:)/,
            /^with\s+/,
        ];
        for (const pattern of nestingKeywords) {
            if (pattern.test(trimmed)) {
                complexity += 1 + nestingLevel;
                if (trimmed.endsWith(':')) {
                    nestingLevel = currentIndent + 1;
                }
                break;
            }
        }
        if (/^else\s*:/.test(trimmed)) {
            complexity += 1;
        }
        const logicalOps = (trimmed.match(/\band\b|\bor\b/g) || []).length;
        if (logicalOps > 0) {
            complexity += 1;
        }
        if (/\bif\b.*\belse\b/.test(trimmed) && !trimmed.startsWith('if')) {
            complexity += 1;
        }
        if (/\b(break|continue)\b/.test(trimmed)) {
            complexity += 1;
        }
    }
    return complexity;
}
export { calculateMaintainabilityIndex } from './health.mjs';
