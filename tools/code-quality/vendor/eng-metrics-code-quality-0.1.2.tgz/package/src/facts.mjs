import { promises as fs } from 'node:fs';
import path from 'node:path';

const identityPattern = /^[a-f0-9]{64}$/;
const keyPattern = /^[a-f0-9]{64}:sha(?:1:[a-f0-9]{40}|256:[a-f0-9]{64})$/;

function decode(value) {
  if (!Array.isArray(value) || value.length !== 3 || value[0] !== 1 ||
      typeof value[1] !== 'string' || !identityPattern.test(value[1]) || !Array.isArray(value[2])) {
    throw new Error('Invalid metric-facts protocol');
  }
  const cache = new Map();
  for (const row of value[2]) {
    if (!Array.isArray(row) || row.length !== 2 || typeof row[0] !== 'string' ||
        !keyPattern.test(row[0]) || cache.has(row[0]) || !Array.isArray(row[1]) ||
        row[1].length !== 3 || !row[1].every(number => Number.isSafeInteger(number) && number >= 0) || row[1][0] < 1) {
      throw new Error('Invalid metric-facts entry');
    }
    const [cyclomatic_complexity, cognitive_complexity, lines_of_code] = row[1];
    cache.set(row[0], { cyclomatic_complexity, cognitive_complexity, lines_of_code });
  }
  return { identity: value[1], cache };
}

export async function loadMetricFacts(filename, identity) {
  if (!identityPattern.test(identity)) throw new Error('Invalid metric-facts identity');
  let source;
  try { source = await fs.readFile(filename, 'utf8'); }
  catch (error) {
    if (error.code === 'ENOENT') return new Map();
    throw error;
  }
  const decoded = decode(JSON.parse(source));
  return decoded.identity === identity ? decoded.cache : new Map();
}

export async function saveMetricFacts(filename, identity, cache) {
  const rows = [...cache].map(([key, calculation]) => [key, [
    calculation.cyclomatic_complexity, calculation.cognitive_complexity, calculation.lines_of_code,
  ]]);
  const value = [1, identity, rows];
  decode(value);
  await fs.mkdir(path.dirname(filename), { recursive: true });
  const temporary = `${filename}.${process.pid}.tmp`;
  await fs.writeFile(temporary, JSON.stringify(value));
  await fs.rename(temporary, filename);
}
